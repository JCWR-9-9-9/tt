export OO_PS4_TOOLCHAIN=/home/user/tab/tasks/fc3f4fdd-b8ab-48dc-9d21-10043b81948d/work/tc/OpenOrbis/PS4Toolchain
export PATH=/usr/lib/llvm-16/bin:$PATH GOLDHEN_SDK=/home/user/tab/tasks/e0310653-04b8-4d18-a3bd-2de23ea8a7d1/work/sdk DOTNET_SYSTEM_GLOBALIZATION_INVARIANT=1
