تيكن مودز v2.00 (الإضافة v2.18، المثبّت TABX00011 v2.00)
=====================================================

ما الجديد
---------
صانع الكومبو صار شاشة واحدة كبيرة، كل شي فيها قابل للتعديل:

- كل سطر هو خطوة (ضغطة واحدة). الخطوة إما اتجاه، أو زر، أو اتجاه مع زر معاً مثل "Up+Right + X".
- الاتجاه والزر يُختاران من الشاشة نفسها، والإضافة بـ X. ما فيه صفحات منفصلة.
- الفاصل بعد كل خطوة بالثواني، بخطوات 0.01 ثانية، الافتراضي 0.20 ثانية.
- القائمة تعرض 8 خطوات بالمرة مع تمرير، والعنوان يعرض عدد الخطوات.

كيف تبني كومبو
--------------
1) من القائمة (L3 + OPTIONS) اختر سطر "Combo slot" واضغط Triangle، ثم اختر "Build a combo" واضغط X.
2) الصف "Direction": Left/Right لاختيار الاتجاه (none, Up, Up+Right, Right, Down+Right, Down, Down+Left, Left, Up+Left).
3) الصف "Button": Left/Right لاختيار الزر (none, X, Circle, Square, Triangle, L1, R1).
   لازم يكون فيه اتجاه أو زر على الأقل. إذا اخترت الاثنين تصير الخطوة اتجاه مع زر في الوقت نفسه.
4) الصف "Gap after it": Left/Right تغيّر الفاصل 0.01 ثانية، و L1/R1 تغيّره 0.10 ثانية.
5) X على أي صف من الصفوف الثلاثة (Direction, Button, Gap) أو على "Add step" تضيف الخطوة. المؤشر يبقى مكانه بعد الإضافة، فتضيف الخطوة التالية بسرعة.
6) للتعديل على خطوة موجودة: Up/Down توصل لسطرها، ثم Left/Right تغيّر فاصلها فقط. Triangle تحذف الخطوة المختارة.
7) "Save": X تفتح اختيار الخانة. Left/Right لاختيار الخانة من 1 إلى 10، ثم X للحفظ.
   إذا كانت الخانة فيها كومبو، اضغط X مرتين للاستبدال.
8) O يلغي صانع الكومبو كله ولا يكتب شي. O في صفحة الخانة يرجعك لصانع الكومبو.

حدود
-----
- الفاصل الأدنى 0.07 ثانية (أقصر ضغطة مع إطار فاضي بعدها). الأقصى 5.00 ثانية. الافتراضي 0.20 ثانية.
- أقصى عدد خطوات 40.
- كل ضغطة تنضغط نحو 50 ملي ثانية، والعصيين بوضع الراحة.
- اللعبة تقرأ الدواسة 60 مرة بالثانية، لذلك الفاصل يُحفظ بإطارات كاملة (1/60 ثانية). مثلاً 0.20 ثانية = 12 إطار، و0.25 ثانية = 15 إطار.
  الشاشة تعرض الفاصل كما اخترته، والفرق لا يتجاوز 1/60 ثانية.

ما لم يتغير
-----------
- "Edit timing" (تعديل التوقيت للخانة الموجودة) كما هو في v1.09، بنفس المفاتيح.
- الخانات 1 إلى 9، والخانة 10 بكومبو "10 Hit Combo 1" الجاهز إذا كانت فارغة، والتسجيل بـ L3 + R3، والتشغيل بـ R3 أو L3 للمرآة.
- الصحة، وسرعة اللعب، والعرض على الشاشة. الملف يُكتب بالترويسة وطريقة الكتابة نفسها.
- النصوص على الشاشة إنجليزية لأن الخط المرسوم به القائمة لا يدعم العربية. هذا الشرح بالعربية والإنجليزية.

ملاحظة عن الشاشة
----------------
- الشاشة صارت أكبر من القديمة. إذا رأيت أعلى الصفوف تومض أو تختفي في لحظات، أخبرني بالضبط متى يحدث.

التثبيت
-------
1) امسح أي ملف tekken_memsearch*.prx من مجلد plugins، وامسح سطره من plugins.ini إذا كان موجوداً.
2) ثبّت Tekken_Mods_Installer_v2.00.pkg بالطريقة نفسها التي ثبّتّ بها الإصدارات السابقة.
3) اختبر: ابنِ كومبو من خطوتين أو ثلاث في خانة فارغة (مثلاً الخانة 4)، واحفظه، ثم شغّله بـ R3.

لم يُختبر على البلايستيشن
------------------------
البناء ينجح واختبارات الحاسوب تمر، لكن لم يُشغَّل هذا الإصدار على جهاز PS4 بعد. جرّبه أولاً على خانة لا تهمك.

==================================================================

TEKKEN MODS v2.00 (plugin v2.18, installer TABX00011 v2.00)
=========================================================

What changed
------------
The combo builder is now one big screen, everything editable:
- Each row is one step (one press): a direction, a button, or both together, e.g. "Up+Right + X".
- Direction and Button are picked on the same screen; X adds the step. No separate pages.
- Gap after each step in seconds, in 0.01 s steps (default 0.20 s).
- The list shows 8 steps at a time with a scroll, and the title shows the step count.

How to build a combo
--------------------
1) In the mod menu (L3 + OPTIONS), select the "Combo slot" row, press Triangle, then choose "Build a combo" and press X.
2) "Direction" row: Left/Right picks none, Up, Up+Right, Right, Down+Right, Down, Down+Left, Left or Up+Left.
3) "Button" row: Left/Right picks none, X, Circle, Square, Triangle, L1 or R1.
   A step needs a direction or a button (or both). Both together make one step, e.g. Up+Right + X.
4) "Gap after it": Left/Right changes it by 0.01 s, L1/R1 by 0.10 s.
5) X on the Direction, Button or Gap row, or on "Add step", adds the step. The cursor stays where it was, so the next step is quick.
6) To change an existing step: Up/Down to its row, then Left/Right changes only its gap. Triangle deletes the selected step.
7) "Save": X opens the slot picker. Left/Right picks slot 1 to 10, then X saves. If the slot already holds a combo, X twice replaces it.
8) O cancels the builder and writes nothing. O on the slot picker goes back to the builder.

Limits
------
- Gap: minimum 0.07 s (a 50 ms press plus one released frame), maximum 5.00 s, default 0.20 s.
- Maximum 40 steps. Each press is a 50 ms tap with the sticks centred.
- The game reads the pad 60 times a second, so gaps are stored in whole frames (1/60 s): 0.20 s = 12 frames, 0.25 s = 15 frames.
  The screen shows the gap you chose; the stored timing is within 1/60 s of it.

What did not change
-------------------
- "Edit timing" for an existing slot, with the same keys as v1.09.
- Slots 1 to 9, slot 10 with its built-in "10 Hit Combo 1" when empty, recording (L3 + R3), playback (R3, L3 mirrored).
- Health, game speed, the on-screen menu. Files are written with the same header and the same writer as before.
- On-screen text is English because the menu font has no Arabic. This README is in Arabic and English.

Note on the screen
------------------
- The builder screen is taller and wider than before. If its top rows flicker or disappear for a moment, tell me exactly when it happens.

Install
-------
1) Delete any tekken_memsearch*.prx from the plugins folder, and its line in plugins.ini, if present.
2) Install Tekken_Mods_Installer_v2.00.pkg the same way as the earlier releases.
3) Test: build a combo of two or three steps in an unused slot (for example slot 4), save it, play it with R3.

Not tested on the PS4
---------------------
The build succeeds and the host tests pass. This release has not run on a PS4 yet. Try it on a slot you do not need first.
