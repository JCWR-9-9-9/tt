// ov_fast.h — v2.14: the per-frame overlay work, compiled at -O2 in ov_fast.c.
#ifndef TK_OV_FAST_H
#define TK_OV_FAST_H
#include <stdint.h>
#include "overlay_draw.h"
uint32_t ovf_blit(uint8_t *buf, uint64_t size, int layout, uint32_t pitch, uint32_t fmt, const uint8_t *cv, const OvGeom *g);
void ovf_render(uint8_t *cv, const OvGeom *g, const OvMenuView *v, const unsigned char font[][8], int opaque);
#endif
