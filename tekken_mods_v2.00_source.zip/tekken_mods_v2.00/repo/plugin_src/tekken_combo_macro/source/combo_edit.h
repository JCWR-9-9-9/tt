#ifndef TK_COMBO_EDIT_H
#define TK_COMBO_EDIT_H
// v2.17 (menu v1.09): timing editor and combo maker, plain C (host-testable). v2.18: the maker takes gaps in
// hundredths of a second and one step may hold a direction and a button (ce_step_name).
// Needs MacroStep (main.c) and the MB_* masks + CE_* limits (menu_logic.h) above it.
// The game reads the pad once per frame and playback steps through the stored samples, so every gap
// is a whole number of frames (1/60 s). t_us is rewritten on the same grid: t_us = frame * 1e6 / 60.

typedef struct { uint32_t start, hold, buttons; } CePress;   // press: first step, steps held, buttons word

#define CE_BTN_MASK 0x7FFFFFFFu     // the intercept bit is never stored

// Rising edges of the buttons word. A press starts on a step whose buttons are non-zero and differ from the
// step before; its hold is the run of equal buttons from there. Returns the count, or -1 if more than max.
static inline int ce_parse(const MacroStep *s, uint32_t n, CePress *out, uint32_t max) {
    int P = 0;
    uint32_t i = 0;
    while (i < n) {
        const uint32_t b = s[i].buttons & CE_BTN_MASK;
        const uint32_t prev = i ? (s[i - 1].buttons & CE_BTN_MASK) : 0;
        if (b && b != prev) {
            uint32_t h = 1;
            while (i + h < n && (s[i + h].buttons & CE_BTN_MASK) == b) h++;
            if ((uint32_t)P >= max) return -1;
            out[P].start = i; out[P].hold = h; out[P].buttons = b;
            P++;
            i += h;
        } else {
            i++;
        }
    }
    return P;
}

// Gap of press k in frames: first step of press k to first step of press k+1; the last press: to the end.
static inline uint32_t ce_gap_frames(const CePress *p, int P, uint32_t n, int k) {
    return (k + 1 < P ? p[k + 1].start : n) - p[k].start;
}

// Smallest gap of press k: its own hold, plus one released frame when the next press is the same buttons
// (or when it is the last press, so every button is up before the combo ends).
static inline uint32_t ce_min_gap(const CePress *p, int P, int k) {
    const int need_release = (k + 1 >= P) || (p[k + 1].buttons == p[k].buttons);
    return p[k].hold + (need_release ? 1u : 0u);
}

// Rebuilds the sequence from the original with new gaps (frames per press). Everything in the original
// before the first press (lead-in) is kept; each press's own hold steps are copied as they were; the idle
// steps after a press are cut from their end or extended with their last step (neutral when there were
// none). Returns the new count, or 0 when a gap is below the press's hold or the result would not fit.
static inline uint32_t ce_rebuild(const MacroStep *in, uint32_t n, const CePress *p, int P,
                                  const uint32_t *gaps, MacroStep *out) {
    uint32_t total = P ? p[0].start : n;
    for (int k = 0; k < P; k++) {
        if (gaps[k] < p[k].hold) return 0;
        total += gaps[k];
    }
    if (total > CE_MAX_STEPS) return 0;
    uint32_t o = 0;
    const uint32_t lead = P ? p[0].start : n;
    for (uint32_t i = 0; i < lead; i++) out[o++] = in[i];
    for (int k = 0; k < P; k++) {
        const uint32_t hold = p[k].hold, base = p[k].start + hold;
        for (uint32_t j = 0; j < hold; j++) out[o++] = in[p[k].start + j];
        const uint32_t idle_orig = (k + 1 < P ? p[k + 1].start : n) - base;
        const uint32_t idle_new = gaps[k] - hold;
        for (uint32_t j = 0; j < idle_new; j++, o++) {
            if (j < idle_orig) out[o] = in[base + j];
            else if (idle_orig) out[o] = in[base + idle_orig - 1];
            else { memset(&out[o], 0, sizeof(MacroStep)); out[o].lx = out[o].ly = out[o].rx = out[o].ry = 0x80; }
        }
    }
    for (uint32_t i = 0; i < o; i++) out[i].t_us = (uint32_t)((uint64_t)i * 1000000u / CE_HZ_FRAMES);
    return o;
}

// v2.18: a maker gap in hundredths of a second (what the screen shows) to pad frames, rounded to the nearest
// frame (1/60 s), clamped to the maker's limits (0.07 s = 4 frames up to 5.00 s = 300 frames).
static inline uint32_t ce_cs_frames(uint32_t cs) {
    uint32_t f = (cs * CE_HZ_FRAMES + 50u) / 100u;
    if (f < CE_MIN_GAP) f = CE_MIN_GAP;
    if (f > CE_GAP_MAX) f = CE_GAP_MAX;
    return f;
}

// Maker: one step = CE_TAP_FRAMES steps with its buttons (sticks neutral), then neutral steps up to its gap.
static inline uint32_t ce_make_build(const MkPress *m, int M, MacroStep *out) {
    uint32_t o = 0;
    for (int k = 0; k < M; k++) {
        uint32_t gap = ce_cs_frames(m[k].cs);
        if (o + gap > CE_MAX_STEPS) return 0;
        for (uint32_t j = 0; j < gap; j++, o++) {
            memset(&out[o], 0, sizeof(MacroStep));
            out[o].lx = out[o].ly = out[o].rx = out[o].ry = 0x80;
            if (j < CE_TAP_FRAMES) out[o].buttons = m[k].buttons;
        }
    }
    for (uint32_t i = 0; i < o; i++) out[i].t_us = (uint32_t)((uint64_t)i * 1000000u / CE_HZ_FRAMES);
    return o;
}

// Seconds with two decimals from frames: hundredths of a second, rounded to the nearest.
static inline uint32_t ce_hundredths(uint32_t frames) { return (frames * 100u + CE_HZ_FRAMES / 2u) / CE_HZ_FRAMES; }

// Short button names for the editor rows ("Sq+Dn+Rt"); unknown bits show as "?".
static inline void ce_button_name(char *out, size_t n, uint32_t b, int shortform) {
    static const struct { uint32_t bit; const char *shrt, *full; } T[] = {
        {0x00000010u, "Up", "Up"}, {0x00000040u, "Dn", "Down"}, {0x00000080u, "Lf", "Left"}, {0x00000020u, "Rt", "Right"},
        {0x00000400u, "L1", "L1"}, {0x00000800u, "R1", "R1"}, {0x00000100u, "L2", "L2"}, {0x00000200u, "R2", "R2"},
        {0x00001000u, "Tri", "Triangle"}, {0x00002000u, "Circ", "Circle"}, {0x00004000u, "X", "X"}, {0x00008000u, "Sq", "Square"},
    };
    static const uint32_t KNOWN = 0x0010u | 0x0040u | 0x0080u | 0x0020u | 0x0400u | 0x0800u | 0x0100u | 0x0200u |
                                  0x1000u | 0x2000u | 0x4000u | 0x8000u;
    size_t used = 0;
    out[0] = 0;
    for (size_t i = 0; i < sizeof(T) / sizeof(T[0]); i++) {
        if (!(b & T[i].bit)) continue;
        const char *s = shortform ? T[i].shrt : T[i].full;
        if (used && used + 1 < n) out[used++] = '+';
        for (; *s && used + 1 < n; s++) out[used++] = *s;
        out[used] = 0;
    }
    if (b & ~KNOWN & CE_BTN_MASK) {                       // a bit this table does not name
        if (used && used + 1 < n) out[used++] = '+';
        if (used + 1 < n) out[used++] = '?';
        out[used] = 0;
    }
    if (!used && n > 1) { out[0] = '-'; out[1] = 0; }
}

// v2.18 builder row name: "Up+Right + X", "Up", "X" (plain words, no arrow glyphs). Dir and button in one step.
static inline void ce_step_name(char *out, size_t n, uint32_t buttons) {
    char d[32], b[32];
    ce_button_name(d, sizeof(d), buttons & 0x00F0u, 0);     // direction bits only
    ce_button_name(b, sizeof(b), buttons & ~0x00F0u & CE_BTN_MASK, 0);
    if (!(buttons & 0x00F0u)) snprintf(out, n, "%s", b);
    else if (!(buttons & ~0x00F0u & CE_BTN_MASK)) snprintf(out, n, "%s", d);
    else snprintf(out, n, "%s + %s", d, b);
}

#endif
