// overlay_draw.h — draws the mod menu straight into a PS4 VideoOut display buffer.
// Plain C, no PS4 calls: the same code runs in the plugin and in the host tests.
//
// Display buffers registered with sceVideoOutRegisterBuffers use tiling mode TILE (0) or LINEAR (1).
// TILE = GCN "Display2DThin": 8x8 micro tiles (display micro-tiling) inside macro tiles, with pipe
// and bank bits XOR-swizzled into the address. For 32 bpp the micro tile is 256 bytes = the pipe
// interleave size, which gives a closed form per pixel:
//   PS4 (Liverpool, P8_32x32_16x16, 16 banks, bank w/h 1/1, macro aspect 2, macro tile 128x64 = 32 KB)
//     addr = elem*4 | pipe<<8 | bank<<11 | macro_index<<15
//   PS4 Pro "Neo" mode (16 pipes, 8 banks, bank height 2, aspect 1, macro tile 128x128 = 64 KB)
//     addr = elem*4 | pipe<<8 | bank<<12 | (macro_index*2 + ((y>>3)&1))<<15
//   elem = x0 | x1<<1 | y0<<2 | x2<<3 | y1<<4 | y2<<5           (display micro tiling, 32 bpp)
//   macro_index = (y / macro_h) * (pitch / 128) + x / 128
// Written by Tab from AMD addrlib (siaddrlib/egbaddrlib) formulas; checked bit-for-bit in the host
// tests against shadPS4's own detilers (TileManager32 2024, tiling.comp 2025) — see hosttest/tiling_test.cpp.
#ifndef TK_OVERLAY_DRAW_H
#define TK_OVERLAY_DRAW_H
#include <stdint.h>
#include <stddef.h>
#include <string.h>
#include "pq_lut.h"

enum { OV_LAYOUT_LINEAR = 0, OV_LAYOUT_PS4, OV_LAYOUT_PRO_A, OV_LAYOUT_PRO_B, OV_LAYOUT_COUNT };

#define OV_FMT_A8R8G8B8_SRGB    0x80000000u
#define OV_FMT_A8B8G8R8_SRGB    0x80002200u
#define OV_FMT_A2R10G10B10      0x88060000u
#define OV_FMT_A2R10G10B10_SRGB 0x88000000u
#define OV_FMT_A2R10G10B10_PQ   0x88740000u   // BT.2020 + ST 2084 (HDR)
#define OV_FMT_A16R16G16B16_F   0xC1060000u   // 64 bpp, not supported

static inline int ov_format_supported(uint32_t f) {
    return f == OV_FMT_A8R8G8B8_SRGB || f == OV_FMT_A8B8G8R8_SRGB || f == OV_FMT_A2R10G10B10 ||
           f == OV_FMT_A2R10G10B10_SRGB || f == OV_FMT_A2R10G10B10_PQ;
}
static inline const char *ov_format_name(uint32_t f) {
    switch (f) {
    case OV_FMT_A8R8G8B8_SRGB: return "A8R8G8B8";
    case OV_FMT_A8B8G8R8_SRGB: return "A8B8G8R8";
    case OV_FMT_A2R10G10B10: return "A2R10G10B10";
    case OV_FMT_A2R10G10B10_SRGB: return "A2R10G10B10 sRGB";
    case OV_FMT_A2R10G10B10_PQ: return "A2R10G10B10 HDR";
    case OV_FMT_A16R16G16B16_F: return "RGBA16F";
    default: return "unknown";
    }
}
static inline const char *ov_layout_name(int l) {
    static const char *n[] = {"linear", "PS4 tiled", "Pro tiled A", "Pro tiled B"};
    return (l >= 0 && l < OV_LAYOUT_COUNT) ? n[l] : "?";
}

// Pack an sRGB colour for the buffer's pixel format (opaque alpha).
static inline uint32_t ov_pack(uint32_t f, uint8_t r, uint8_t g, uint8_t b) {
    switch (f) {
    case OV_FMT_A8R8G8B8_SRGB: return 0xff000000u | (uint32_t)r << 16 | (uint32_t)g << 8 | b;
    case OV_FMT_A8B8G8R8_SRGB: return 0xff000000u | (uint32_t)b << 16 | (uint32_t)g << 8 | r;
    case OV_FMT_A2R10G10B10:
    case OV_FMT_A2R10G10B10_SRGB: {
        uint32_t r10 = (r * 1023u + 127u) / 255u, g10 = (g * 1023u + 127u) / 255u, b10 = (b * 1023u + 127u) / 255u;
        return 3u << 30 | r10 << 20 | g10 << 10 | b10;
    }
    case OV_FMT_A2R10G10B10_PQ:
        return 3u << 30 | (uint32_t)OV_PQ10[r] << 20 | (uint32_t)OV_PQ10[g] << 10 | OV_PQ10[b];
    default: return 0;
    }
}

static inline uint32_t ov_bit(uint32_t v, int n) { return (v >> n) & 1u; }

// Display micro-tiling element index, 32 bpp.
static inline uint32_t ov_elem(uint32_t x, uint32_t y) {
    return ov_bit(x, 0) | ov_bit(x, 1) << 1 | ov_bit(y, 0) << 2 | ov_bit(x, 2) << 3 | ov_bit(y, 1) << 4 | ov_bit(y, 2) << 5;
}
static inline uint32_t ov_macro_h(int layout) { return layout == OV_LAYOUT_PS4 ? 64u : 128u; }

// Byte offset of the micro tile holding (x, y); x and y may be anywhere in that 8x8 tile.
static inline uint64_t ov_microtile_base(int layout, uint32_t x, uint32_t y, uint32_t pitch) {
    const uint32_t mh = ov_macro_h(layout);
    const uint64_t macro = (uint64_t)(y / mh) * (pitch / 128u) + x / 128u;
    uint32_t pipe, bank;
    if (layout == OV_LAYOUT_PS4) {
        pipe = (ov_bit(x, 3) ^ ov_bit(y, 3) ^ ov_bit(x, 4)) | (ov_bit(x, 4) ^ ov_bit(y, 4)) << 1 |
               (ov_bit(x, 5) ^ ov_bit(y, 5)) << 2;
        bank = (ov_bit(x, 6) ^ ov_bit(y, 6)) | (ov_bit(x, 7) ^ ov_bit(y, 5) ^ ov_bit(y, 6)) << 1 |
               (ov_bit(x, 8) ^ ov_bit(y, 4)) << 2 | (ov_bit(x, 9) ^ ov_bit(y, 3)) << 3;
        return (uint64_t)pipe << 8 | (uint64_t)bank << 11 | macro << 15;
    }
    if (layout == OV_LAYOUT_PRO_A)   // shadPS4 2024 TileManager32 is_neo pipe equation
        pipe = (ov_bit(x, 3) ^ ov_bit(y, 3) ^ ov_bit(x, 4)) | (ov_bit(x, 4) ^ ov_bit(y, 4)) << 1 |
               (ov_bit(x, 5) ^ ov_bit(y, 5)) << 2 | (ov_bit(x, 6) ^ ov_bit(y, 5)) << 3;
    else                             // AMD addrlib ADDR_PIPECFG_P16_32x32_8x16
        pipe = (ov_bit(x, 4) ^ ov_bit(y, 3)) | (ov_bit(x, 3) ^ ov_bit(y, 4)) << 1 |
               (ov_bit(x, 5) ^ ov_bit(y, 6)) << 2 | (ov_bit(x, 6) ^ ov_bit(y, 5)) << 3;
    bank = (ov_bit(x, 7) ^ ov_bit(y, 6)) | (ov_bit(x, 8) ^ ov_bit(y, 5) ^ ov_bit(y, 6)) << 1 | (ov_bit(x, 9) ^ ov_bit(y, 4)) << 2;
    return (uint64_t)pipe << 8 | (uint64_t)bank << 12 | (macro * 2u + ov_bit(y, 3)) << 15;
}

// Byte offset of pixel (x, y) in a buffer of the given layout.
static inline uint64_t ov_pixel_offset(int layout, uint32_t x, uint32_t y, uint32_t pitch) {
    if (layout == OV_LAYOUT_LINEAR) return ((uint64_t)y * pitch + x) * 4u;
    return ov_microtile_base(layout, x, y, pitch) | (uint64_t)ov_elem(x, y) * 4u;
}

// Rows the buffer really spans (tiled surfaces are padded to whole macro tiles).
static inline uint32_t ov_padded_height(int layout, uint32_t height) {
    if (layout == OV_LAYOUT_LINEAR) return height;
    uint32_t mh = ov_macro_h(layout);
    return (height + mh - 1) / mh * mh;
}
static inline uint64_t ov_surface_bytes(int layout, uint32_t pitch, uint32_t height) {
    return (uint64_t)pitch * ov_padded_height(layout, height) * 4u;
}

// ------------------------------------------------------------------ menu canvas
// The menu is rasterised once per state change into a small 8-bit canvas (palette index per pixel,
// 0 = leave the game's pixel alone), then copied into the display buffer every frame. No reads from
// GPU memory (they are uncached and very slow): the "semi-transparent" panel is a 50% checkerboard
// of dark pixels, which reads as a dark tint at native resolution.
enum { PAL_NONE = 0, PAL_BG, PAL_TITLE_BAR, PAL_WHITE, PAL_SEL_BAR, PAL_DARK, PAL_TEXT, PAL_GREEN, PAL_RED,
       PAL_GREY, PAL_DGREEN, PAL_DRED, PAL_DGREY, PAL_FOOT, PAL_ACCENT, PAL_YELLOW, PAL_DYELLOW, PAL_COUNT };
static const uint8_t OV_PAL_RGB[PAL_COUNT][3] = {
    {0, 0, 0},       {10, 10, 14},   {178, 18, 36},   {255, 255, 255}, {236, 236, 236},
    {18, 18, 22},    {226, 226, 230}, {96, 226, 128}, {255, 96, 96},   {196, 196, 200},
    {0, 128, 52},    {190, 16, 32},  {70, 70, 76},    {165, 165, 172}, {230, 40, 60},   {255, 200, 64},  {150, 96, 0},
};

#define OV_MAX_ROWS 16       // v2.18: the combo builder shows 13 rows (8 steps + 5 inputs)
typedef struct {
    int rows;
    int selected;
    const char *label[OV_MAX_ROWS];
    const char *value[OV_MAX_ROWS];
    int value_kind[OV_MAX_ROWS];      // 0 neutral, 1 good (green), 2 bad (red), 3 damage % (yellow, v2.12)
    const char *title, *footer;
    // v2.13 combo-slot strip: one line under row strip_row showing slots 1..10
    // (filled = green, empty = grey, selected = white box). strip = 0: no strip (old callers, memset 0).
    int strip, strip_row, strip_sel;
    uint32_t strip_full;              // bit i set = slot i+1 holds a combo
    int plain_rows;                   // v2.18: rows below this index show their selected value without "< >" (long step rows)
} OvMenuView;

typedef struct {
    uint32_t scale, foot_scale;
    uint32_t w, h;              // panel size in pixels
    uint32_t x, y;              // panel position in the display buffer
} OvGeom;

static inline int ov_geom_strip(OvGeom *g, uint32_t width, uint32_t height, int rows, int strip) {
    uint32_t s = height / 360u;
    if (s < 1) s = 1;
    if (s > 6) s = 6;
    g->scale = s;
    g->foot_scale = (2u * s) / 3u ? (2u * s) / 3u : 1u;
    g->w = 240u * s;
    g->h = 16u * s + 4u * s + (uint32_t)rows * 14u * s + (strip ? 13u * s : 0u) + 4u * s + 8u * g->foot_scale + 6u * s;
    g->x = height / 18u;
    g->y = height > g->h ? (height - g->h) / 2u : 0;
    return g->x + g->w <= width && g->y + g->h <= height;
}
static inline int ov_geom(OvGeom *g, uint32_t width, uint32_t height, int rows) { return ov_geom_strip(g, width, height, rows, 0); }

// v2.14: same panel size, placed at the BOTTOM left and snapped to whole 8x8 micro tiles.
// Why the bottom: the overlay is drawn by the CPU into the buffer that has just gone on screen
// (Tekken flips from the GPU, so there is no earlier moment when the frame is finished and not yet
// shown). The scan-out reads the buffer top to bottom over ~16 ms; rows it reaches before the draw
// lands show the game's frame without the menu (yahya's video: the title and top rows flickered,
// the lower rows stayed). At the bottom the scan-out reaches the panel ~10 ms after the flip instead
// of ~6 ms (v2.13, vertically centred and taller than v2.12's), so a late draw still lands in time.
// x/y/h multiples of 8 = every micro tile is whole (fast path in ov_blit_fast); the extra rows (<8)
// at the bottom of the canvas are plain background.
static inline int ov_geom_bottom(OvGeom *g, uint32_t width, uint32_t height, int rows, int strip) {
    ov_geom_strip(g, width, height, rows, strip);
    g->h = (g->h + 7u) & ~7u;
    g->x = (height / 18u) & ~7u;
    const uint32_t margin = height / 18u;
    g->y = height > g->h + margin ? ((height - g->h - margin) & ~7u) : 0;
    return g->x + g->w <= width && g->y + g->h <= height;
}

// v2.18: the combo builder's panel is wider (wpct percent of the normal width) so a step row keeps its value
// clear of its label on a TV; the height, the bottom placement and the scan-out timing are ov_geom_bottom's.
static inline int ov_geom_bottom_wide(OvGeom *g, uint32_t width, uint32_t height, int rows, int strip, uint32_t wpct) {
    const int ok = ov_geom_bottom(g, width, height, rows, strip);
    g->w = (g->w * wpct) / 100u;
    return ok && g->x + g->w <= width;
}

static inline void ov_fill(uint8_t *cv, uint32_t cw, uint32_t ch, int x, int y, int w, int h, uint8_t c) {
    for (int j = y; j < y + h; j++) {
        if (j < 0 || j >= (int)ch) continue;
        for (int i = x; i < x + w; i++)
            if (i >= 0 && i < (int)cw) cv[(uint32_t)j * cw + (uint32_t)i] = c;
    }
}
static inline int ov_text(uint8_t *cv, uint32_t cw, uint32_t ch, int x, int y, uint32_t s, const char *t, uint8_t c,
                          const unsigned char font[][8]) {
    for (; *t; t++, x += 8 * (int)s) {
        unsigned char k = (unsigned char)*t;
        if (k > 127) k = '?';
        for (int row = 0; row < 8; row++)
            for (int col = 0; col < 8; col++)
                if (font[k][row] & (1u << col)) ov_fill(cv, cw, ch, x + col * (int)s, y + row * (int)s, (int)s, (int)s, c);
    }
    return x;
}
static inline int ov_text_w(const char *t, uint32_t s) { return (int)(strlen(t) * 8u * s); }

// Rasterise the menu into cv (g->w * g->h bytes).
// opaque = 0: see-through 50% checkerboard background (v2.10-v2.13); opaque = 1: solid dark background
// (v2.14: every panel pixel is written, so the fast blit can store whole 256-byte micro tiles).
static inline void ov_render_menu_bg(uint8_t *cv, const OvGeom *g, const OvMenuView *v, const unsigned char font[][8], int opaque) {
    const uint32_t s = g->scale, W = g->w, H = g->h;
    for (uint32_t j = 0; j < H; j++)
        for (uint32_t i = 0; i < W; i++) cv[j * W + i] = (opaque || ((i + j) & 1u)) ? PAL_BG : PAL_NONE;
    const int th = 16 * (int)s;
    ov_fill(cv, W, H, 0, 0, (int)W, th, PAL_TITLE_BAR);
    ov_fill(cv, W, H, 0, th, (int)W, (int)(s > 1 ? s / 2 + 1 : 1), PAL_ACCENT);
    ov_text(cv, W, H, ((int)W - ov_text_w(v->title, s)) / 2, 4 * (int)s, s, v->title, PAL_WHITE, font);
    int y = th + 4 * (int)s;
    for (int r = 0; r < v->rows && r < OV_MAX_ROWS; r++, y += 14 * (int)s) {
        const int sel = r == v->selected;
        if (sel) ov_fill(cv, W, H, 2 * (int)s, y, (int)W - 4 * (int)s, 14 * (int)s, PAL_SEL_BAR);
        ov_text(cv, W, H, 8 * (int)s, y + 3 * (int)s, s, v->label[r], sel ? PAL_DARK : PAL_TEXT, font);
        char val[40];
        const char *vt = v->value[r] ? v->value[r] : "";
        if (sel && r >= v->plain_rows) { size_t n = strlen(vt); if (n > 30) n = 30; val[0] = '<'; val[1] = ' '; memcpy(val + 2, vt, n); val[n + 2] = ' '; val[n + 3] = '>'; val[n + 4] = 0; }
        else { size_t n = strlen(vt); if (n > 38) n = 38; memcpy(val, vt, n); val[n] = 0; }
        uint8_t c = v->value_kind[r] == 1 ? (sel ? PAL_DGREEN : PAL_GREEN) : v->value_kind[r] == 2 ? (sel ? PAL_DRED : PAL_RED)
                  : v->value_kind[r] == 3 ? (sel ? PAL_DYELLOW : PAL_YELLOW) : (sel ? PAL_DGREY : PAL_GREY);
        ov_text(cv, W, H, (int)W - 8 * (int)s - ov_text_w(val, s), y + 3 * (int)s, s, val, c, font);
        if (v->strip && r == v->strip_row) {   // v2.13: slots 1..10 at a glance
            const int sy = y + 14 * (int)s, cw = ((int)W - 16 * (int)s) / 10;
            for (int k = 0; k < 10; k++) {
                char num[3] = {(char)(k == 9 ? '1' : '1' + k), (char)(k == 9 ? '0' : 0), 0};
                const int cx = 8 * (int)s + k * cw, full = (v->strip_full >> k) & 1u, cur = k == v->strip_sel;
                if (cur) ov_fill(cv, W, H, cx + (int)s, sy, cw - 2 * (int)s, 12 * (int)s, PAL_WHITE);
                else if (full) ov_fill(cv, W, H, cx + (int)s, sy, cw - 2 * (int)s, 12 * (int)s, PAL_DGREEN);
                const uint8_t tc = cur ? (full ? PAL_DGREEN : PAL_DGREY) : full ? PAL_WHITE : PAL_DGREY;
                ov_text(cv, W, H, cx + (cw - ov_text_w(num, s)) / 2, sy + 2 * (int)s, s, num, tc, font);
            }
            y += 13 * (int)s;
        }
    }
    y += 4 * (int)s;
    ov_fill(cv, W, H, 8 * (int)s, y - 2 * (int)s, (int)W - 16 * (int)s, (int)(s > 1 ? s / 2 : 1), PAL_DGREY);
    ov_text(cv, W, H, 8 * (int)s, y + 3 * (int)s, g->foot_scale, v->footer, PAL_FOOT, font);
}

static inline void ov_render_menu(uint8_t *cv, const OvGeom *g, const OvMenuView *v, const unsigned char font[][8]) {
    ov_render_menu_bg(cv, g, v, font, 0);
}

// Copy the canvas into the display buffer at (g->x, g->y). Writes only, never reads the buffer.
// Every store is bounds-checked against `size` (bytes of the buffer that are known to be mapped).
// Returns the number of pixels written.
static inline uint32_t ov_blit(uint8_t *buf, uint64_t size, int layout, uint32_t pitch, uint32_t fmt,
                               const uint8_t *cv, const OvGeom *g) {
    uint32_t pal[PAL_COUNT];
    for (int i = 0; i < PAL_COUNT; i++) pal[i] = ov_pack(fmt, OV_PAL_RGB[i][0], OV_PAL_RGB[i][1], OV_PAL_RGB[i][2]);
    const uint32_t x0 = g->x, y0 = g->y, x1 = g->x + g->w, y1 = g->y + g->h;
    uint32_t n = 0;
    if (layout == OV_LAYOUT_LINEAR) {
        for (uint32_t y = y0; y < y1; y++) {
            const uint8_t *src = cv + (size_t)(y - y0) * g->w;
            uint64_t row = (uint64_t)y * pitch * 4u;
            for (uint32_t x = x0; x < x1; x++) {
                uint8_t c = src[x - x0];
                uint64_t off = row + (uint64_t)x * 4u;
                if (c && off + 4 <= size) { *(volatile uint32_t *)(buf + off) = pal[c]; n++; }
            }
        }
        return n;
    }
    // Tiled: walk whole 8x8 micro tiles; inside one, element order = ascending addresses (256 B run).
    static const uint8_t ex[64] = {0,1,2,3,0,1,2,3,4,5,6,7,4,5,6,7,0,1,2,3,0,1,2,3,4,5,6,7,4,5,6,7,
                                   0,1,2,3,0,1,2,3,4,5,6,7,4,5,6,7,0,1,2,3,0,1,2,3,4,5,6,7,4,5,6,7};
    static const uint8_t ey[64] = {0,0,0,0,1,1,1,1,0,0,0,0,1,1,1,1,2,2,2,2,3,3,3,3,2,2,2,2,3,3,3,3,
                                   4,4,4,4,5,5,5,5,4,4,4,4,5,5,5,5,6,6,6,6,7,7,7,7,6,6,6,6,7,7,7,7};
    for (uint32_t ty = y0 & ~7u; ty < y1; ty += 8) {
        for (uint32_t tx = x0 & ~7u; tx < x1; tx += 8) {
            const uint64_t base = ov_microtile_base(layout, tx, ty, pitch);
            if (base + 256 > size) continue;
            volatile uint32_t *dst = (volatile uint32_t *)(buf + base);
            for (uint32_t e = 0; e < 64; e++) {
                const uint32_t x = tx + ex[e], y = ty + ey[e];
                if (x < x0 || x >= x1 || y < y0 || y >= y1) continue;
                uint8_t c = cv[(size_t)(y - y0) * g->w + (x - x0)];
                if (c) { dst[e] = pal[c]; n++; }
            }
        }
    }
    return n;
}

// v2.14 fast copy. Same result as ov_blit for any canvas (host-tested pixel for pixel on all layouts),
// but built for speed: compiled at -O2 in its own file (ov_fast.c; the rest of the plugin stays as it
// was built), and a micro tile that lies fully inside the panel and has no transparent pixel is
// written as one run of 32 ascending 8-byte stores (256 bytes = whole write-combining lines) instead
// of 64 bounds-checked 4-byte ones. Writes only, never reads the buffer; every store stays below `size`.
static inline uint32_t ov_blit_fast(uint8_t *buf, uint64_t size, int layout, uint32_t pitch, uint32_t fmt,
                                    const uint8_t *cv, const OvGeom *g) {
    uint32_t pal[PAL_COUNT];
    for (int i = 0; i < PAL_COUNT; i++) pal[i] = ov_pack(fmt, OV_PAL_RGB[i][0], OV_PAL_RGB[i][1], OV_PAL_RGB[i][2]);
    const uint32_t W = g->w, x0 = g->x, y0 = g->y, x1 = g->x + g->w, y1 = g->y + g->h;
    uint32_t n = 0;
    if (layout == OV_LAYOUT_LINEAR) {
        for (uint32_t y = y0; y < y1; y++) {
            const uint8_t *src = cv + (size_t)(y - y0) * W;
            const uint64_t row = (uint64_t)y * pitch * 4u + (uint64_t)x0 * 4u;
            if (row + (uint64_t)W * 4u <= size) {
                volatile uint32_t *d = (volatile uint32_t *)(buf + row);
                for (uint32_t i = 0; i < W; i++) { const uint8_t c = src[i]; if (c) { d[i] = pal[c]; n++; } }
            } else {
                for (uint32_t i = 0; i < W; i++) {
                    const uint8_t c = src[i]; const uint64_t off = row + (uint64_t)i * 4u;
                    if (c && off + 4 <= size) { *(volatile uint32_t *)(buf + off) = pal[c]; n++; }
                }
            }
        }
        return n;
    }
    static const uint8_t fx[64] = {0,1,2,3,0,1,2,3,4,5,6,7,4,5,6,7,0,1,2,3,0,1,2,3,4,5,6,7,4,5,6,7,
                                   0,1,2,3,0,1,2,3,4,5,6,7,4,5,6,7,0,1,2,3,0,1,2,3,4,5,6,7,4,5,6,7};
    static const uint8_t fy[64] = {0,0,0,0,1,1,1,1,0,0,0,0,1,1,1,1,2,2,2,2,3,3,3,3,2,2,2,2,3,3,3,3,
                                   4,4,4,4,5,5,5,5,4,4,4,4,5,5,5,5,6,6,6,6,7,7,7,7,6,6,6,6,7,7,7,7};
    uint32_t rel[64];
    for (int e = 0; e < 64; e++) rel[e] = (uint32_t)fy[e] * W + fx[e];
    for (uint32_t ty = y0 & ~7u; ty < y1; ty += 8) {
        const int rows_in = ty >= y0 && ty + 8 <= y1;
        for (uint32_t tx = x0 & ~7u; tx < x1; tx += 8) {
            const uint64_t base = ov_microtile_base(layout, tx, ty, pitch);
            if (base + 256 > size) continue;
            volatile uint32_t *dst = (volatile uint32_t *)(buf + base);
            if (rows_in && tx >= x0 && tx + 8 <= x1) {
                const uint8_t *s = cv + (size_t)(ty - y0) * W + (tx - x0);
                uint32_t px[64]; uint32_t holes = 0;
                for (int e = 0; e < 64; e++) { const uint8_t c = s[rel[e]]; holes |= (c == 0); px[e] = pal[c]; }
                if (!holes) {
                    volatile uint64_t *d64 = (volatile uint64_t *)(buf + base);
                    for (int k = 0; k < 32; k++) d64[k] = (uint64_t)px[2 * k] | (uint64_t)px[2 * k + 1] << 32;
                    n += 64;
                } else {
                    for (int e = 0; e < 64; e++) if (s[rel[e]]) { dst[e] = px[e]; n++; }
                }
                continue;
            }
            for (int e = 0; e < 64; e++) {   // edge tile (panel not on the 8x8 grid): pixel by pixel
                const uint32_t x = tx + fx[e], y = ty + fy[e];
                if (x < x0 || x >= x1 || y < y0 || y >= y1) continue;
                const uint8_t c = cv[(size_t)(y - y0) * W + (x - x0)];
                if (c) { dst[e] = pal[c]; n++; }
            }
        }
    }
    return n;
}
#endif
