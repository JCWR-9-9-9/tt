#ifndef TK_MENU_LOGIC_H
#define TK_MENU_LOGIC_H
#include <stdint.h>
// Mod-menu UI state machine (plain C, host-testable). Merged into tekken_combo_macro.
// Add further items here (enum + value table + handler in main.c).
// v2.12: values are the cave flag bytes. 0-2 = TLH's (unchanged), 3-5 = damage taken scaled to 80/60/50 %.
// v2.13: two new rows, Combo slot (1..10) and Game speed (100/75/50/33/25 %); Overlay stays last.
// v2.15: 6-10 = damage taken scaled UP to 105/110/120/150/200 % (P2 on 110 % = your hits on P2 do 10 % more).
// v2.17 (menu v1.09): Triangle on the Combo slot row opens the Combo tools pages: Edit timing (gap editor for
// the selected slot) and Build a combo (maker). Pages are PG_*; O goes back one page. Edits are held in RAM
// until X saves them; O, or closing the menu, writes nothing. main.c carries out what menu_step asks (act).
// v2.18 (menu v2.00): the maker is ONE big screen. Each row is one step: a direction, a button, or both
// (Up+Right + X). Direction and Button are picked on the same screen (Left/Right), the gap for the next step
// is 0.01 s steps (default 0.20 s), X adds it; the list scrolls (8 rows) with a count. Triangle deletes the
// selected step, Left/Right on a step edits its gap, Save picks a slot, O cancels and writes nothing.
enum { HEALTH_NORMAL, HEALTH_MAX, HEALTH_MIN, HEALTH_DMG80, HEALTH_DMG60, HEALTH_DMG50,
       HEALTH_DMG105, HEALTH_DMG110, HEALTH_DMG120, HEALTH_DMG150, HEALTH_DMG200, HEALTH_CHOICES };
enum { ITEM_P1_HEALTH, ITEM_P2_HEALTH, ITEM_SLOT, ITEM_SPEED, ITEM_OVERLAY, ITEM_COUNT };
#define SLOT_COUNT 10
// Game speed choices as exact fractions num/den of normal speed (index 0 = 100 %, the default).
enum { SPEED_100, SPEED_75, SPEED_50, SPEED_33, SPEED_25, SPEED_CHOICES };
static const uint32_t SPEED_NUM[SPEED_CHOICES] = {1, 3, 1, 1, 1};
static const uint32_t SPEED_DEN[SPEED_CHOICES] = {1, 4, 2, 3, 4};
static inline const char *menu_speed_name(int v) {
  static const char *names[] = {"100%", "75%", "50%", "33%", "25%"};
  return names[v >= 0 && v < SPEED_CHOICES ? v : 0];
}
// On-screen overlay layout (v2.10). Auto picks from the buffer's tiling mode and PS4 / PS4 Pro mode;
// the others force one layout so it can be fixed from the menu if Auto draws garbage. Off = notifications.
enum { OVL_AUTO, OVL_PS4, OVL_PRO_A, OVL_PRO_B, OVL_LINEAR, OVL_OFF, OVL_CHOICES };

#define MB_L3       0x00000002u
#define MB_OPTIONS  0x00000008u
#define MB_UP       0x00000010u
#define MB_RIGHT    0x00000020u
#define MB_DOWN     0x00000040u
#define MB_LEFT     0x00000080u
#define MB_CIRCLE   0x00002000u
#define MB_CROSS    0x00004000u
#define MB_SQUARE   0x00008000u
#define MB_OPEN_HOLD MB_L3   // v2.11: hold L3, then press OPTIONS (the touchpad is the game's again)
#define MB_TRIANGLE 0x00001000u   // v2.17: the menu reads the face buttons
#define MB_L1       0x00000400u
#define MB_R1       0x00000800u

// v2.17 combo tools: pages, requests to main.c, and limits (the editor and the maker share them).
enum { PG_MAIN, PG_TOOLS, PG_EDIT, PG_MAKE, PG_MAKE_SLOT };
enum { ACT_NONE, ACT_EDIT_OPEN, ACT_EDIT_GAP, ACT_EDIT_RESET, ACT_EDIT_SAVE, ACT_EDIT_CANCEL,
       ACT_MAKE_CANCEL, ACT_MAKE_SAVE, ACT_MAKE_NOTE };
// v2.18 ACT_MAKE_NOTE argument: why an Add or Save did nothing (main.c shows the words).
enum { MK_NOTE_EMPTY = 1, MK_NOTE_FULL, MK_NOTE_NONE };
#define CE_HZ_FRAMES   60u     // the pad grid: one step per game frame
#define CE_TAP_FRAMES  3u      // maker press length: 50 ms
#define CE_MIN_GAP     4u      // maker: tap + one released frame (0.067 s)
#define CE_GAP_MAX     300u    // 5.00 s, the largest gap the editor and the maker accept
#define CE_MAX_STEPS   18000u  // main.c MAX_STEPS (5 min at 60 samples/s)
#define CE_MAKE_MAX    40u     // presses in one maker combo
#define CE_EDIT_ROWS   5u      // presses shown at once in the editor
#define CE_MAKE_VIS    8u      // v2.18 builder: step rows visible at once (the list scrolls)
#define CE_MAKE_INPUTS 5u      // v2.18 builder input rows: Direction, Button, Gap, Add step, Save
#define CE_MAKE_ROWS   (CE_MAKE_VIS + CE_MAKE_INPUTS)
#define CE_GAP_CS_MIN  7u      // maker gap, hundredths of a second: 0.07 s = CE_MIN_GAP frames (4)
#define CE_GAP_CS_MAX  500u    // 5.00 s
#define CE_GAP_CS_DEF  20u     // 0.20 s, the default gap of a new step
#define CE_GAP_CS_BIG  10u     // L1 / R1 on a gap: 0.10 s (Left / Right: 0.01 s)
// v2.18 builder choices. Direction goes round the pad clockwise so Up+Right is two Rights from none.
#define CE_DIR_OPTS    9u
static const uint32_t CE_DIR_MASK[CE_DIR_OPTS] = {
    0x0000u, 0x0010u, 0x0030u, 0x0020u, 0x0060u, 0x0040u, 0x00C0u, 0x0080u, 0x0090u};
static const char *CE_DIR_NAME[CE_DIR_OPTS] = {
    "none", "Up", "Up+Right", "Right", "Down+Right", "Down", "Down+Left", "Left", "Up+Left"};
#define CE_BTN_OPTS    7u
static const uint32_t CE_BTN_BITS[CE_BTN_OPTS] = {0x0000u, 0x4000u, 0x2000u, 0x8000u, 0x1000u, 0x0400u, 0x0800u};
static const char *CE_BTN_NAME[CE_BTN_OPTS] = {"none", "X", "Circle", "Square", "Triangle", "L1", "R1"};

enum { MENU_PASS = 0, MENU_SWALLOW = 1 };

typedef struct { uint32_t buttons, cs; } MkPress;   // v2.18 maker: one step (direction | button bits) and its gap, hundredths of a second

typedef struct {
  int open, selected, health[2];
  int ovl, ovl_changed;    // overlay layout choice (OVL_*)
  int confirm;             // X pressed this sample
  int slot, slot_changed;  // v2.13: selected combo slot 0..9 (shown as 1..10)
  int speed, speed_changed;// v2.13: SPEED_* index, never saved (every game launch starts at 100 %)
  int clear_armed;         // Square pressed once on the slot row: waiting for the second Square
  int clear_now;           // second Square: clear the selected slot (this sample)
  int32_t owner;          // pad handle that opened the menu
  int changed, health_changed, opened_now;
  int hint, hint_shown;   // one-time "how to open" hint on a plain OPTIONS press
  // v2.17 combo tools
  int page, sub;          // PG_* and the cursor row on that page
  int ed_n, ed_cur;       // editor: presses in the slot, cursor press (set by main.c on open)
  int act, act_arg;       // request for main.c this sample (ACT_*), argument (gap frames or slot)
  MkPress mk[CE_MAKE_MAX];// maker: steps entered so far
  int mk_n, mk_dir, mk_btn, mk_gap, mk_slot, mk_armed, mk_top;   // v2.18: mk_gap = gap for the next step (cs), mk_top = first visible step
  uint32_t full_mask;     // bit i = slot i+1 holds a combo (set by main.c before each sample)
} Menu;

typedef struct {           // per pad handle
  uint32_t prev;
  int swallow;             // after open/close: hide input until every button is released
} MenuPad;

static inline const char *menu_value(int v) {
  static const char *names[] = {"Normal", "Infinite", "1-Hit", "Damage 80%", "Damage 60%", "Damage 50%",
                                "Damage 105%", "Damage 110%", "Damage 120%", "Damage 150%", "Damage 200%"};
  return names[v >= 0 && v < HEALTH_CHOICES ? v : 0];
}
// Value colour on the overlay: 1 green (Infinite), 2 red (1-Hit), 3 yellow (Damage below 100 %),
// v2.15: Damage above 100 % is red too (that player takes MORE damage), 0 grey (Normal).
static inline int menu_value_kind(int v) {
  return v == HEALTH_MAX ? 1 : v == HEALTH_MIN ? 2 : (v >= HEALTH_DMG80 && v <= HEALTH_DMG50) ? 3
       : (v >= HEALTH_DMG105 && v < HEALTH_CHOICES) ? 2 : 0;
}
static inline const char *menu_ovl_name(int v) {
  static const char *names[] = {"Auto", "PS4", "Pro A", "Pro B", "Linear", "Off"};
  return names[v >= 0 && v < OVL_CHOICES ? v : 0];
}
static inline void menu_init(Menu *m) {
  m->open = m->selected = 0; m->health[0] = m->health[1] = 0; m->owner = -1;
  m->ovl = OVL_AUTO; m->ovl_changed = m->confirm = 0;
  m->slot = 0; m->speed = SPEED_100; m->slot_changed = m->speed_changed = m->clear_armed = m->clear_now = 0;
  m->changed = m->health_changed = m->opened_now = m->hint = m->hint_shown = 0;
  m->page = PG_MAIN; m->sub = 0; m->ed_n = m->ed_cur = 0; m->act = m->act_arg = ACT_NONE;
  m->mk_n = 0; m->mk_dir = 0; m->mk_btn = 0; m->mk_gap = CE_GAP_CS_DEF; m->mk_slot = 0; m->mk_armed = 0;
  m->mk_top = 0; m->full_mask = 0;
}


// v2.18 builder helpers. Gap in hundredths of a second, kept within the limits of the maker.
static inline int mk_clamp_cs(int v) {
  if (v < (int)CE_GAP_CS_MIN) v = (int)CE_GAP_CS_MIN;
  if (v > (int)CE_GAP_CS_MAX) v = (int)CE_GAP_CS_MAX;
  return v;
}
// Scroll window: a step under the cursor is kept in view; an input row shows the newest steps.
static inline void mk_scroll(Menu *m) {
  const int n = m->mk_n, V = (int)CE_MAKE_VIS;
  if (m->sub < n) {
    if (m->sub < m->mk_top) m->mk_top = m->sub;
    if (m->sub >= m->mk_top + V) m->mk_top = m->sub - V + 1;
  } else m->mk_top = n - V;
  if (m->mk_top > n - V) m->mk_top = n - V;
  if (m->mk_top < 0) m->mk_top = 0;
}

// v2.17 combo tools. Plain pad -> state; the work (reading, rebuilding, writing files) is main.c's, asked via act.
static inline int menu_page_step(Menu *m, uint32_t edge) {
  const int dir = ((edge & MB_RIGHT) != 0) - ((edge & MB_LEFT) != 0);               // slot / choice steps
  const int gap = dir + 6 * (((edge & MB_R1) != 0) - ((edge & MB_L1) != 0));        // gap steps: 1 frame, L1/R1 6
  if (edge) m->changed = 1;
  if (m->mk_armed && (edge & ~MB_CROSS)) m->mk_armed = 0;
  switch (m->page) {
  case PG_TOOLS:
    if (edge & MB_UP) m->sub = m->sub > 0 ? m->sub - 1 : 0;
    if (edge & MB_DOWN) m->sub = m->sub < 2 ? m->sub + 1 : 2;
    if (dir && m->sub == 0) { m->slot = (m->slot + SLOT_COUNT + dir) % SLOT_COUNT; m->slot_changed = 1; }
    if (edge & MB_CROSS) {
      if (m->sub == 0) { m->page = PG_EDIT; m->sub = 0; m->act = ACT_EDIT_OPEN; }
      else if (m->sub == 1) { m->page = PG_MAKE; m->sub = 0; m->mk_n = 0; m->mk_dir = 0; m->mk_btn = 0; m->mk_gap = CE_GAP_CS_DEF; m->mk_top = 0; }
      else { m->page = PG_MAIN; m->sub = 0; }
    }
    if (edge & MB_CIRCLE) { m->page = PG_MAIN; m->sub = 0; }
    break;
  case PG_EDIT:
    if ((edge & MB_UP) && m->ed_cur > 0) m->ed_cur--;
    if ((edge & MB_DOWN) && m->ed_cur + 1 < m->ed_n) m->ed_cur++;
    if (gap) { m->act = ACT_EDIT_GAP; m->act_arg = gap; }
    if (edge & MB_TRIANGLE) m->act = ACT_EDIT_RESET;
    if (edge & MB_CROSS) m->act = ACT_EDIT_SAVE;                 // main.c: writes, or stays here when it cannot
    if (edge & MB_CIRCLE) { m->act = ACT_EDIT_CANCEL; m->page = PG_TOOLS; m->sub = 0; }
    break;
  case PG_MAKE: {
    // v2.18 one-screen builder. Cursor rows: steps 0..n-1 (Left/Right = that step's gap, Triangle = delete),
    // then the inputs: Direction, Button, Gap (the next step), Add step, Save. X on Direction, Button, Gap or
    // Add step adds the step; the cursor stays on the row it was on.
    const int n = m->mk_n;
    const int gcs = dir + CE_GAP_CS_BIG * (((edge & MB_R1) != 0) - ((edge & MB_L1) != 0));
    if (edge & MB_UP) m->sub = m->sub > 0 ? m->sub - 1 : 0;
    if (edge & MB_DOWN) m->sub = m->sub < n + (int)CE_MAKE_INPUTS - 1 ? m->sub + 1 : n + (int)CE_MAKE_INPUTS - 1;
    const int in = m->sub - n;                                  // input row 0..4, or < 0 = a step
    if (in < 0) {
        if (gcs) m->mk[m->sub].cs = (uint32_t)mk_clamp_cs((int)m->mk[m->sub].cs + gcs);
        if (edge & MB_TRIANGLE) {                               // delete this step
            for (int i = m->sub; i + 1 < n; i++) m->mk[i] = m->mk[i + 1];
            m->mk_n = n - 1;
            m->sub = m->sub < m->mk_n ? m->sub : (m->mk_n > 0 ? m->mk_n - 1 : m->mk_n);
        }
    } else {
        if (in == 0 && dir) m->mk_dir = (m->mk_dir + (int)CE_DIR_OPTS + dir) % (int)CE_DIR_OPTS;
        if (in == 1 && dir) m->mk_btn = (m->mk_btn + (int)CE_BTN_OPTS + dir) % (int)CE_BTN_OPTS;
        if (in == 2 && gcs) m->mk_gap = mk_clamp_cs(m->mk_gap + gcs);
        if (edge & MB_CROSS) {
            if (in <= 3) {                                      // add the step (Direction, Button, Gap, Add step)
                const uint32_t bits = CE_DIR_MASK[m->mk_dir] | CE_BTN_BITS[m->mk_btn];
                if (!bits) { m->act = ACT_MAKE_NOTE; m->act_arg = MK_NOTE_EMPTY; }
                else if (n >= (int)CE_MAKE_MAX) { m->act = ACT_MAKE_NOTE; m->act_arg = MK_NOTE_FULL; }
                else {
                    m->mk[n].buttons = bits;
                    m->mk[n].cs = (uint32_t)m->mk_gap;
                    m->mk_n = n + 1;
                    m->sub = m->sub + 1;                        // same input row, one row further down the list
                }
            } else if (n > 0) {                                 // Save: pick a slot
                m->page = PG_MAKE_SLOT; m->sub = 0; m->mk_slot = m->slot; m->mk_armed = 0;
            } else { m->act = ACT_MAKE_NOTE; m->act_arg = MK_NOTE_NONE; }
        }
    }
    mk_scroll(m);
    if (edge & MB_CIRCLE) { m->act = ACT_MAKE_CANCEL; m->mk_n = 0; m->page = PG_TOOLS; m->sub = 1; m->mk_top = 0; }
    break;
  }
  case PG_MAKE_SLOT:
    if (edge & MB_UP) m->sub = m->sub > 0 ? m->sub - 1 : 0;
    if (edge & MB_DOWN) m->sub = m->sub < 2 ? m->sub + 1 : 2;
    if (dir && m->sub == 0) { m->mk_slot = (m->mk_slot + SLOT_COUNT + dir) % SLOT_COUNT; m->mk_armed = 0; }
    if (edge & MB_CROSS) {
      if (m->sub == 1) {
        const int full = (m->full_mask >> m->mk_slot) & 1u;
        if (full && !m->mk_armed) m->mk_armed = 1;              // a slot that holds a combo: X again replaces it
        else { m->act = ACT_MAKE_SAVE; m->act_arg = m->mk_slot; }
      } else if (m->sub == 2) { m->page = PG_MAKE; m->sub = m->mk_n + (int)CE_MAKE_INPUTS - 1; }
    }
    if (edge & MB_CIRCLE) { m->page = PG_MAKE; m->sub = m->mk_n + (int)CE_MAKE_INPUTS - 1; m->mk_armed = 0; }
    break;
  default:
    m->page = PG_MAIN;
    break;
  }
  return MENU_SWALLOW;
}

// Feed one REAL pad sample (before anything is stripped). Returns:
//   MENU_SWALLOW      hide the whole sample from the game and from the combo engine
//   MENU_PASS         untouched
static inline int menu_step(Menu *m, MenuPad *p, int32_t handle, uint32_t btn) {
  const uint32_t edge = btn & ~p->prev;
  p->prev = btn;
  m->changed = m->health_changed = m->opened_now = m->hint = m->ovl_changed = m->confirm = 0;
  m->slot_changed = m->speed_changed = m->clear_now = 0;
  m->act = ACT_NONE; m->act_arg = 0;

  if (m->open && handle != m->owner) return MENU_PASS;   // other controllers are not the menu's

  const int chord = (btn & MB_OPEN_HOLD) && (edge & MB_OPTIONS);
  if (chord) {
    m->open = !m->open;
    m->owner = m->open ? handle : -1;
    m->opened_now = m->open;
    m->clear_armed = 0;
    m->page = PG_MAIN; m->sub = 0; m->mk_armed = 0;
    m->changed = 1; p->swallow = 1;
    return MENU_SWALLOW;
  }
  if (m->open) {
    if (m->page != PG_MAIN) return menu_page_step(m, edge);
    if (m->clear_armed && (edge & ~MB_SQUARE)) { m->clear_armed = 0; m->changed = 1; }   // anything else = "no"
    if (edge & MB_UP)   { m->selected = (m->selected + ITEM_COUNT - 1) % ITEM_COUNT; m->changed = 1; }
    if (edge & MB_DOWN) { m->selected = (m->selected + 1) % ITEM_COUNT; m->changed = 1; }
    int delta = ((edge & MB_RIGHT) != 0) - ((edge & MB_LEFT) != 0);
    if (delta && m->selected == ITEM_OVERLAY) {
      m->ovl = (m->ovl + OVL_CHOICES + delta) % OVL_CHOICES;
      m->ovl_changed = m->changed = 1;
    } else if (delta && m->selected == ITEM_SLOT) {
      m->slot = (m->slot + SLOT_COUNT + delta) % SLOT_COUNT;
      m->slot_changed = m->changed = 1;
    } else if (delta && m->selected == ITEM_SPEED) {
      m->speed = (m->speed + SPEED_CHOICES + delta) % SPEED_CHOICES;
      m->speed_changed = m->changed = 1;
    } else if (delta && m->selected <= ITEM_P2_HEALTH) {
      m->health[m->selected] = (m->health[m->selected] + HEALTH_CHOICES + delta) % HEALTH_CHOICES;
      m->health_changed = m->changed = 1;
    }
    if (edge & MB_CROSS) m->changed = m->confirm = 1;   // confirm: re-show current value
    if ((edge & MB_TRIANGLE) && m->selected == ITEM_SLOT) {  // v2.17: timing editor and combo maker
      m->page = PG_TOOLS; m->sub = 0; m->clear_armed = 0; m->changed = 1;
    }
    if ((edge & MB_SQUARE) && m->selected == ITEM_SLOT) {   // Square, Square = clear this slot
      if (m->clear_armed) { m->clear_armed = 0; m->clear_now = 1; }
      else m->clear_armed = 1;
      m->changed = 1;
    }
    if (edge & MB_CIRCLE) { m->open = 0; m->owner = -1; m->changed = 1; p->swallow = 1; m->clear_armed = 0; }
    return MENU_SWALLOW;
  }
  if (p->swallow) {                                  // keep OPTIONS/O from leaking into the game
    if (!btn) p->swallow = 0;
    return MENU_SWALLOW;
  }
  if ((edge & MB_OPTIONS) && !m->hint_shown) { m->hint = 1; m->hint_shown = 1; }
  return MENU_PASS;
}
#endif
