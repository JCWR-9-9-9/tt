// tekken_combo_macro v2.18 — GoldHEN plugin: combo macro recorder + in-game mod menu (merged).
// v2.18 (menu v2.00): Build a combo is one big screen. Each row is one step (a direction, a button, or both,
//        e.g. Up+Right + X), gap 0.01 s steps (default 0.20 s), 8 rows visible and scrolled, count in the title.
//        Direction, Button and Gap are picked on that screen; X adds, Triangle deletes the selected step,
//        Left/Right on a step edits its gap, Save picks slot 1-10, O cancels (nothing written). Timing editor,
//        slots 1-9, recording, playback, health and speed logic unchanged.
// v2.17 (menu v1.09): Combo tools, opened with Triangle on the Combo slot row. (1) Edit timing: pick a press
//        and change the gap after it in 1/60 s steps (Left/Right, L1/R1 = 6 frames); X saves, O cancels, and
//        the file is written only on X. (2) Build a combo: pick a button or direction, a gap, add presses,
//        undo, choose slot 1-10, X saves (X twice on a full slot). Both write through slot_write, the same
//        writer as every slot. Slots 1-9, recording, playback, health and speed logic are unchanged.
// v2.16: slot 10 ships with a fixed combo, "10 Hit Combo 1" (Marshall Law, yahya's PDF): 10 presses at
//        0.00 / 0.20 / 0.40 / 0.60 / 0.90 / 1.20 / 1.50 / 1.80 / 2.10 / 2.40 s, each a 50 ms tap, on the
//        60 Hz pad grid (slot10_seed below). Written to slot10.bin only when that file does not exist yet;
//        a recording already in slot 10 is never replaced. Slots 1-9, recording, playback, health and
//        speed logic are unchanged (macro_save now calls slot_write, the same writer, with the same bytes).
// v2.15: P1/P2 Health also offer Damage 105% / 110% / 120% / 150% / 200% (that player TAKES more damage;
//        set P2 to 110% and your hits on P2 do 10% more). Same cave, same place, same size budget
//        (health_bytes.h CAVE_DMG, now 165 bytes); flags 00-05 behave exactly as before. Health is clamped
//        so it never wraps: it never goes below the game's own value or 0, whichever is lower (KO as normal).
// v2.14: on-screen menu flicker fix. The menu is drawn by the CPU into the buffer that has just gone on
//        screen; on his PS4 the draw landed several ms after the flip, after the scan-out had already
//        passed the panel's top rows (his video: title/top rows flicker, lower rows steady). Now:
//        the draw thread runs at the highest thread priority (wakes right at the flip), the per-frame
//        copy is compiled at -O2 and writes whole micro tiles (ov_fast.c, solid dark panel), the panel
//        sits at the bottom left (the scan-out reaches it ~10 ms after the flip instead of ~6 ms),
//        a menu change is copied after the old picture is already in place, and the PAD n/S counter
//        only redraws the menu while the Game speed row is selected. Overlay row footer = draw timing.
// v2.13: 10 combo slots (menu row "Combo slot", files slot1.bin..slot10.bin, the old slot1.bin is slot 1,
//        selection kept in combo_slot.cfg; Square twice on the row clears a slot) and slow motion
//        (menu row "Game speed" 100/75/50/33/25 %, frame pacing on the pad read: pace_logic.h).
// v2.11: the menu opens with L3 + OPTIONS only; the touchpad click goes to the game again.
// v2.12: P1/P2 Health also offer Damage 80% / 60% / 50% (hits take that share of the damage, min 1)
//        through an extended cave (health_bytes.h CAVE_DMG); TLH's cave stays the fallback for 0/1/2.
// v2.10: the menu is drawn on screen into the game's display buffers, tiled or linear, any of the
// 32-bit VideoOut formats (overlay_draw.h); notifications stay as the fallback.
// Built for Tab / yahya. Hook pattern taken from GoldHEN_Plugins_Repository/gamepad_helper (jocover).
//
// v2 (merge): the mod menu used to be a second plugin hooking scePadReadExt/StateExt, the same
// functions this plugin patches with Patcher_Install_Patch. Two plugins writing the same
// prologues = one clobbers the other, and the menu never saw input on hardware. Now ONE prx owns
// the pad: the menu runs inside process_sample() on the proven scePadRead/scePadReadState hooks.
//
// Mod menu (only on CUSA06014 v05.10; the combo works on all four Tekken 7 IDs):
//   hold L3, then press OPTIONS -> open / close  (L3 + OPTIONS never fires the mirrored combo)
//   D-pad up/down select P1/P2, left/right Normal / Infinite / 1-Hit (applies at once),
//   X re-shows the value, O closes. While open the menu eats that pad's input and the combo
//   triggers are off. Health cheat: TLH (GoldHEN Cheat Repository CUSA06014_05.10.json).
//
// Controls (the plugin swallows L3 and R3 so the game never sees them):
//   L3+R3 together  -> start recording   (recording begins at the first non-neutral input)
//   L3+R3 again     -> stop + save to /data/GoldHEN/combo_macro/slot<N>.bin (N = selected slot, 1..10)
//   R3 alone        -> play the selected slot as recorded            (fires on R3 release)
//   L3 alone        -> play the selected slot mirrored left<->right  (for when you're on the other side)
//   Menu rows (v2.13): P1 Health, P2 Health, Combo slot (Left/Right 1..10, Square twice = clear),
//   Game speed (100/75/50/33/25 %, slow motion while the menu is closed), Overlay.
//   any button / L3 / R3 during playback -> cancel playback
//
// Timing: replay is sample-based, not wall-clock. Every pad sample the game reads
// (one per scePadReadState call, or each sample returned by scePadRead) during recording
// is stored as one step; during playback each sample the game reads is replaced by the next
// stored step. Because the game reads the pad once per game frame, this replays on the same
// frame grid it was recorded on (60 fps in Tekken 7), independent of clock jitter.

#include "plugin_common.h"
#include "Common.h"
#include <Patcher.h>
#include <orbis/Pad.h>
#include "menu_logic.h"
#include "health_bytes.h"
#include "pace_logic.h"
#ifndef TK_HOST_TEST
#include <orbis/VideoOut.h>
#include <orbis/libkernel.h>
#include "font8x8_basic.h"
#endif

attr_public const char *g_pluginName = "tekken_combo_macro";
attr_public const char *g_pluginDesc = "Combo macro, 10 slots (L3+R3 rec, R3 play, L3 mirror) + mod menu (L3 + OPTIONS) + timing edit / combo builder";
attr_public const char *g_pluginAuth = "Tab; health cheat TLH";
attr_public u32 g_pluginVersion = 0x00000218; // 2.18

HOOK_INIT(scePadRead);
HOOK_INIT(scePadReadState);

static Patcher *scePadReadExtPatcher;
static Patcher *scePadReadStateExtPatcher;

#define BTN_L3        0x00000002u
#define BTN_R3        0x00000004u
#define BTN_UP        0x00000010u
#define BTN_RIGHT     0x00000020u
#define BTN_DOWN      0x00000040u
#define BTN_LEFT      0x00000080u
#define BTN_TOUCHPAD  0x00100000u
#define BTN_INTERCEPT 0x80000000u
#define BTN_TRIGGERS  (BTN_L3 | BTN_R3)

#define MACRO_DIR   GOLDHEN_PATH "/combo_macro"
#define MACRO_FILE  MACRO_DIR "/slot1.bin"   // slot 1 = the v2.12 file, same format
#define SLOT_CFG_FILE MACRO_DIR "/combo_slot.cfg"   // v2.13: selected slot, text "1".."10"
#define MACRO_MAGIC 0x4D434B54u   // "TKCM"
#define MACRO_VER   1u
#define MAX_STEPS   18000         // 5 min at 60 samples/s
#define STICK_DEAD  40            // neutral zone around 0x80, only used to find the combo start
#define TRIG_DEAD   30
#define MAX_HANDLES 8

typedef struct {
    uint32_t buttons;
    uint8_t lx, ly, rx, ry;
    uint8_t l2, r2;
    uint16_t reserved;
    uint32_t t_us;      // pad timestamp relative to the first step (informational)
} MacroStep;            // 16 bytes

typedef struct {
    uint32_t magic, version, count, step_size;
    uint32_t presses, source, reserved[2];
} MacroHeader;          // 32 bytes

#include "combo_edit.h"     // v2.17: timing editor + combo maker (pure C, host-tested)

enum { ST_IDLE = 0, ST_RECORDING, ST_PLAYING };

typedef struct {
    int32_t handle;
    int used;
    uint32_t prev_real;
    int chord_used;     // both L3 and R3 were down during this press
    int solo_pending;   // exactly one of L3/R3 went down first
    uint32_t solo_btn;
    int suppress;       // ignore trigger release (used after a cancel)
    MenuPad mpad;       // mod-menu edge tracking for this pad
} HandleState;

static MacroStep *g_slot;        // saved combo (played back)
static uint32_t g_slot_count;
static MacroStep *g_rec;         // recording buffer
static uint32_t g_rec_count;
static uint32_t g_rec_mark;      // truncation point when L3/R3 goes down during recording
static int g_rec_started;
static uint64_t g_rec_t0;
static int g_rec_wait_release;
static uint32_t g_rec_source;

static int g_state = ST_IDLE;
static int32_t g_owner = -1;     // pad handle that owns the current record/playback
static uint32_t g_play_idx;
static int g_play_mirror;

static HandleState g_hs[MAX_HANDLES];
static volatile char g_lock;
static Menu g_menu;              // (v2.13: declared here, the slot code needs the selected slot)

// v2.13 combo slots: only the selected slot is in memory (g_slot); the others are known by header.
static uint32_t g_slot_len[SLOT_COUNT];      // steps (frames) per slot, 0 = empty
static uint32_t g_slot_presses[SLOT_COUNT];
static volatile uint32_t g_view_gen;         // bumped on anything the on-screen menu shows
#define ED_MAX_PRESSES 512
static MacroStep *g_ed_orig, *g_ed_work;     // v2.17: the slot as read / the rebuilt sequence (allocated on first use)
static CePress g_ed_press[ED_MAX_PRESSES];
static uint32_t g_ed_gap[ED_MAX_PRESSES], g_ed_gap0[ED_MAX_PRESSES];   // gap per press, frames: now / as read
static uint32_t g_ed_n, g_ed_work_n;         // steps in the slot as read / in the rebuilt sequence
static int g_ed_P, g_ed_slot, g_ed_dirty;
static uint32_t g_ed_presses;                 // header press count of the slot as read (kept on save)

static char g_ov_timing[48];                 // v2.14: Overlay row footer, e.g. "MENU READY 0.9MS AFTER FLIP (MAX 1.4)"

// v2.13 slow motion
static Pacer g_pacer;
static volatile char g_pace_lock;
static ComboGate g_gate;
static int g_call_first, g_call_last;        // position of the sample inside the current read call
#ifdef TK_HOST_TEST
static uint64_t g_host_now_us, g_host_slept_us; static uint32_t g_host_sleeps;
static uint64_t tk_now_us(void) { return g_host_now_us; }
static void tk_sleep_us(uint64_t us) { if (!us) return; g_host_now_us += us; g_host_slept_us += us; g_host_sleeps++; }
#else
static uint64_t tk_now_us(void) { return sceKernelGetProcessTime(); }
static void tk_sleep_us(uint64_t us) { if (us) sceKernelUsleep((uint32_t)us); }
#endif

static inline int lock_try(void) { return !__atomic_test_and_set(&g_lock, __ATOMIC_ACQUIRE); }
static inline void lock_release(void) { __atomic_clear(&g_lock, __ATOMIC_RELEASE); }

static HandleState *hs_get(int32_t handle) {
    for (int i = 0; i < MAX_HANDLES; i++)
        if (g_hs[i].used && g_hs[i].handle == handle) return &g_hs[i];
    for (int i = 0; i < MAX_HANDLES; i++)
        if (!g_hs[i].used) {
            memset(&g_hs[i], 0, sizeof(HandleState));
            g_hs[i].used = 1;
            g_hs[i].handle = handle;
            return &g_hs[i];
        }
    return NULL;
}

static inline int iabs_(int v) { return v < 0 ? -v : v; }

static int step_is_neutral(const MacroStep *s) {
    if (s->buttons & ~(BTN_TRIGGERS | BTN_INTERCEPT)) return 0;
    if (iabs_((int)s->lx - 0x80) > STICK_DEAD || iabs_((int)s->ly - 0x80) > STICK_DEAD) return 0;
    if (iabs_((int)s->rx - 0x80) > STICK_DEAD || iabs_((int)s->ry - 0x80) > STICK_DEAD) return 0;
    if (s->l2 > TRIG_DEAD || s->r2 > TRIG_DEAD) return 0;
    return 1;
}

static uint32_t count_presses(const MacroStep *s, uint32_t n) {
    uint32_t presses = 0, prev = 0;
    for (uint32_t i = 0; i < n; i++) {
        uint32_t b = s[i].buttons & ~BTN_INTERCEPT;
        presses += __builtin_popcount(b & ~prev);
        prev = b;
    }
    return presses;
}

static int file_write_all(int fd, const void *buf, size_t len) {
    const uint8_t *p = (const uint8_t *)buf;
    while (len) {
        ssize_t w = sceKernelWrite(fd, p, len);
        if (w <= 0) return -1;
        p += w; len -= (size_t)w;
    }
    return 0;
}

static int file_read_all(int fd, void *buf, size_t len) {
    uint8_t *p = (uint8_t *)buf;
    while (len) {
        ssize_t r = sceKernelRead(fd, p, len);
        if (r <= 0) return -1;
        p += r; len -= (size_t)r;
    }
    return 0;
}

static void slot_path(char *out, size_t n, int slot, const char *ext) {
    snprintf(out, n, MACRO_DIR "/slot%d.%s", slot + 1, ext);
}

// v2.16: the one writer for every slot file (temp file + rename, as v2.12 did for slot1.bin).
static int slot_write(int slot, const MacroStep *steps, uint32_t count, uint32_t presses, uint32_t source) {
    char file[96], tmp[96];
    slot_path(file, sizeof(file), slot, "bin");
    slot_path(tmp, sizeof(tmp), slot, "tmp");
    sceKernelMkdir(GOLDHEN_PATH, 0777);
    sceKernelMkdir(MACRO_DIR, 0777);
    int fd = sceKernelOpen(tmp, 0x0001 | 0x0200 | 0x0400, 0777); // O_WRONLY|O_CREAT|O_TRUNC
    if (fd < 0) { final_printf("save: open failed 0x%08x\n", fd); return -1; }
    MacroHeader h;
    memset(&h, 0, sizeof(h));
    h.magic = MACRO_MAGIC; h.version = MACRO_VER; h.count = count;
    h.step_size = sizeof(MacroStep); h.presses = presses;
    h.source = source;
    int ok = file_write_all(fd, &h, sizeof(h)) == 0 &&
             file_write_all(fd, steps, (size_t)count * sizeof(MacroStep)) == 0;
    sceKernelClose(fd);
    if (!ok) { final_printf("save: write failed\n"); return -1; }
    sceKernelUnlink(file);
    if (sceKernelRename(tmp, file) != 0) { final_printf("save: rename failed\n"); return -1; }
    return 0;
}

// Saves g_slot into the selected slot's file.
static int macro_save(void) {
    return slot_write(g_menu.slot, g_slot, g_slot_count, count_presses(g_slot, g_slot_count), g_rec_source);
}

// v2.16 slot 10: the fixed combo "10 Hit Combo 1" (Marshall Law, from yahya's PDF). Presses on the
// 60 Hz pad grid: frame = ms * 60 / 1000, each press held for 3 frames (50 ms), then released.
// Press 1 is Square with the D-pad held down + right (the PDF's down-right arrow), as the pad read
// returns it: the DOWN and RIGHT bits of the buttons word (the same bits the recorder stores from a
// real D-pad), sticks at neutral. Presses 2-10 are face buttons only.
#define DEF_SLOT        9       // slot 10 (0-based)
#define DEF_FRAME_HZ    60u
#define DEF_TAP_FRAMES  3u      // 50 ms at 60 Hz
#define DEF_LEN_FRAMES  150u    // 2.5 s: the last press (2.40 s) and its tap, then neutral
typedef struct { uint32_t ms; uint32_t buttons; } DefPress;
static const DefPress DEF_PRESSES[] = {
    {0,    MB_SQUARE | MB_DOWN | MB_RIGHT, },   // 1   0.00 s  Square, D-pad down-right
    {200,  MB_TRIANGLE,                    },   // 2   0.20 s  Triangle
    {400,  MB_TRIANGLE,                    },   // 3   0.40 s  Triangle
    {600,  MB_SQUARE,                      },   // 4   0.60 s  Square
    {900,  MB_CROSS,                       },   // 5   0.90 s  X
    {1200, MB_CROSS,                       },   // 6   1.20 s  X
    {1500, MB_CROSS,                       },   // 7   1.50 s  X
    {1800, MB_CIRCLE,                      },   // 8   1.80 s  Circle
    {2100, MB_CROSS,                       },   // 9   2.10 s  X
    {2400, MB_CIRCLE,                      },   // 10  2.40 s  Circle
};
#define DEF_PRESS_COUNT (sizeof(DEF_PRESSES) / sizeof(DEF_PRESSES[0]))

// Builds the fixed combo into out (DEF_LEN_FRAMES steps). Returns the step count.
static uint32_t def_combo_build(MacroStep *out) {
    memset(out, 0, DEF_LEN_FRAMES * sizeof(MacroStep));
    for (uint32_t f = 0; f < DEF_LEN_FRAMES; f++) {
        out[f].lx = out[f].ly = out[f].rx = out[f].ry = 0x80;
        out[f].t_us = (uint32_t)((uint64_t)f * 1000000u / DEF_FRAME_HZ);
    }
    for (uint32_t p = 0; p < DEF_PRESS_COUNT; p++) {
        const uint32_t f0 = DEF_PRESSES[p].ms * DEF_FRAME_HZ / 1000u;
        for (uint32_t k = 0; k < DEF_TAP_FRAMES; k++) {
            out[f0 + k].buttons |= DEF_PRESSES[p].buttons;
        }
    }
    return DEF_LEN_FRAMES;
}

// Writes the fixed combo to slot 10 only when slot10.bin does not exist (a recording there is kept).
static void slot10_seed(void) {
    char file[96];
    slot_path(file, sizeof(file), DEF_SLOT, "bin");
    int fd = sceKernelOpen(file, 0x0000, 0); // O_RDONLY
    if (fd >= 0) { sceKernelClose(fd); return; }
    const uint32_t n = def_combo_build(g_rec);   // g_rec is only the recording scratch; empty until R3 is used
    if (slot_write(DEF_SLOT, g_rec, n, DEF_PRESS_COUNT, 0) != 0) final_printf("slot 10: could not write the fixed combo\n");
}

// Reads one slot file. steps == NULL: header only. Returns the step count (0 = empty/invalid).
static uint32_t slot_read(int slot, MacroStep *steps, uint32_t *presses) {
    char file[96];
    slot_path(file, sizeof(file), slot, "bin");
    int fd = sceKernelOpen(file, 0x0000, 0); // O_RDONLY
    if (fd < 0) return 0;
    MacroHeader h;
    int ok = file_read_all(fd, &h, sizeof(h)) == 0 && h.magic == MACRO_MAGIC && h.version == MACRO_VER &&
             h.step_size == sizeof(MacroStep) && h.count > 0 && h.count <= MAX_STEPS;
    if (ok && steps) ok = file_read_all(fd, steps, (size_t)h.count * sizeof(MacroStep)) == 0;
    sceKernelClose(fd);
    if (!ok) return 0;
    if (presses) *presses = h.presses;
    return h.count;
}

// Loads slot `slot` into g_slot (the playback buffer) and refreshes its info.
static int slot_load(int slot) {
    uint32_t presses = 0;
    uint32_t n = slot_read(slot, g_slot, &presses);
    g_slot_count = n;
    g_slot_len[slot] = n; g_slot_presses[slot] = n ? presses : 0;
    g_view_gen++;
    return n ? 0 : -1;
}
// Loads the selected slot (v2.12 name kept: it always meant "the combo R3 plays").
static int macro_load(void) { return slot_load(g_menu.slot); }

static void slots_scan(void) {
    for (int i = 0; i < SLOT_COUNT; i++) {
        g_slot_presses[i] = 0;
        g_slot_len[i] = slot_read(i, NULL, &g_slot_presses[i]);
        if (!g_slot_len[i]) g_slot_presses[i] = 0;
    }
    g_view_gen++;
}

static void slot_cfg_save(void) {
    sceKernelMkdir(GOLDHEN_PATH, 0777);
    sceKernelMkdir(MACRO_DIR, 0777);
    int fd = sceKernelOpen(SLOT_CFG_FILE, 0x0001 | 0x0200 | 0x0400, 0777);
    if (fd < 0) return;
    char t[4]; int n = snprintf(t, sizeof(t), "%d\n", g_menu.slot + 1);
    sceKernelWrite(fd, t, (size_t)n);
    sceKernelClose(fd);
}
static void slot_cfg_load(void) {
    int fd = sceKernelOpen(SLOT_CFG_FILE, 0x0000, 0);
    if (fd < 0) return;
    char t[4] = {0};
    ssize_t r = sceKernelRead(fd, t, 3);
    sceKernelClose(fd);
    if (r <= 0) return;
    int v = 0;
    for (int i = 0; i < r && t[i] >= '0' && t[i] <= '9'; i++) v = v * 10 + (t[i] - '0');
    if (v >= 1 && v <= SLOT_COUNT) g_menu.slot = v - 1;
}

// Deletes one slot's file (menu: Square twice). Returns 0 when the slot is empty afterwards.
static int slot_clear(int slot) {
    char file[96], tmp[96];
    slot_path(file, sizeof(file), slot, "bin");
    slot_path(tmp, sizeof(tmp), slot, "tmp");
    sceKernelUnlink(file);
    sceKernelUnlink(tmp);
    uint32_t left = slot_read(slot, NULL, NULL);
    g_slot_len[slot] = left;
    if (!left) g_slot_presses[slot] = 0;
    if (slot == g_menu.slot && !left) g_slot_count = 0;
    g_view_gen++;
    return left ? -1 : 0;
}

static void fill_step(MacroStep *s, const OrbisPadData *d) {
    s->buttons = d->buttons & ~(BTN_TRIGGERS | BTN_INTERCEPT);
    s->lx = d->leftStick.x;  s->ly = d->leftStick.y;
    s->rx = d->rightStick.x; s->ry = d->rightStick.y;
    s->l2 = d->analogButtons.l2; s->r2 = d->analogButtons.r2;
    s->reserved = 0;
    s->t_us = 0;
}

static void apply_step(OrbisPadData *d, const MacroStep *s, int mirror) {
    uint32_t b = s->buttons;
    uint8_t lx = s->lx, rx = s->rx;
    if (mirror) {
        uint32_t l = b & BTN_LEFT, r = b & BTN_RIGHT;
        b &= ~(BTN_LEFT | BTN_RIGHT);
        if (l) b |= BTN_RIGHT;
        if (r) b |= BTN_LEFT;
        lx = (uint8_t)(255 - lx);
        rx = (uint8_t)(255 - rx);
    }
    d->buttons = b | (d->buttons & BTN_INTERCEPT);
    d->leftStick.x = lx;  d->leftStick.y = s->ly;
    d->rightStick.x = rx; d->rightStick.y = s->ry;
    d->analogButtons.l2 = s->l2; d->analogButtons.r2 = s->r2;
}

static void record_start(int32_t handle, uint32_t source) {
    g_state = ST_RECORDING;
    g_owner = handle;
    g_rec_count = 0;
    g_rec_mark = UINT32_MAX;
    g_rec_started = 0;
    g_rec_wait_release = 1;
    g_rec_source = source;
    gate_reset(&g_gate);
    Notify(TEX_ICON_SYSTEM, "Combo REC (slot %d)\nDo your combo, then L3+R3 to save", g_menu.slot + 1);
}

static void record_stop(void) {
    uint32_t n = g_rec_count;
    if (g_rec_mark != UINT32_MAX && g_rec_mark < n) n = g_rec_mark;   // drop the stop chord
    while (n > 0 && step_is_neutral(&g_rec[n - 1])) n--;                // drop trailing idle
    g_state = ST_IDLE;
    g_owner = -1;
    if (n == 0 || !g_rec_started) {
        NotifyStatic(TEX_ICON_SYSTEM, "Combo REC cancelled\nNothing recorded (old combo kept)");
        return;
    }
    const int slot = g_menu.slot;
    if (n < MAX_STEPS) {  // one neutral step at the end so every button is released
        memset(&g_rec[n], 0, sizeof(MacroStep));
        g_rec[n].lx = g_rec[n].ly = g_rec[n].rx = g_rec[n].ry = 0x80;
        g_rec[n].t_us = g_rec[n - 1].t_us;
        n++;
    }
    memcpy(g_slot, g_rec, (size_t)n * sizeof(MacroStep));
    g_slot_count = n;
    uint32_t presses = count_presses(g_slot, n);
    int saved = macro_save();
    g_slot_len[slot] = n; g_slot_presses[slot] = presses; g_view_gen++;
    uint32_t tenths = (n * 10 + 30) / 60;  // at 60 samples/s
    Notify(TEX_ICON_SYSTEM, "Combo saved (%u inputs, %u frames ~%u.%us)\nSlot %d%s",
           presses, n, tenths / 10, tenths % 10, slot + 1, saved == 0 ? "" : "\nWARNING: could not write file");
}

static void play_start(int32_t handle, int mirror) {
    if (g_slot_count == 0) {
        Notify(TEX_ICON_SYSTEM, "No combo in slot %d yet\nL3+R3 to record (L3 + OPTIONS: pick a slot)", g_menu.slot + 1);
        return;
    }
    g_state = ST_PLAYING;
    g_owner = handle;
    g_play_idx = 0;
    gate_reset(&g_gate);
    g_play_mirror = mirror;
}

static void play_stop(void) {
    g_state = ST_IDLE;
    g_owner = -1;
}


// ============================ mod menu (CUSA06014 v05.10 only) ============================
static int g_menu_enabled;          // title/version check passed at load
static uint64_t g_eboot_base;
static int g_cave_installed, g_patch_failed;

#ifndef TK_HOST_TEST
static int mapped(uint64_t at, size_t len, int want_write) {
    void *start = 0, *end = 0; int prot = 0;
    if (!at || !len || sceKernelQueryMemoryProtection((void *)at, &start, &end, &prot) < 0) return 0;
    return (uintptr_t)start <= at && (uintptr_t)end >= at + len && (prot & 1) && (!want_write || (prot & 2));
}
static int kwrite(uint64_t at, const void *src, size_t n) {
    if (!mapped(at, n, 0)) return 0;
    struct proc_rw rw; memset(&rw, 0, sizeof(rw));
    rw.address = at; rw.data = (void *)src; rw.length = n; rw.write_flags = 1;
    if (sys_sdk_proc_rw(&rw) != 0) return 0;
    __sync_synchronize();
    return memcmp((void *)at, src, n) == 0;
}
#endif

// Install the cave + jump once (on the first non-Normal choice), then only set the two flag bytes.
// v2.12: prefers the extended cave CAVE_DMG (Normal/Infinite/1-Hit exactly as TLH's + Damage 80/60/50 %;
// v2.15: + Damage 105/110/120/150/200 %).
// Falls back to TLH's own cave when only TLH's 83 bytes are free, or when TLH's cave is already active
// (GoldHEN cheat menu "Health" on); then the Damage choices are refused and the other three still work.
enum { CAVE_KIND_NONE, CAVE_KIND_DMG, CAVE_KIND_TLH };
static int g_cave_kind;
static int g_cave_tlh_why;   // 1 = TLH cave was already active, 2 = not enough free bytes for CAVE_DMG
static int cave_free(uint64_t cave, size_t n) {
    const unsigned char *p = (const unsigned char *)cave;
    for (size_t i = 0; i < n; i++) if (p[i] != 0 && p[i] != 0x90 && p[i] != 0xcc) return 0;
    return 1;
}
static void damage_unavailable_notice(void) {
    NotifyStatic(TEX_ICON_SYSTEM, g_cave_tlh_why == 1
        ? "Mod Menu: Damage % can't run while the GoldHEN cheat \"Health\" is on.\nTurn it off, restart the game."
        : "Mod Menu: Damage % not available here (no free space for it).\nNormal / Infinite / 1-Hit still work.");
}
static int health_apply(void) {
    uint64_t cave = g_eboot_base + CAVE_OFF, site = g_eboot_base + SITE_OFF;
    if (g_patch_failed) return 0;
    if (!g_cave_installed && (g_menu.health[0] || g_menu.health[1])) {
        if (!mapped(site, sizeof(SITE_ORIG), 0) || !mapped(cave, sizeof(CAVE), 0)) goto fail;
        const int dmg_room = mapped(cave, sizeof(CAVE_DMG), 0);
        if (memcmp((void *)site, SITE_ORIG, sizeof(SITE_ORIG)) != 0) {
            // Another cheat may own this site: never overwrite foreign code.
            if (memcmp((void *)site, SITE_PATCH, sizeof(SITE_PATCH)) != 0) goto fail;
            if (dmg_room && memcmp((void *)(cave + 2), CAVE_DMG + 2, sizeof(CAVE_DMG) - 2) == 0)
                g_cave_kind = CAVE_KIND_DMG;          // ours, from an earlier load in this game session
            else if (memcmp((void *)(cave + 2), CAVE + 2, sizeof(CAVE) - 2) == 0)
                { g_cave_kind = CAVE_KIND_TLH; g_cave_tlh_why = 1; }   // TLH cave active (GoldHEN cheat menu)
            else goto fail;
            g_cave_installed = 1;
        } else {
            if (dmg_room && cave_free(cave, sizeof(CAVE_DMG))) {
                if (!kwrite(cave, CAVE_DMG, sizeof(CAVE_DMG))) goto fail;
                g_cave_kind = CAVE_KIND_DMG;
            } else if (cave_free(cave, sizeof(CAVE))) {
                if (!kwrite(cave, CAVE, sizeof(CAVE))) goto fail;
                g_cave_kind = CAVE_KIND_TLH; g_cave_tlh_why = 2;
            } else goto fail;
            if (!kwrite(site, SITE_PATCH, sizeof(SITE_PATCH))) goto fail;   // jump last: cave is complete first
            g_cave_installed = 1;
        }
    }
    if (g_cave_installed) {
        if (g_cave_kind == CAVE_KIND_TLH && (g_menu.health[0] > HEALTH_MIN || g_menu.health[1] > HEALTH_MIN)) {
            damage_unavailable_notice();
            return 0;   // refused, not broken: the caller restores the previous choice
        }
        unsigned char flags[2] = {(unsigned char)g_menu.health[0], (unsigned char)g_menu.health[1]};
        if (!kwrite(cave, flags, 2)) goto fail;
    }
    return 1;
fail:
    g_patch_failed = 1;
    NotifyStatic(TEX_ICON_SYSTEM, "Mod Menu: health patch blocked (unexpected game bytes). No more writes.");
    return 0;
}

static int overlay_ready(void);
static void overlay_on_open(void);
static void overlay_cfg_save(void);

// Row value "3: 1.2s" / "3: empty"; detail (notifications) "3: 1.2s, 6 inputs, 72 frames".
static void slot_value_text(char *out, size_t n, int slot, int detail) {
    const uint32_t len = g_slot_len[slot];
    if (!len) { snprintf(out, n, "%d: empty", slot + 1); return; }
    uint32_t tenths = (len * 10 + 30) / 60;   // at 60 frames/s
    if (detail) snprintf(out, n, "%d: %u.%us, %u inputs, %u frames", slot + 1, tenths / 10, tenths % 10, g_slot_presses[slot], len);
    else snprintf(out, n, "%d: %u.%us", slot + 1, tenths / 10, tenths % 10);
}

static void menu_announce(void) {
    char text[200];
    if (g_menu.ovl_changed) {   // always told by notification, so a broken layout can be fixed blind
        overlay_cfg_save();
        snprintf(text, sizeof(text), "Mod Menu overlay: %s\n%s", menu_ovl_name(g_menu.ovl),
                 g_menu.ovl == OVL_OFF ? "menu shown as notifications" : "if the menu looks broken, try the next one");
        NotifyStatic(TEX_ICON_SYSTEM, text);
        return;
    }
    const int on_screen = overlay_ready();
    if (!g_menu.open) { if (!on_screen) NotifyStatic(TEX_ICON_SYSTEM, "Mod Menu closed"); return; }
    if (on_screen && !g_menu.confirm) return;   // drawn on screen: no notification spam (X still shows one)
    if (g_menu.page != PG_MAIN) {               // v2.17 combo tools
        if (g_menu.page == PG_TOOLS)
            snprintf(text, sizeof(text), "Tekken Mod Menu > Combo tools\n> %s\nUp/Down select | Left/Right slot | X open | O back",
                     g_menu.sub == 0 ? "Edit timing" : g_menu.sub == 1 ? "Build a combo" : "Back");
        else if (g_menu.page == PG_EDIT)
            snprintf(text, sizeof(text), "Edit timing, slot %d: press %d of %d\nLeft/Right 1 frame (1/60 s) | L1/R1 6 | X save | O cancel",
                     g_ed_slot + 1, g_menu.ed_cur + 1, g_ed_P);
        else if (g_menu.page == PG_MAKE)
            snprintf(text, sizeof(text), "Build a combo: %d step%s\nUp/Down move | Left/Right change | X add | Triangle delete | O cancel (nothing saved)",
                     g_menu.mk_n, g_menu.mk_n == 1 ? "" : "s");
        else
            snprintf(text, sizeof(text), "Save combo to slot %d\n%s", g_menu.mk_slot + 1,
                     g_menu.mk_armed ? "X again = replace the slot's combo" : "Left/Right slot | X save | O back");
        NotifyStatic(TEX_ICON_SYSTEM, text);
        return;
    }
    if (g_menu.selected == ITEM_OVERLAY)
        snprintf(text, sizeof(text), "Tekken Mod Menu\n> Overlay: %s\nUp/Down select | Left/Right change | O close",
                 menu_ovl_name(g_menu.ovl));
    else if (g_menu.selected == ITEM_SLOT) {
        char v[64];
        slot_value_text(v, sizeof(v), g_menu.slot, 1);
        snprintf(text, sizeof(text), "Tekken Mod Menu\n> Combo slot: %s\n%s", v,
                 g_menu.clear_armed ? "Press SQUARE again to clear it (any other button = no)"
                                    : "Left/Right change | SQUARE clear | O close");
    } else if (g_menu.selected == ITEM_SPEED)
        snprintf(text, sizeof(text), "Tekken Mod Menu\n> Game speed: %s\n%s", menu_speed_name(g_menu.speed),
                 g_menu.speed ? "Slow motion starts when the menu closes" : "Up/Down select | Left/Right change | O close");
    else
        snprintf(text, sizeof(text), "Tekken Mod Menu\n> P%d Health: %s\nUp/Down select | Left/Right change | O close",
                 g_menu.selected + 1, menu_value(g_menu.health[g_menu.selected]));
    NotifyStatic(TEX_ICON_SYSTEM, text);
}

static void pad_neutralize(OrbisPadData *d) {
    d->buttons &= BTN_INTERCEPT;
    d->leftStick.x = d->leftStick.y = d->rightStick.x = d->rightStick.y = 0x80;
    d->analogButtons.l2 = d->analogButtons.r2 = 0;
    d->touch.fingers = 0;
}

static void combo_forget_triggers(HandleState *h, uint32_t real) {
    h->solo_pending = 0; h->chord_used = 0; h->suppress = 0; h->prev_real = real;
}

static void menu_act(void);   // v2.17 (defined with the combo tools)

// Runs first on every real sample. Returns 1 when the menu consumed the sample (combo skipped).
static int menu_filter(HandleState *h, int32_t handle, OrbisPadData *d) {
    uint32_t real = d->buttons;
    int old0 = g_menu.health[0], old1 = g_menu.health[1];
    g_menu.full_mask = 0;                                    // v2.17: which slots hold a combo (save confirm)
    for (int i = 0; i < SLOT_COUNT; i++) if (g_slot_len[i]) g_menu.full_mask |= 1u << i;
    int r = menu_step(&g_menu, &h->mpad, handle, real);
    if (g_menu.health_changed && g_cave_installed && g_cave_kind == CAVE_KIND_TLH) {
        // TLH fallback cave: step over the Damage choices (1-Hit -> Normal going right, Normal -> 1-Hit going left)
        int *hv = &g_menu.health[g_menu.selected], was = g_menu.selected == 0 ? old0 : old1;
        if (*hv > HEALTH_MIN) { *hv = was == HEALTH_MIN ? HEALTH_NORMAL : HEALTH_MIN; damage_unavailable_notice(); }
    }
    if (g_menu.health_changed && !health_apply()) { g_menu.health[0] = old0; g_menu.health[1] = old1; }
    if (g_menu.slot_changed) { slot_load(g_menu.slot); slot_cfg_save(); }   // R3 / L3 now play this slot
    if (g_menu.act) menu_act();                              // v2.17: timing edit / combo maker requests
    int clear_msg = 0;   // 1 = already empty, 2 = cleared, 3 = delete failed (shown after the row text)
    if (g_menu.clear_armed && !g_slot_len[g_menu.slot]) { g_menu.clear_armed = 0; clear_msg = 1; }   // nothing to clear
    if (g_menu.clear_now) clear_msg = slot_clear(g_menu.slot) == 0 ? 2 : 3;
    if (g_menu.speed_changed) g_pacer.active = 0;   // new schedule from the next read after the menu closes
    if (g_menu.changed) g_view_gen++;
    if (g_menu.opened_now) {
        overlay_on_open();
        if (g_state == ST_RECORDING) {
            g_state = ST_IDLE; g_owner = -1;
            NotifyStatic(TEX_ICON_SYSTEM, "Combo REC cancelled (menu opened)\nOld combo kept");
        } else if (g_state == ST_PLAYING) {
            play_stop();
        }
    }
    if (g_menu.changed) menu_announce();
    if (clear_msg)
        Notify(TEX_ICON_SYSTEM, clear_msg == 1 ? "Combo slot %d is already empty" : clear_msg == 2 ? "Combo slot %d cleared"
                                                : "Combo slot %d: could not delete the file", g_menu.slot + 1);
    if (g_menu.hint) NotifyStatic(TEX_ICON_SYSTEM, "Mod Menu: L3 + OPTIONS\n(hold L3, then press OPTIONS)");
    if (r == MENU_SWALLOW) { combo_forget_triggers(h, real); pad_neutralize(d); return 1; }
    if (g_menu.open) {   // a second controller while the menu is open: passes through, no combo triggers
        combo_forget_triggers(h, real);
        d->buttons &= ~BTN_TRIGGERS;
        return 1;
    }
    return 0;
}

#define OVL_CFG_FILE MACRO_DIR "/overlay.cfg"
static void overlay_cfg_save(void) {
    sceKernelMkdir(GOLDHEN_PATH, 0777);
    sceKernelMkdir(MACRO_DIR, 0777);
    int fd = sceKernelOpen(OVL_CFG_FILE, 0x0001 | 0x0200 | 0x0400, 0777);
    if (fd < 0) return;
    char c = (char)('0' + g_menu.ovl);
    sceKernelWrite(fd, &c, 1);
    sceKernelClose(fd);
}
static void overlay_cfg_load(void) {
    int fd = sceKernelOpen(OVL_CFG_FILE, 0x0000, 0);
    if (fd < 0) return;
    char c = 0;
    if (sceKernelRead(fd, &c, 1) == 1 && c >= '0' && c < '0' + OVL_CHOICES) g_menu.ovl = c - '0';
    sceKernelClose(fd);
}

#include "overlay_draw.h"
#ifndef TK_HOST_TEST
#include "ov_fast.h"
#endif
// ---- v2.17 combo tools: timing editor (gap per press) and combo maker. Held in RAM until X saves. ----
static int ed_buffers(void) {
    if (!g_ed_orig) g_ed_orig = (MacroStep *)malloc(MAX_STEPS * sizeof(MacroStep));
    if (!g_ed_work) g_ed_work = (MacroStep *)malloc(MAX_STEPS * sizeof(MacroStep));
    return g_ed_orig && g_ed_work;
}
// Source word of a slot file's header (kept as it was when the slot is rewritten).
static uint32_t slot_source(int slot) {
    char file[96];
    slot_path(file, sizeof(file), slot, "bin");
    int fd = sceKernelOpen(file, 0x0000, 0);
    if (fd < 0) return 0;
    MacroHeader h;
    int ok = file_read_all(fd, &h, sizeof(h)) == 0;
    sceKernelClose(fd);
    return ok ? h.source : 0;
}
// After a slot file is written: the slot list, and the playback buffer when it is the selected slot.
static void slot_info_refresh(int slot, uint32_t n, uint32_t presses) {
    g_slot_len[slot] = n; g_slot_presses[slot] = presses;
    if (slot == g_menu.slot) slot_load(slot);
    g_view_gen++;
}
static void ed_back(void) { g_menu.page = PG_TOOLS; g_menu.sub = 0; g_ed_dirty = 0; }
static void ed_recount(void) {
    g_ed_dirty = 0;
    for (int k = 0; k < g_ed_P; k++) if (g_ed_gap[k] != g_ed_gap0[k]) g_ed_dirty = 1;
}
static int ed_try_rebuild(void) {
    const uint32_t m = ce_rebuild(g_ed_orig, g_ed_n, g_ed_press, g_ed_P, g_ed_gap, g_ed_work);
    if (!m) return 0;
    g_ed_work_n = m;
    ed_recount();
    return 1;
}
// Menu: Edit timing on the selected slot. Reads the file, finds the presses, fills the gap table.
static void ed_open(void) {
    const int slot = g_menu.slot;
    if (!g_slot_len[slot]) {
        Notify(TEX_ICON_SYSTEM, "Combo slot %d is empty\nBuild one with Combo tools > Build a combo", slot + 1);
        ed_back();
        return;
    }
    if (!ed_buffers()) { NotifyStatic(TEX_ICON_SYSTEM, "Timing edit: not enough memory"); ed_back(); return; }
    uint32_t hdr_presses = 0;
    const uint32_t n = slot_read(slot, g_ed_orig, &hdr_presses);
    const int P = n ? ce_parse(g_ed_orig, n, g_ed_press, ED_MAX_PRESSES) : -1;
    if (P < 0) {
        Notify(TEX_ICON_SYSTEM, "Combo slot %d: %s", slot + 1,
               n ? "more than 512 presses, too many to edit" : "could not read the file");
        ed_back();
        return;
    }
    if (P == 0) { Notify(TEX_ICON_SYSTEM, "Combo slot %d: no presses in it", slot + 1); ed_back(); return; }
    for (int k = 0; k < P; k++) g_ed_gap0[k] = g_ed_gap[k] = ce_gap_frames(g_ed_press, P, n, k);
    g_ed_n = n; g_ed_P = P; g_ed_slot = slot; g_ed_dirty = 0; g_ed_presses = hdr_presses;
    if (!ed_try_rebuild()) { ed_back(); return; }
    g_menu.ed_n = P; g_menu.ed_cur = 0;
}
// Menu: Left/Right (1 frame) or L1/R1 (6 frames) on the press under the cursor. Clamped to its min..5 s.
static void ed_gap_step(int delta) {
    const int k = g_menu.ed_cur;
    if (k < 0 || k >= g_ed_P) return;
    const int lo = (int)ce_min_gap(g_ed_press, g_ed_P, k);
    int hi = (int)CE_GAP_MAX;
    if (hi < lo) hi = lo;
    int v = (int)g_ed_gap[k] + delta;
    if (v < lo) v = lo;
    if (v > hi) v = hi;
    if ((uint32_t)v == g_ed_gap[k]) return;
    const uint32_t old = g_ed_gap[k];
    g_ed_gap[k] = (uint32_t)v;
    if (!ed_try_rebuild()) {
        g_ed_gap[k] = old;
        NotifyStatic(TEX_ICON_SYSTEM, "Timing: that gap would make the combo too long\nGap kept");
    }
}
// Menu: Triangle puts the press under the cursor back to the gap it had when the editor opened.
static void ed_reset(void) {
    const int k = g_menu.ed_cur;
    if (k < 0 || k >= g_ed_P) return;
    g_ed_gap[k] = g_ed_gap0[k];
    ed_try_rebuild();
}
// Menu: X. Writes the slot only when something changed; the page goes back to the tools on success.
static void ed_save(void) {
    if (!g_ed_dirty) {
        NotifyStatic(TEX_ICON_SYSTEM, "Timing unchanged\nNothing was written");
        ed_back();
        return;
    }
    const uint32_t presses = g_ed_presses;                 // the count the slot already had (presses are not re-counted)
    if (slot_write(g_ed_slot, g_ed_work, g_ed_work_n, presses, slot_source(g_ed_slot)) != 0) {
        Notify(TEX_ICON_SYSTEM, "Combo slot %d: could not write the timing\nThe old timing is kept", g_ed_slot + 1);
        return;
    }
    slot_info_refresh(g_ed_slot, g_ed_work_n, presses);
    const uint32_t hs = ce_hundredths(g_ed_work_n);
    Notify(TEX_ICON_SYSTEM, "Combo slot %d: timing saved\n%u presses, %u.%02u s", g_ed_slot + 1, presses, hs / 100, hs % 100);
    ed_back();
}
// Menu: X on Save (second X when the slot already holds a combo). Builds the maker's presses and writes them.
static void mk_save(int slot) {
    if (!g_menu.mk_n) { NotifyStatic(TEX_ICON_SYSTEM, "Combo maker: add a press first"); return; }
    if (!ed_buffers()) { NotifyStatic(TEX_ICON_SYSTEM, "Combo maker: not enough memory"); return; }
    const uint32_t n = ce_make_build(g_menu.mk, g_menu.mk_n, g_ed_work);
    if (!n) { NotifyStatic(TEX_ICON_SYSTEM, "Combo maker: that combo is too long\nNothing was written"); return; }
    const uint32_t presses = g_menu.mk_n;                  // the presses entered (a direction is one press), as the seed counts them
    if (slot_write(slot, g_ed_work, n, presses, 0) != 0) {
        Notify(TEX_ICON_SYSTEM, "Combo slot %d: could not write the combo\nNothing changed", slot + 1);
        return;
    }
    g_menu.slot = slot;
    slot_cfg_save();
    slot_info_refresh(slot, n, presses);
    const uint32_t hs = ce_hundredths(n);
    Notify(TEX_ICON_SYSTEM, "Combo saved to slot %d\n%u presses, %u.%02u s", slot + 1, presses, hs / 100, hs % 100);
    g_menu.mk_n = 0;
    g_menu.page = PG_TOOLS; g_menu.sub = 1;
}
// Runs the request menu_step left for this sample (menu_logic.h, act).
static void menu_act(void) {
    switch (g_menu.act) {
    case ACT_EDIT_OPEN: ed_open(); break;
    case ACT_EDIT_GAP: ed_gap_step(g_menu.act_arg); break;
    case ACT_EDIT_RESET: ed_reset(); break;
    case ACT_EDIT_SAVE: ed_save(); break;
    case ACT_EDIT_CANCEL: NotifyStatic(TEX_ICON_SYSTEM, "Timing edit cancelled\nNothing was written"); break;
    case ACT_MAKE_CANCEL: NotifyStatic(TEX_ICON_SYSTEM, "Combo maker cancelled\nNothing was written"); break;
    case ACT_MAKE_SAVE: mk_save(g_menu.act_arg); break;
    case ACT_MAKE_NOTE:                                       // v2.18: why an Add or Save did nothing
        if (g_menu.act_arg == MK_NOTE_EMPTY) NotifyStatic(TEX_ICON_SYSTEM, "Pick a direction or a button first");
        else if (g_menu.act_arg == MK_NOTE_FULL) NotifyStatic(TEX_ICON_SYSTEM, "Combo maker: 40 steps is the most\nDelete a step to add another");
        else NotifyStatic(TEX_ICON_SYSTEM, "Add a step first, then Save");
        break;
    default: break;
    }
}

// Builds what the on-screen menu shows (plain C: the host preview draws with this same function).
// v2.17: the Combo tools pages (at most 5 rows, so the panel keeps its size).
static void menu_view_page(OvMenuView *v) {
    static char lb[CE_EDIT_ROWS][24], vb[CE_EDIT_ROWS][24], title[48], nm[16];
    v->strip = 0;
    v->selected = g_menu.sub;
    if (g_menu.page == PG_TOOLS) {
        const int s = g_menu.slot;
        v->title = "COMBO TOOLS";
        v->rows = 3;
        v->label[0] = "Edit timing";
        if (g_slot_len[s]) snprintf(vb[0], sizeof(vb[0]), "slot %d (%u)", s + 1, g_slot_presses[s]);
        else snprintf(vb[0], sizeof(vb[0]), "slot %d empty", s + 1);
        v->value[0] = vb[0];
        v->label[1] = "Build a combo"; v->value[1] = "";
        v->label[2] = "Back"; v->value[2] = "";
        v->footer = "L/R SLOT  X OPEN  O BACK";
    } else if (g_menu.page == PG_EDIT) {
        const int P = g_ed_P;
        int top = g_menu.ed_cur - (int)CE_EDIT_ROWS / 2;
        if (top > P - (int)CE_EDIT_ROWS) top = P - (int)CE_EDIT_ROWS;
        if (top < 0) top = 0;
        const int rows = P < (int)CE_EDIT_ROWS ? P : (int)CE_EDIT_ROWS;
        snprintf(title, sizeof(title), "EDIT TIMING  SLOT %d", g_ed_slot + 1);
        v->title = title;
        v->rows = rows;
        v->selected = g_menu.ed_cur - top;
        for (int r = 0; r < rows; r++) {
            const int k = top + r;
            ce_button_name(nm, sizeof(nm), g_ed_press[k].buttons, 1);
            snprintf(lb[r], sizeof(lb[r]), "%2d %s", k + 1, nm);
            const uint32_t hs = ce_hundredths(g_ed_gap[k]);
            snprintf(vb[r], sizeof(vb[r]), k + 1 == P ? "tail %u.%02us" : "gap %u.%02us", hs / 100, hs % 100);
            v->label[r] = lb[r];
            v->value[r] = vb[r];
            v->value_kind[r] = g_ed_gap[k] != g_ed_gap0[k] ? 3 : 0;   // yellow = changed, not saved yet
        }
        v->footer = "L/R 1 FRAME  L1/R1 6  X SAVE  O CANCEL";
    } else if (g_menu.page == PG_MAKE) {
        // v2.18 one-screen builder: CE_MAKE_VIS step rows (scrolled, plain values), then the five input rows.
        static char mlb[CE_MAKE_ROWS][64], mvb[CE_MAKE_ROWS][24];
        const int n = g_menu.mk_n, top = g_menu.mk_top;
        snprintf(title, sizeof(title), "BUILD A COMBO  %d STEP%s", n, n == 1 ? "" : "S");
        v->title = title;
        v->rows = CE_MAKE_ROWS;
        v->strip = 0;
        v->plain_rows = (int)CE_MAKE_VIS;
        v->selected = g_menu.sub < n ? g_menu.sub - top : (int)CE_MAKE_VIS + (g_menu.sub - n);
        for (int r = 0; r < (int)CE_MAKE_VIS; r++) {
            const int k = top + r;
            mlb[r][0] = mvb[r][0] = 0;
            if (k < n) {
                char name[40];
                ce_step_name(name, sizeof(name), g_menu.mk[k].buttons);
                snprintf(mlb[r], sizeof(mlb[r]), "%2d %s", k + 1, name);
                snprintf(mvb[r], sizeof(mvb[r]), "%u.%02us", g_menu.mk[k].cs / 100, g_menu.mk[k].cs % 100);
            } else if (r == 0 && n == 0) snprintf(mlb[r], sizeof(mlb[r]), "No steps yet");
            v->label[r] = mlb[r];
            v->value[r] = mvb[r];
        }
        const int in = (int)CE_MAKE_VIS;
        const uint32_t gcs = (uint32_t)g_menu.mk_gap;
        v->label[in + 0] = "Direction";   v->value[in + 0] = CE_DIR_NAME[g_menu.mk_dir];
        v->label[in + 1] = "Button";      v->value[in + 1] = CE_BTN_NAME[g_menu.mk_btn];
        v->label[in + 2] = "Gap after it"; snprintf(vb[2], sizeof(vb[2]), "%u.%02us", gcs / 100, gcs % 100); v->value[in + 2] = vb[2];
        v->label[in + 3] = "Add step";    v->value[in + 3] = "X";
        v->label[in + 4] = "Save";        v->value[in + 4] = n ? "X, choose a slot" : "add a step first";
        v->footer = "X ADD  L/R CHANGE  TRI DELETE  O CANCEL";
    } else {   // PG_MAKE_SLOT
        const int full = (g_menu.full_mask >> g_menu.mk_slot) & 1u;
        snprintf(title, sizeof(title), "SAVE COMBO TO A SLOT");
        v->title = title;
        v->rows = 3;
        v->label[0] = "Slot";
        snprintf(vb[0], sizeof(vb[0]), "%d%s", g_menu.mk_slot + 1, full ? " (has one)" : " (empty)");
        v->value[0] = vb[0];
        v->label[1] = "Save";
        v->value[1] = g_menu.mk_armed ? "X AGAIN = REPLACE" : "X";
        v->value_kind[1] = g_menu.mk_armed ? 2 : 0;
        v->label[2] = "Back"; v->value[2] = "";
        v->footer = "L/R SLOT  X SAVE  O BACK";
    }
}

static void menu_view_fill(OvMenuView *v, const char *ovl_text) {
    static char slot_text[40], foot_text[64];
    memset(v, 0, sizeof(*v));
    if (g_menu.page != PG_MAIN) { menu_view_page(v); return; }
    v->rows = ITEM_COUNT; v->selected = g_menu.selected;
    v->title = "TEKKEN 7 MOD MENU";
    v->footer = "D-PAD SELECT/CHANGE   O CLOSE";
    for (int i = 0; i < 2; i++) {
        v->label[i] = i == 0 ? "P1 Health" : "P2 Health";
        v->value[i] = menu_value(g_menu.health[i]);
        v->value_kind[i] = menu_value_kind(g_menu.health[i]);
    }
    v->label[ITEM_SLOT] = "Combo slot";
    if (g_menu.clear_armed) { snprintf(slot_text, sizeof(slot_text), "Clear? SQUARE"); v->value_kind[ITEM_SLOT] = 2; }
    else { slot_value_text(slot_text, sizeof(slot_text), g_menu.slot, 0); v->value_kind[ITEM_SLOT] = g_slot_len[g_menu.slot] ? 1 : 0; }
    v->value[ITEM_SLOT] = slot_text;
    v->strip = 1; v->strip_row = ITEM_SLOT; v->strip_sel = g_menu.slot;
    for (int i = 0; i < SLOT_COUNT; i++) if (g_slot_len[i]) v->strip_full |= 1u << i;
    v->label[ITEM_SPEED] = "Game speed";
    v->value[ITEM_SPEED] = menu_speed_name(g_menu.speed);
    v->value_kind[ITEM_SPEED] = g_menu.speed ? 3 : 0;
    v->label[ITEM_OVERLAY] = "Overlay"; v->value[ITEM_OVERLAY] = ovl_text;
    if (g_menu.selected == ITEM_OVERLAY && g_ov_timing[0]) v->footer = g_ov_timing;   // v2.14: draw timing
    if (g_menu.selected == ITEM_SLOT)
        v->footer = g_menu.clear_armed ? "SQUARE AGAIN = CLEAR   ANY OTHER = NO" : "L3+R3 REC  R3/L3 PLAY  SQUARE CLEAR";
    else if (g_menu.selected == ITEM_SPEED) {
        const char *what = g_menu.speed ? "SLOW-MO STARTS ON CLOSE" : "NORMAL SPEED";
        if (g_pacer.rate) snprintf(foot_text, sizeof(foot_text), "%s   PAD %u/S", what, g_pacer.rate);
        else snprintf(foot_text, sizeof(foot_text), "%s", what);
        v->footer = foot_text;
    }
}

#ifndef TK_HOST_TEST
// ---- on-screen overlay: draws into the game's VideoOut display buffers (tiled or linear) ----
HOOK_INIT(sceVideoOutRegisterBuffers);
HOOK_INIT(sceVideoOutUnregisterBuffers);
HOOK_INIT(sceVideoOutSubmitFlip);
typedef struct {
    uint8_t *addr;
    OrbisVideoOutBufferAttribute attr;
    int group, valid;
    int checked_layout;      // layout the cached check below is for (-1 = none)
    int ok;                  // drawable with that layout
    uint64_t size;           // bytes known mapped + CPU-writable from addr
} OvBuf;
static OvBuf ov_bufs[16];
static int video_handle = -1;
static OrbisPthreadMutex buffer_lock;
static int buffer_lock_ready;
static volatile int renderer_running;
static OrbisPthread renderer_thread;
static int g_is_neo;
static volatile int g_reg_count, g_last_ok, g_overlay_broken;
static volatile uint32_t g_flips_seen, g_draws_ok, g_flip_hook_calls;
static int g_flip_hooked, g_event_mode;
static int g_diag_shown, g_nobuf_shown, g_broken_shown;
static char g_last_reason[96];
static uint8_t *g_canvas;
static size_t g_canvas_cap;
static OvGeom g_geom;
static struct { int valid, sel, h0, h1, ovl, layout, rows; uint32_t w, h, gen; } g_ckey;

static int ov_layout_for(const OrbisVideoOutBufferAttribute *a, int choice) {
    switch (choice) {
    case OVL_PS4: return OV_LAYOUT_PS4;
    case OVL_PRO_A: return OV_LAYOUT_PRO_A;
    case OVL_PRO_B: return OV_LAYOUT_PRO_B;
    case OVL_LINEAR: return OV_LAYOUT_LINEAR;
    case OVL_OFF: return -1;
    default: break;
    }
    if (a->tmode == ORBIS_VIDEO_OUT_TILING_MODE_LINEAR) return OV_LAYOUT_LINEAR;
    if (a->tmode == ORBIS_VIDEO_OUT_TILING_MODE_TILE) return g_is_neo ? OV_LAYOUT_PRO_B : OV_LAYOUT_PS4;
    return -1;
}

// Checks one buffer for a layout; caches the answer. Called with buffer_lock held.
static const char *ov_check(OvBuf *b, int layout) {
    if (b->checked_layout == layout) return b->ok ? NULL : g_last_reason;
    b->checked_layout = layout; b->ok = 0; b->size = 0;
    const OrbisVideoOutBufferAttribute *a = &b->attr;
    const char *why = NULL;
    OvGeom g;
    if (layout < 0) why = "overlay set to Off";
    else if (!ov_format_supported((uint32_t)a->format)) why = "pixel format not supported";
    else if (a->tmode != 0 && a->tmode != 1) why = "unknown tiling mode";
    else if (a->width < 640 || a->height < 360 || a->width > 4096 || a->height > 2304) why = "unexpected size";
    else if (a->pixelPitch < a->width || a->pixelPitch > 4096) why = "unexpected pitch";
    else if (layout != OV_LAYOUT_LINEAR && (a->pixelPitch % 128u)) why = "pitch not tile aligned";
    else if (!ov_geom_bottom_wide(&g, a->width, a->height, CE_MAKE_ROWS, 0, 120)) why = "menu does not fit";   // v2.18: the builder page, the widest one
    if (!why) {
        uint64_t want = ov_surface_bytes(layout, a->pixelPitch, a->height);
        uint64_t at = (uint64_t)(uintptr_t)b->addr;
        void *st = 0, *en = 0; int32_t prot = 0;
        if (!at || sceKernelQueryMemoryProtection(b->addr, &st, &en, &prot) < 0 || (uint64_t)(uintptr_t)st > at)
            why = "buffer memory not found";
        else {
            uint64_t avail = (uint64_t)(uintptr_t)en - at;
            uint64_t minimum = (uint64_t)a->pixelPitch * a->height * 4u;
            if (avail < minimum) why = "buffer smaller than expected";
            else {
                b->size = avail < want ? avail : want;
                if ((prot & 3) != 3) {
                    // GPU-only mapping: ask for CPU read/write on top of what the game set.
                    uint64_t len = (b->size + 0x3fffu) & ~(uint64_t)0x3fff;
                    if (len > avail) len = avail & ~(uint64_t)0x3fff;
                    if (len < b->size || sceKernelMprotect(b->addr, len, prot | 3) != 0) why = "buffer not CPU-writable";
                    else if (sceKernelQueryMemoryProtection(b->addr, &st, &en, &prot) < 0 || (prot & 3) != 3) why = "buffer not CPU-writable";
                }
            }
        }
    }
    if (why) { snprintf(g_last_reason, sizeof(g_last_reason), "%s", why); return g_last_reason; }
    b->ok = 1;
    return NULL;
}

static void ov_view(OvMenuView *v, int layout) {
    static char ovl_text[24];
    if (g_menu.ovl == OVL_AUTO)
        snprintf(ovl_text, sizeof(ovl_text), "Auto: %s", layout == OV_LAYOUT_LINEAR ? "Linear" : layout == OV_LAYOUT_PS4 ? "PS4"
                                                     : layout == OV_LAYOUT_PRO_A ? "Pro A" : "Pro B");
    else snprintf(ovl_text, sizeof(ovl_text), "%s", menu_ovl_name(g_menu.ovl));
    menu_view_fill(v, ovl_text);
}

// v2.14 draw timing, shown in the Overlay row footer (one-second window, renderer thread only).
static struct { uint64_t win_start, sum_ready, max_ready, sum_dur, max_dur; uint32_t n, n_ready; } g_ovt;
static void ov_timing_add(uint64_t flip_us, uint64_t t0, uint64_t t1) {
    const uint64_t dur = t1 - t0;
    g_ovt.n++; g_ovt.sum_dur += dur; if (dur > g_ovt.max_dur) g_ovt.max_dur = dur;
    if (flip_us && flip_us <= t0 && t0 - flip_us < 100000) {   // flip time usable (process-time clock)
        const uint64_t ready = t1 - flip_us;
        g_ovt.n_ready++; g_ovt.sum_ready += ready; if (ready > g_ovt.max_ready) g_ovt.max_ready = ready;
    }
    if (!g_ovt.win_start) g_ovt.win_start = t1;
    if (t1 - g_ovt.win_start < 1000000) return;
    char t[48];
    if (g_ovt.n_ready) {
        const uint64_t a = (g_ovt.sum_ready / g_ovt.n_ready + 50) / 100, mx = (g_ovt.max_ready + 50) / 100;
        snprintf(t, sizeof(t), "MENU READY %u.%uMS AFTER FLIP (MAX %u.%u)", (unsigned)(a / 10), (unsigned)(a % 10),
                 (unsigned)(mx / 10), (unsigned)(mx % 10));
    } else {
        const uint64_t a = (g_ovt.sum_dur / g_ovt.n + 50) / 100, mx = (g_ovt.max_dur + 50) / 100;
        snprintf(t, sizeof(t), "DRAW %u.%uMS (MAX %u.%u)", (unsigned)(a / 10), (unsigned)(a % 10), (unsigned)(mx / 10), (unsigned)(mx % 10));
    }
    if (strcmp(t, g_ov_timing) != 0) {
        snprintf(g_ov_timing, sizeof(g_ov_timing), "%s", t);
        if (g_menu.selected == ITEM_OVERLAY) g_view_gen++;   // shown only on the Overlay row
    }
    memset(&g_ovt, 0, sizeof(g_ovt)); g_ovt.win_start = t1;
}

// Draws the menu into buffer idx. Called with buffer_lock held. Returns 1 when pixels were written.
// flip_us = process time of the flip that put idx on screen (0 = not known / CPU-flip path).
// v2.14 order: the picture already rendered is copied FIRST (the frame gets a complete menu at once,
// even when the menu just changed), then a changed menu is rendered and copied again over it, so a
// change shows up in the same frame without ever leaving a frame half-drawn by a slow render.
// v2.18: the builder page has its own panel (CE_MAKE_ROWS rows, no slot strip, 120 % wide); every other page keeps v1.09's.
static void ov_page_layout(int *rows, int *strip, uint32_t *wpct) {
    if (g_menu.page == PG_MAKE) { *rows = (int)CE_MAKE_ROWS; *strip = 0; *wpct = 120; }
    else { *rows = ITEM_COUNT; *strip = 1; *wpct = 100; }
}

static int ov_draw_buffer(int idx, uint64_t flip_us) {
    if (!g_menu.open || idx < 0 || idx >= 16 || !ov_bufs[idx].valid) return 0;
    OvBuf *b = &ov_bufs[idx];
    const int layout = ov_layout_for(&b->attr, g_menu.ovl);
    if (ov_check(b, layout)) { g_last_ok = 0; return 0; }
    const uint64_t t0 = sceKernelGetProcessTime();
    OvGeom g;
    int rows, strip; uint32_t wpct;
    ov_page_layout(&rows, &strip, &wpct);
    if (!ov_geom_bottom_wide(&g, b->attr.width, b->attr.height, rows, strip, wpct)) return 0;
    const int geom_same = g_ckey.valid && g_ckey.layout == layout && g_ckey.w == b->attr.width && g_ckey.h == b->attr.height &&
                          g_ckey.rows == rows;
    const uint32_t gen = g_view_gen;
    const int content_same = geom_same && g_ckey.sel == g_menu.selected && g_ckey.h0 == g_menu.health[0] &&
                             g_ckey.h1 == g_menu.health[1] && g_ckey.ovl == g_menu.ovl && g_ckey.gen == gen;
    uint32_t n = 0;
    if (geom_same) n = ovf_blit(b->addr, b->size, layout, b->attr.pixelPitch, (uint32_t)b->attr.format, g_canvas, &g_geom);
    if (!content_same) {
        size_t need = (size_t)g.w * g.h;
        if (need > g_canvas_cap) {
            free(g_canvas);
            g_canvas = (uint8_t *)malloc(need);
            g_canvas_cap = g_canvas ? need : 0;
            if (!g_canvas) { g_ckey.valid = 0; return 0; }
        }
        OvMenuView v;
        ov_view(&v, layout);
        ovf_render(g_canvas, &g, &v, font8x8_basic, 1);
        g_geom = g;
        g_ckey.valid = 1; g_ckey.sel = g_menu.selected; g_ckey.h0 = g_menu.health[0]; g_ckey.h1 = g_menu.health[1];
        g_ckey.ovl = g_menu.ovl; g_ckey.layout = layout; g_ckey.w = b->attr.width; g_ckey.h = b->attr.height;
        g_ckey.gen = gen; g_ckey.rows = rows;
        n = ovf_blit(b->addr, b->size, layout, b->attr.pixelPitch, (uint32_t)b->attr.format, g_canvas, &g_geom);
    }
    __asm__ __volatile__("sfence" ::: "memory");
    if (n) { g_draws_ok++; g_last_ok = 1; if (flip_us) ov_timing_add(flip_us, t0, sceKernelGetProcessTime()); }
    return n != 0;
}

int32_t sceVideoOutRegisterBuffers_hook(int32_t h, int32_t first, void *const *p, int32_t n, const OrbisVideoOutBufferAttribute *a) {
    int32_t ret = HOOK_CONTINUE(sceVideoOutRegisterBuffers, int32_t(*)(int32_t, int32_t, void *const *, int32_t, const OrbisVideoOutBufferAttribute *), h, first, p, n, a);
    if (!g_menu_enabled || !buffer_lock_ready || ret < 0 || !a || !p || first < 0 || n <= 0 || first + n > 16) return ret;
    scePthreadMutexLock(&buffer_lock);
    video_handle = h;
    for (int i = 0; i < n; i++) {
        OvBuf *b = &ov_bufs[first + i];
        b->addr = (uint8_t *)p[i]; b->attr = *a; b->group = ret; b->valid = 1; b->checked_layout = -2; b->ok = 0;
    }
    g_reg_count++;
    const int layout = ov_layout_for(a, g_menu.ovl);
    const char *why = ov_check(&ov_bufs[first], layout);
    void *st = 0, *en = 0; int32_t prot = -1;
    sceKernelQueryMemoryProtection(p[0], &st, &en, &prot);
    scePthreadMutexUnlock(&buffer_lock);
    if (!g_diag_shown) {   // one diagnostic per game launch: what the game's screen buffers are
        g_diag_shown = 1;
        char text[256];
        snprintf(text, sizeof(text), "Mod Menu overlay: %s 0x%08x, tile mode %d, %ux%u pitch %u, %d buffers, %s, mem 0x%x\n%s%s",
                 ov_format_name((uint32_t)a->format), (uint32_t)a->format, a->tmode, a->width, a->height, a->pixelPitch, n,
                 g_is_neo ? "Pro mode" : "PS4 mode", prot, why ? "OFF: " : "ON: ", why ? why : ov_layout_name(layout));
        NotifyStatic(TEX_ICON_SYSTEM, text);
    }
    return ret;
}
int32_t sceVideoOutUnregisterBuffers_hook(int32_t h, int32_t group) {
    if (buffer_lock_ready) scePthreadMutexLock(&buffer_lock);
    int32_t ret = HOOK_CONTINUE(sceVideoOutUnregisterBuffers, int32_t(*)(int32_t, int32_t), h, group);
    if (ret >= 0 && h == video_handle)
        for (int i = 0; i < 16; i++) if (ov_bufs[i].valid && ov_bufs[i].group == group) ov_bufs[i].valid = 0;
    if (buffer_lock_ready) scePthreadMutexUnlock(&buffer_lock);
    return ret;
}
// Games that flip from the CPU: draw into the buffer that is about to be shown, right before the flip.
int32_t sceVideoOutSubmitFlip_hook(int32_t h, int32_t idx, uint32_t mode, int64_t arg) {
    g_flip_hook_calls++;
    if (g_menu.open && buffer_lock_ready && h == video_handle && idx >= 0 && idx < 16 && scePthreadMutexTrylock(&buffer_lock) == 0) {
        ov_draw_buffer(idx, 0);
        scePthreadMutexUnlock(&buffer_lock);
    }
    return HOOK_CONTINUE(sceVideoOutSubmitFlip, int32_t(*)(int32_t, int32_t, uint32_t, int64_t), h, idx, mode, arg);
}

// Games that flip from the GPU (sceGnmSubmitAndFlipCommandBuffers; Unreal Engine games like Tekken 7
// most likely do): the GPU is still rendering the frame when that call returns, so drawing then would
// be overwritten. Instead this thread wakes on our own flip event (or polls the flip status) and
// draws into the buffer that has just gone on screen. It has to finish before the scan-out reaches
// the panel's rows; v2.10-v2.13 often did not (default priority, unoptimised copy, panel higher up).
// v2.14: this thread now runs at the highest thread priority (256), so it is not left waiting behind
// the game's busy threads right after a flip (the likely cause of the late draws in his video). It
// sleeps on the flip event almost all the time and its work per frame is one copy of the panel,
// about a millisecond, only while the menu is open. If the priority call fails it runs as before.
#define TK_RENDER_PRIO 256
static int g_render_prio_rc = 1;
static void *renderer(void *arg) {
    (void)arg;
    g_render_prio_rc = scePthreadSetprio(scePthreadSelf(), TK_RENDER_PRIO);
    OrbisKernelEqueue eq = 0;
    int eq_ok = 0, eq_tried = 0;
    uint64_t last_num = (uint64_t)-1, open_since = 0;
    uint32_t draws_at_open = 0;
    int broken_key = -1;
    while (renderer_running) {
        const int h = video_handle;
        if (h >= 0 && !eq_tried) {
            eq_tried = 1;
            if (sceKernelCreateEqueue(&eq, "tkmod_flip") == 0) {
                if (sceVideoOutAddFlipEvent(eq, h, NULL) == 0) eq_ok = 1;
                else sceKernelDeleteEqueue(eq);
            }
            g_event_mode = eq_ok;
        }
        if (eq_ok) {
            OrbisKernelEvent ev; int got = 0; OrbisKernelUseconds to = 100000;
            int r = sceKernelWaitEqueue(eq, &ev, 1, &got, &to);
            if (r < 0 && (uint32_t)r != 0x8002003cu) { sceKernelDeleteEqueue(eq); eq_ok = 0; g_event_mode = 0; }  // not a timeout
        } else {
            sceKernelUsleep(g_menu.open ? 1000 : 50000);
        }
        if (!g_menu.open) { open_since = 0; continue; }
        if (!open_since) {
            open_since = sceKernelGetProcessTime(); draws_at_open = g_draws_ok;
            memset(&g_ovt, 0, sizeof(g_ovt));
            // retry after a "nothing drawn" only when something changed (layout choice or new buffers)
            const int key = g_menu.ovl * 100000 + g_reg_count;
            if (key != broken_key) g_overlay_broken = 0;
        }
        if (g_overlay_broken && g_menu.ovl * 100000 + g_reg_count != broken_key) { g_overlay_broken = 0; open_since = sceKernelGetProcessTime(); draws_at_open = g_draws_ok; }
        if (h >= 0) {
            OrbisVideoOutFlipStatus f; memset(&f, 0, sizeof(f));
            if (sceVideoOutGetFlipStatus(h, &f) == 0 && f.num != last_num) {
                last_num = f.num; g_flips_seen++;
                scePthreadMutexLock(&buffer_lock);
                ov_draw_buffer(f.currentBuffer, f.ptime ? f.ptime : 1);
                scePthreadMutexUnlock(&buffer_lock);
            }
        }
        // Menu open for 2 s and nothing drawn: say why once, and fall back to notifications.
        if (!g_overlay_broken && g_menu.ovl != OVL_OFF && g_draws_ok == draws_at_open && sceKernelGetProcessTime() - open_since > 2000000) {
            g_overlay_broken = 1; broken_key = g_menu.ovl * 100000 + g_reg_count;
            if (!g_broken_shown) {
                g_broken_shown = 1;
                Notify(TEX_ICON_SYSTEM, "Mod Menu overlay: nothing drawn (%s; flips %u, flip calls %u, %s). Using notifications.",
                       g_last_reason[0] ? g_last_reason : "no reason", g_flips_seen, g_flip_hook_calls, g_event_mode ? "event" : "poll");
                menu_announce();
            }
        }
    }
    if (eq_ok) sceKernelDeleteEqueue(eq);
    return 0;
}

static int overlay_ready(void) {
    if (!buffer_lock_ready || g_menu.ovl == OVL_OFF || g_overlay_broken || video_handle < 0) return 0;
    for (int i = 0; i < 16; i++) {
        OvBuf *b = &ov_bufs[i];
        if (!b->valid) continue;
        int layout = ov_layout_for(&b->attr, g_menu.ovl);
        if (b->checked_layout == layout) return b->ok;
        return layout >= 0 && ov_format_supported((uint32_t)b->attr.format);   // checked on the next draw
    }
    return 0;
}
static void overlay_on_open(void) {
    if (g_reg_count == 0 && !g_nobuf_shown && g_menu.ovl != OVL_OFF) {
        g_nobuf_shown = 1;
        NotifyStatic(TEX_ICON_SYSTEM, "Mod Menu overlay: the game's screen buffers were not seen (registered before the plugin loaded). Using notifications.");
    }
}
static int hook_safe(const void *fn) {   // never chain onto someone else's detour (jmp at the entry)
    unsigned char c = *(const unsigned char *)fn;
    return c != 0xe9 && c != 0xff && c != 0xeb;
}
static void overlay_start(void) {
    if (scePthreadMutexInit(&buffer_lock, NULL, "tkmod-buffer") != 0) return;   // notification mode
    for (int i = 0; i < 16; i++) ov_bufs[i].checked_layout = -2;
    g_is_neo = sceKernelIsNeoMode() == 1;
    buffer_lock_ready = 1;
    if (hook_safe((const void *)(uintptr_t)sceVideoOutRegisterBuffers) && hook_safe((const void *)(uintptr_t)sceVideoOutUnregisterBuffers)) {
        HOOK32(sceVideoOutRegisterBuffers);
        HOOK32(sceVideoOutUnregisterBuffers);
    }
    if (hook_safe((const void *)(uintptr_t)sceVideoOutSubmitFlip)) { HOOK32(sceVideoOutSubmitFlip); g_flip_hooked = 1; }
    renderer_running = 1;
    if (scePthreadCreate(&renderer_thread, NULL, renderer, NULL, "tkmod-render") != 0) renderer_running = 0;
}
static void overlay_stop(void) {
    renderer_running = 0;
    if (renderer_thread) scePthreadJoin(renderer_thread, NULL);
    if (Detour_sceVideoOutSubmitFlip.StubPtr) UNHOOK(sceVideoOutSubmitFlip);
    if (Detour_sceVideoOutRegisterBuffers.StubPtr) UNHOOK(sceVideoOutRegisterBuffers);
    if (Detour_sceVideoOutUnregisterBuffers.StubPtr) UNHOOK(sceVideoOutUnregisterBuffers);
    if (buffer_lock_ready) { scePthreadMutexDestroy(&buffer_lock); buffer_lock_ready = 0; }
    free(g_canvas); g_canvas = NULL; g_canvas_cap = 0;
}
#else
int g_test_overlay_ready;
static int overlay_ready(void) { return g_test_overlay_ready && g_menu.ovl != OVL_OFF; }
static void overlay_on_open(void) {}
static void overlay_start(void) {}
static void overlay_stop(void) {}
#endif
// ===================================== end mod menu =====================================

// Handles one pad sample. Called with the lock held.
static void process_sample(int32_t handle, OrbisPadData *d, uint32_t source) {
    HandleState *h = hs_get(handle);
    if (!h) return;

    // Mod menu sees the real pad first; when it consumes the sample the combo engine is skipped.
    if (g_menu_enabled && menu_filter(h, handle, d)) return;

    uint32_t real = d->buttons;
    uint32_t pressed_now = real & ~h->prev_real;
    int l3 = (real & BTN_L3) != 0, r3 = (real & BTN_R3) != 0;
    int chord_event = 0, solo_event = 0;
    uint32_t solo_btn = 0;

    // ---- trigger detection on the real pad ----
    if (l3 && r3) {
        if (!h->chord_used) { h->chord_used = 1; chord_event = 1; }
        h->solo_pending = 0;
    } else if (l3 || r3) {
        if (!h->chord_used && !h->solo_pending) { h->solo_pending = 1; h->solo_btn = real & BTN_TRIGGERS; }
    } else {
        if (h->solo_pending && !h->chord_used && !h->suppress) { solo_event = 1; solo_btn = h->solo_btn; }
        h->solo_pending = 0; h->chord_used = 0; h->suppress = 0;
    }

    // ---- state machine ----
    if (g_state == ST_PLAYING && handle == g_owner) {
        // cancel on any new real press (including L3/R3)
        if ((pressed_now & ~BTN_INTERCEPT) != 0) {
            play_stop();
            if (pressed_now & BTN_TRIGGERS) { h->suppress = 1; h->chord_used = 1; }
            chord_event = solo_event = 0;
        } else if (g_play_idx < g_slot_count) {
            // one step per game frame; at 100 % (and always on scePadReadState) one step per sample exactly
            // as v2.12; slowed + buffered scePadRead: the gate keeps the steps on game time (pace_logic.h)
            apply_step(d, &g_slot[g_play_idx], g_play_mirror);
            if (gate_sample(&g_gate, source, SPEED_NUM[g_menu.speed], SPEED_DEN[g_menu.speed], g_call_first, g_call_last))
                g_play_idx++;
            if (g_play_idx >= g_slot_count) play_stop();
            h->prev_real = real;
            return;
        } else {
            play_stop();
        }
    }

    if (chord_event) {
        if (g_state == ST_IDLE) record_start(handle, source);
        else if (g_state == ST_RECORDING && handle == g_owner) record_stop();
    } else if (solo_event && g_state == ST_IDLE) {
        play_start(handle, solo_btn == BTN_L3);
    }

    if (g_state == ST_RECORDING && handle == g_owner && !chord_event) {
        if (g_rec_wait_release) {
            if (!l3 && !r3) g_rec_wait_release = 0;
        }
        if (!g_rec_wait_release) {
            if ((l3 || r3) && g_rec_mark == UINT32_MAX) g_rec_mark = g_rec_count;
            if (!l3 && !r3) g_rec_mark = UINT32_MAX;
            MacroStep s;
            fill_step(&s, d);
            if (!g_rec_started && !step_is_neutral(&s)) { g_rec_started = 1; g_rec_t0 = d->timestamp; }
            if (g_rec_started &&
                gate_sample(&g_gate, source, SPEED_NUM[g_menu.speed], SPEED_DEN[g_menu.speed], g_call_first, g_call_last)) {
                s.t_us = (uint32_t)(d->timestamp - g_rec_t0);
                if (g_rec_count < MAX_STEPS) g_rec[g_rec_count++] = s;
                if (g_rec_count >= MAX_STEPS) { g_rec_mark = UINT32_MAX; record_stop(); }
            }
        }
    }

    h->prev_real = real;
    d->buttons &= ~BTN_TRIGGERS;   // the game never sees L3/R3
}

// v2.13 slow motion: runs before the real read, outside the combo lock. At 100 % (the default) and
// while the menu is open it never sleeps. Only one controller + read kind is paced (pace_logic.h).
static void speed_pace(int32_t handle, uint32_t source) {
    if (!g_menu_enabled) return;
    if (__atomic_test_and_set(&g_pace_lock, __ATOMIC_ACQUIRE)) return;
    uint64_t wait = 0;
    const uint64_t now = tk_now_us();
    if (pace_is_key(&g_pacer, handle, source, now)) {
        const uint32_t old_rate = g_pacer.rate;
        pace_measure(&g_pacer, now);
        if (g_pacer.rate != old_rate && g_menu.open && g_menu.selected == ITEM_SPEED) g_view_gen++;   // v2.14: only when shown
        const int sp = g_menu.open ? SPEED_100 : g_menu.speed;
        wait = pace_step(&g_pacer, now, pace_period_us(SPEED_NUM[sp], SPEED_DEN[sp]));
    }
    __atomic_clear(&g_pace_lock, __ATOMIC_RELEASE);
    tk_sleep_us(wait);
}

int32_t scePadRead_hook(int32_t handle, OrbisPadData *pData, int32_t num) {
    speed_pace(handle, 1);
    int32_t ret = scePadReadExt(handle, pData, num);
    if (ret <= 0 || pData == NULL) return ret;
    if (!lock_try()) return ret;
    for (int32_t i = 0; i < ret; i++) { g_call_first = i == 0; g_call_last = i == ret - 1; process_sample(handle, &pData[i], 1); }
    lock_release();
    return ret;
}

int32_t scePadReadState_hook(int32_t handle, OrbisPadData *pData) {
    speed_pace(handle, 2);
    int32_t ret = scePadReadStateExt(handle, pData);
    if (ret != 0 || pData == NULL) return ret;
    if (!lock_try()) return ret;
    g_call_first = g_call_last = 1;
    process_sample(handle, pData, 2);
    lock_release();
    return ret;
}

s32 attr_public plugin_load(s32 argc, const char *argv[]) {
    final_printf("[GoldHEN] <%s\\Ver.0x%08x> %s\n", g_pluginName, g_pluginVersion, __func__);
    final_printf("[GoldHEN] Plugin Author(s): %s\n", g_pluginAuth);
    boot_ver();

    g_slot = (MacroStep *)malloc(MAX_STEPS * sizeof(MacroStep));
    g_rec = (MacroStep *)malloc(MAX_STEPS * sizeof(MacroStep));
    if (!g_slot || !g_rec) {
        final_printf("out of memory\n");
        return -1;
    }
    memset(g_hs, 0, sizeof(g_hs));
    g_slot_count = 0;
    menu_init(&g_menu);          // slot 1, speed 100 %
    memset(&g_pacer, 0, sizeof(g_pacer));
    gate_reset(&g_gate);
    slot10_seed();               // v2.16: slot 10 gets the fixed combo if it has no file yet
    slot_cfg_load();             // v2.13: the slot picked last time (all Tekken IDs)
    slots_scan();
    macro_load();                // the selected slot -> R3 / L3

    // Mod menu only on the exact build the TLH health offsets are for.
    g_menu_enabled = 0;
    struct proc_info info;
    memset(&info, 0, sizeof(info));
    if (sys_sdk_proc_info(&info) == 0 && strncmp(info.titleid, "CUSA06014", sizeof(info.titleid)) == 0 &&
        strncmp(info.version, "05.10", sizeof(info.version)) == 0 && info.base_address) {
        g_eboot_base = info.base_address;
        g_menu_enabled = 1;
    }

    char module[256];
    snprintf(module, sizeof(module), "/%s/common/lib/%s", sceKernelGetFsSandboxRandomWord(), "libScePad.sprx");
    int h = 0;
    sys_dynlib_load_prx(module, &h);

    scePadReadExtPatcher = (Patcher *)malloc(sizeof(Patcher));
    scePadReadStateExtPatcher = (Patcher *)malloc(sizeof(Patcher));
    Patcher_Construct(scePadReadExtPatcher);
    Patcher_Construct(scePadReadStateExtPatcher);

    // Same patch as gamepad_helper: make the *Ext variants behave like the plain calls,
    // so the hooks can call them instead of the (now detoured) originals.
    uint8_t xor_ecx_ecx[5] = {0x31, 0xC9, 0x90, 0x90, 0x90};
    Patcher_Install_Patch(scePadReadExtPatcher, (uint64_t)scePadReadExt, xor_ecx_ecx, sizeof(xor_ecx_ecx));
    uint8_t xor_edx_edx[5] = {0x31, 0xD2, 0x90, 0x90, 0x90};
    Patcher_Install_Patch(scePadReadStateExtPatcher, (uint64_t)scePadReadStateExt, xor_edx_edx, sizeof(xor_edx_edx));

    HOOK32(scePadRead);
    HOOK32(scePadReadState);

    if (g_menu_enabled) { overlay_cfg_load(); overlay_start(); }

    char combo_line[64];
    if (g_slot_count) snprintf(combo_line, sizeof(combo_line), " (combo slot %d loaded: %u frames)", g_menu.slot + 1, g_slot_count);
    else snprintf(combo_line, sizeof(combo_line), " (combo slot %d)", g_menu.slot + 1);
    if (g_menu_enabled)
        Notify(TEX_ICON_SYSTEM, "Tekken Combo + Mod Menu ON (v2.18)%s\nMenu: L3 + OPTIONS\nL3+R3 rec | R3 play | L3 mirror", combo_line);
    else
        Notify(TEX_ICON_SYSTEM, "Combo Macro ON%s\nL3+R3 rec | R3 play | L3 mirror\n(mod menu needs CUSA06014 v05.10)", combo_line);
    return 0;
}

s32 attr_public plugin_unload(s32 argc, const char *argv[]) {
    final_printf("[GoldHEN] <%s\\Ver.0x%08x> %s\n", g_pluginName, g_pluginVersion, __func__);
    if (g_menu_enabled) {
        overlay_stop();
        if (g_cave_installed) { g_menu.health[0] = g_menu.health[1] = 0; health_apply(); }
        g_menu_enabled = 0;
    }
    UNHOOK(scePadRead);
    UNHOOK(scePadReadState);
    Patcher_Destroy(scePadReadExtPatcher);
    Patcher_Destroy(scePadReadStateExtPatcher);
    free(scePadReadExtPatcher);
    free(scePadReadStateExtPatcher);
    return 0;
}

s32 attr_module_hidden module_start(s64 argc, const void *args) { return 0; }
s32 attr_module_hidden module_stop(s64 argc, const void *args) { return 0; }
