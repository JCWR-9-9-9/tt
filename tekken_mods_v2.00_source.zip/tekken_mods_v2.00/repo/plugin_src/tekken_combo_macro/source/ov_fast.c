// ov_fast.c — v2.14: the overlay's per-frame copy and the menu rasteriser, in their own file so the
// Makefile can build exactly these at -O2 (the rest of the plugin keeps its v2.13 build flags).
// Plain C, no PS4 calls, no globals: the code lives in overlay_draw.h and is host-tested there.
#include "ov_fast.h"
uint32_t ovf_blit(uint8_t *buf, uint64_t size, int layout, uint32_t pitch, uint32_t fmt, const uint8_t *cv, const OvGeom *g) {
    return ov_blit_fast(buf, size, layout, pitch, fmt, cv, g);
}
void ovf_render(uint8_t *cv, const OvGeom *g, const OvMenuView *v, const unsigned char font[][8], int opaque) {
    ov_render_menu_bg(cv, g, v, font, opaque);
}
