// pace_logic.h — v2.13 slow motion: frame pacing on the game's own pad reads. Plain C, host-testable.
//
// WHY THE PAD READ: the combo macro already proved on his PS4 that Tekken 7 reads the pad once per game
// frame (a recorded combo replays frame-exact, one stored step per read). Sleeping inside that read
// therefore delays the thread that runs the game frame. Tekken's fight logic advances one tick per
// game frame (frame data), so fewer frames per second = the fight runs slower (GUESS: not tested on
// his console; on PC Tekken 7 is known to slow down, not skip, when it drops below 60 fps).
// The flip hook is not used for this: Unreal Engine games like Tekken 7 most likely flip from the GPU
// (sceGnmSubmitAndFlipCommandBuffers), so sceVideoOutSubmitFlip may never be called (the overlay
// works through the flip-event thread, which only watches flips and cannot slow them).
//
// Pacing: an absolute schedule. Each new frame's read may not start before next = previous + period,
// where period = 1/60 s / speed. The game's own frame time is counted inside the period (we only sleep
// for what is left), so the average rate is exactly speed x 60 reads/s once the period is longer than
// the game's natural frame. Reads right after a paced read (another controller in the same frame,
// within PACE_SAME_FRAME_US) are not paced again. Only one (handle, source) pair is paced.
#ifndef TK_PACE_LOGIC_H
#define TK_PACE_LOGIC_H
#include <stdint.h>

#define PACE_SAME_FRAME_US 4000u    // reads this close after a paced one belong to the same frame
#define PACE_KEY_LOST_US   500000u  // pace key unseen this long (controller off): take the next one

// Frame period in microseconds for a speed num/den of normal (60 frames/s); 0 = no pacing.
static inline uint64_t pace_period_us(uint32_t num, uint32_t den) {
  if (!num || !den || num >= den) return 0;
  return (1000000ull * den + 30ull * num) / (60ull * num);   // rounded
}

typedef struct {
  uint64_t next;       // earliest start of the next paced frame
  uint64_t wake;       // when the last paced read returned (after its sleep)
  int active;          // schedule running (0 = resync on the next read)
  int32_t key_handle; uint32_t key_source; int has_key; uint64_t key_seen;
  // measurement: paced-key reads per second (shown on the Game speed row)
  uint64_t win_start; uint32_t win_count, rate;
} Pacer;

// Decides whether this read is the pace key (one controller + one read call kind).
static inline int pace_is_key(Pacer *p, int32_t handle, uint32_t source, uint64_t now) {
  if (!p->has_key || (now - p->key_seen > PACE_KEY_LOST_US && (handle != p->key_handle || source != p->key_source))) {
    p->has_key = 1; p->key_handle = handle; p->key_source = source; p->key_seen = now; p->active = 0;
    p->win_start = now; p->win_count = 0;
  }
  if (handle != p->key_handle || source != p->key_source) return 0;
  p->key_seen = now;
  return 1;
}

// Counts key reads per second (call for every key read, paced or not).
static inline void pace_measure(Pacer *p, uint64_t now) {
  p->win_count++;
  if (now - p->win_start >= 1000000u) {
    uint64_t el = now - p->win_start;
    p->rate = (uint32_t)(((uint64_t)p->win_count * 1000000u + el / 2) / el);
    p->win_start = now; p->win_count = 0;
  }
}

// Returns how many microseconds to sleep before this key read; never more than one period.
static inline uint64_t pace_step(Pacer *p, uint64_t now, uint64_t period) {
  if (!period) { p->active = 0; return 0; }                       // 100 %: never sleeps
  if (p->active && now >= p->wake && now - p->wake < PACE_SAME_FRAME_US) return 0;   // same frame
  if (!p->active || now > p->next + 2 * period) {                 // first slowed read, or long stall
    p->active = 1; p->next = now + period; p->wake = now;          // (loading screen): restart schedule
    return 0;
  }
  uint64_t wait = p->next > now ? p->next - now : 0;
  if (wait > period) wait = period;
  p->next += period;
  p->wake = now + wait;
  return wait;
}

// Combo gate for the buffered read (scePadRead returns k samples per call; when the game is slowed, k
// grows by 1/speed while the game frames do not). Decides per sample whether the combo advances
// one step (playback) / stores one step (recording), so the combo follows GAME time:
//  - 100 %: every sample advances (exactly the v2.12 behaviour)
//  - slowed: num/den of the samples advance, and at least one per call (one call = one game frame)
// scePadReadState (one sample per call = per frame) always advances.
typedef struct { uint32_t acc; int advanced_this_call; } ComboGate;
static inline void gate_reset(ComboGate *g) { g->acc = 0; g->advanced_this_call = 0; }
static inline int gate_sample(ComboGate *g, uint32_t source, uint32_t num, uint32_t den, int first_in_call, int last_in_call) {
  if (first_in_call) g->advanced_this_call = 0;
  if (source != 1 || num >= den) { g->advanced_this_call = 1; return 1; }
  g->acc += num;
  int adv = 0;
  if (g->acc >= den) { g->acc -= den; adv = 1; }
  else if (last_in_call && !g->advanced_this_call) { g->acc = 0; adv = 1; }
  if (adv) g->advanced_this_call = 1;
  return adv;
}
#endif
