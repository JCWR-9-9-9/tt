// Tekken Mods Installer v1.09 (TABX00011; updates v1.08 / v1.07 / v1.06 / v1.05 / v1.04 / v1.03 / v1.02 / v1.01 / the Tekken Mod Menu Installer). Ships plugin v2.17 (v2.17: Combo tools, timing edit and combo maker from Triangle on the Combo slot row; slot 10 = fixed "10 Hit Combo 1" when slot 10 is empty; everything else as v2.16).
// Never touches /data/GoldHEN/combo_macro/ (saved combos slot1..slot10.bin, combo_slot.cfg, overlay.cfg).
// Installs the merged combo + mod menu plugin as tekken_combo_macro.prx, removes the old separate
// tekken_modmenu.prx and every plugins.ini line that references it. Every other ini line is kept.
// Proven v1.01 approach: PNGs loaded before jailbreak; PRX bytes embedded; no /app0 reads afterwards.
#include <sstream>
#include <stdio.h>
#include <string.h>
#include <orbis/libkernel.h>
#include "_common/graphics.h"
#include "_common/png.h"
#include "_common/log.h"
#include "prx_blob.h"
#include "ini_edit.h"
extern "C" {
struct jailbreak_backup_s { uint32_t a[4]; uint64_t b; uint64_t c[3]; uint64_t d; uint8_t pad[64]; };
int sys_sdk_jailbreak(struct jailbreak_backup_s *jb);
uint32_t sys_sdk_version();
}
std::stringstream debugLogStream;
#define GH   "/data/GoldHEN"
#define DST  GH "/plugins/tekken_combo_macro.prx"
#define OLD  GH "/plugins/tekken_modmenu.prx"
#define INI  GH "/plugins.ini"
#define O_RD 0
#define O_WR 1
#define O_CR 0x200
#define O_TR 0x400
static char raw[262146], out[262146 + 1024], check[262146 + 1024];
static char prxcheck[1024 * 1024];

static void notify(const char *msg) {
  OrbisNotificationRequest n; memset(&n, 0, sizeof(n)); n.type = NotificationRequest; n.useIconImageUri = 1; n.targetId = -1;
  snprintf(n.message, sizeof(n.message), "%s", msg);
  snprintf(n.iconUri, sizeof(n.iconUri), "cxml://psnotification/tex_icon_system");
  sceKernelSendNotificationRequest(0, &n, sizeof(n), 0);
}
static int put(int fd, const void *b, size_t n) {
  const char *s = (const char *)b;
  while (n) { ssize_t k = sceKernelWrite(fd, s, n); if (k <= 0) return -1; s += k; n -= k; }
  return 0;
}
static long get(const char *path, char *p, size_t max) {
  int fd = sceKernelOpen(path, O_RD, 0); if (fd < 0) return fd;
  size_t n = 0;
  while (n < max) { ssize_t k = sceKernelRead(fd, p + n, max - n); if (k < 0) { sceKernelClose(fd); return -1; } if (!k) break; n += k; }
  sceKernelClose(fd); return (long)n;
}
static int exists(const char *path) { int fd = sceKernelOpen(path, O_RD, 0); if (fd < 0) return 0; sceKernelClose(fd); return 1; }

static int install(char *reason, size_t cap) {
  sceKernelMkdir(GH, 0777); sceKernelMkdir(GH "/plugins", 0777);
  // 1. merged plugin, written to a temp file, verified byte-for-byte, then renamed over the old one
  if (combo_prx_len > sizeof(prxcheck)) { snprintf(reason, cap, "internal: plugin too big"); return 1; }
  int fd = sceKernelOpen(DST ".tabnew", O_WR | O_CR | O_TR, 0777);
  if (fd < 0) { snprintf(reason, cap, "Cannot open plugin temp file: %x", fd); return 1; }
  int ok = put(fd, combo_prx, combo_prx_len) == 0; sceKernelClose(fd);
  if (!ok || get(DST ".tabnew", prxcheck, sizeof(prxcheck)) != (long)combo_prx_len || memcmp(prxcheck, combo_prx, combo_prx_len)) {
    sceKernelUnlink(DST ".tabnew"); snprintf(reason, cap, "Plugin copy verification failed"); return 2;
  }
  if (sceKernelRename(DST ".tabnew", DST) != 0) {
    // fallback: unlink + rename
    sceKernelUnlink(DST);
    if (sceKernelRename(DST ".tabnew", DST) != 0) { snprintf(reason, cap, "Plugin rename failed"); return 3; }
  }
  if (get(DST, prxcheck, sizeof(prxcheck)) != (long)combo_prx_len || memcmp(prxcheck, combo_prx, combo_prx_len)) {
    snprintf(reason, cap, "Plugin re-read mismatch"); return 3;
  }
  // 2. remove the old separate menu plugin
  sceKernelUnlink(OLD); sceKernelUnlink(OLD ".tabnew");
  if (exists(OLD)) { snprintf(reason, cap, "Could not delete old tekken_modmenu.prx"); return 4; }
  // 3. plugins.ini: drop every tekken_modmenu.prx line, ensure the combo line in the 4 Tekken sections
  long in = get(INI, raw, sizeof(raw) - 1);
  if (in < 0) in = 0;
  if (in >= (long)sizeof(raw) - 1) { snprintf(reason, cap, "plugins.ini too large, unchanged"); return 5; }
  raw[in] = 0;
  size_t outlen = 0; int removed = 0, added = 0;
  if (tk_ini_rewrite(raw, (size_t)in, out, sizeof(out), &outlen, &removed, &added) != 0) { snprintf(reason, cap, "plugins.ini too large, unchanged"); return 5; }
  if (removed || added || !tk_ini_verify(raw, (size_t)in)) {
    fd = sceKernelOpen(INI ".tabnew", O_WR | O_CR | O_TR, 0777);
    if (fd < 0) { snprintf(reason, cap, "Cannot open ini temp file: %x", fd); return 6; }
    ok = put(fd, out, outlen) == 0; sceKernelClose(fd);
    if (!ok || get(INI ".tabnew", check, sizeof(check)) != (long)outlen || memcmp(check, out, outlen)) {
      sceKernelUnlink(INI ".tabnew"); snprintf(reason, cap, "INI write check failed, old file kept"); return 7;
    }
    if (sceKernelRename(INI ".tabnew", INI) != 0) { snprintf(reason, cap, "INI rename failed, old file kept"); return 8; }
  }
  // 4. verify by re-reading the real file
  long v = get(INI, check, sizeof(check) - 1);
  if (v < 0 || !tk_ini_verify(check, (size_t)v)) { snprintf(reason, cap, "INI re-read check failed"); return 9; }
  snprintf(reason, cap, "Combo + Mod Menu in one plugin.\nOld menu plugin removed (%d ini line%s).", removed, removed == 1 ? "" : "s");
  return 0;
}
int main() {
  setvbuf(stdout, NULL, _IONBF, 0);
  auto scene = new Scene2D(1920, 1080, 4);
  if (!scene->Init(0xC000000, 2)) for (;;) sceKernelUsleep(1000000);
  auto okimg = new PNG("/app0/assets/images/ok.png");
  auto failimg = new PNG("/app0/assets/images/fail.png");
  jailbreak_backup_s jb = {0}; uint32_t gh = sys_sdk_version(); int jbr = sys_sdk_jailbreak(&jb);
  char detail[200] = {0}; int rc = install(detail, sizeof(detail));
  char msg[360];
  snprintf(msg, sizeof(msg), "Tekken Mods %s v2.00\n%s\nGoldHEN %x, jailbreak %d, step %d",
           rc ? "FAILED" : "INSTALLED", detail, gh, jbr, rc);
  notify(msg);
  PNG *image = rc ? failimg : okimg;
  for (int frame = 0;; frame++) {
    if (frame < 2) { scene->FrameBufferClear(); image->Draw(scene, 0, 0); }
    scene->SubmitFlip(frame); scene->FrameWait(frame); scene->FrameBufferSwap();
  }
}
