// ini_edit.h — pure C plugins.ini rewrite for the Tekken Mods installer (host-testable).
// Removes every line that mentions tekken_modmenu.prx, keeps every other line byte-for-byte,
// and makes sure each Tekken 7 section has an active tekken_combo_macro.prx line.
#pragma once
#include <string.h>
#include <stddef.h>

#define TK_COMBO_LINE "/data/GoldHEN/plugins/tekken_combo_macro.prx"
static const char *const TK_IDS[4] = {"CUSA05972", "CUSA06014", "CUSA05898", "CUSA05798"};

static int tk_contains(const char *s, size_t n, const char *needle) {
    size_t k = strlen(needle);
    for (size_t i = 0; i + k <= n; i++) if (!memcmp(s + i, needle, k)) return 1;
    return 0;
}
static size_t tk_skip_ws(const char *s, size_t n) { size_t i = 0; while (i < n && (s[i] == ' ' || s[i] == '\t')) i++; return i; }
// -1 = not a header, -2 = header of some other section, 0..3 = Tekken section
static int tk_header(const char *s, size_t n) {
    size_t i = tk_skip_ws(s, n);
    if (i >= n || s[i] != '[') return -1;
    for (int t = 0; t < 4; t++) {
        size_t k = strlen(TK_IDS[t]);
        if (i + 1 + k < n && !memcmp(s + i + 1, TK_IDS[t], k) && s[i + 1 + k] == ']') return t;
    }
    return -2;
}
static int tk_active_combo(const char *s, size_t n) {
    size_t i = tk_skip_ws(s, n);
    return i < n && s[i] != ';' && s[i] != '#' && tk_contains(s, n, "tekken_combo_macro.prx");
}
static int tk_put(char *out, size_t cap, size_t *len, const char *p, size_t n) {
    if (*len + n + 1 > cap) return 0;
    memcpy(out + *len, p, n); *len += n; out[*len] = 0; return 1;
}
// Returns 0 on success, -1 if the output buffer is too small. *removed = modmenu lines dropped.
static int tk_ini_rewrite(const char *in, size_t inlen, char *out, size_t cap, size_t *outlen, int *removed, int *added) {
    int have[4] = {0, 0, 0, 0}, exists[4] = {0, 0, 0, 0}, inserted[4] = {0, 0, 0, 0};
    const char *nl = "\n";
    int cur = -1;
    // pass 1: which Tekken sections exist and already carry an active combo line
    for (size_t i = 0; i < inlen;) {
        size_t j = i; while (j < inlen && in[j] != '\n') j++;
        size_t n = j - i;
        if (n && j < inlen && in[i + n - 1] == '\r') nl = "\r\n";
        int h = tk_header(in + i, n);
        if (h != -1) { cur = h; if (h >= 0) exists[h] = 1; }
        else if (cur >= 0 && tk_active_combo(in + i, n)) have[cur] = 1;
        i = j + (j < inlen);
    }
    // pass 2: copy, drop modmenu lines, insert a missing combo line right under the first header
    *outlen = 0; *removed = 0; *added = 0; if (cap) out[0] = 0;
    for (size_t i = 0; i < inlen;) {
        size_t j = i; while (j < inlen && in[j] != '\n') j++;
        size_t n = j - i, full = n + (j < inlen);
        if (tk_contains(in + i, n, "tekken_modmenu.prx")) { (*removed)++; i += full; continue; }
        if (!tk_put(out, cap, outlen, in + i, full)) return -1;
        int h = tk_header(in + i, n);
        if (h >= 0 && !have[h] && !inserted[h]) {
            if (j >= inlen && !tk_put(out, cap, outlen, nl, strlen(nl))) return -1;   // header was the last line
            if (!tk_put(out, cap, outlen, TK_COMBO_LINE, strlen(TK_COMBO_LINE)) || !tk_put(out, cap, outlen, nl, strlen(nl))) return -1;
            inserted[h] = 1; (*added)++;
        }
        i += full;
    }
    // Tekken sections that do not exist yet
    for (int t = 0; t < 4; t++) {
        if (exists[t]) continue;
        if (*outlen && out[*outlen - 1] != '\n' && !tk_put(out, cap, outlen, nl, strlen(nl))) return -1;
        if (!tk_put(out, cap, outlen, "[", 1) || !tk_put(out, cap, outlen, TK_IDS[t], strlen(TK_IDS[t])) ||
            !tk_put(out, cap, outlen, "]", 1) || !tk_put(out, cap, outlen, nl, strlen(nl)) ||
            !tk_put(out, cap, outlen, TK_COMBO_LINE, strlen(TK_COMBO_LINE)) || !tk_put(out, cap, outlen, nl, strlen(nl))) return -1;
        (*added)++;
    }
    return 0;
}
// Check of the re-read file: no modmenu reference left, every Tekken section has an active combo line.
static int tk_ini_verify(const char *in, size_t inlen) {
    if (tk_contains(in, inlen, "tekken_modmenu.prx")) return 0;
    int have[4] = {0, 0, 0, 0}, cur = -1;
    for (size_t i = 0; i < inlen;) {
        size_t j = i; while (j < inlen && in[j] != '\n') j++;
        int h = tk_header(in + i, j - i);
        if (h != -1) cur = h; else if (cur >= 0 && tk_active_combo(in + i, j - i)) have[cur] = 1;
        i = j + (j < inlen);
    }
    return have[0] && have[1] && have[2] && have[3];
}
