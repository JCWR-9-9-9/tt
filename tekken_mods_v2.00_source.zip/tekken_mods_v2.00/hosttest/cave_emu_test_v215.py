# v2.15 cave emulation: new CAVE_DMG (flags 0..10) vs reference math, vs TLH (0-2) and vs v2.14's cave (0-5).
import sys, struct, random, re
from unicorn import *
from unicorn.x86_const import *
def parse_header(path):
    t=open(path).read()
    def arr(name):
        m=re.search(r'static const unsigned char %s\[\]=\{([^}]*)\}'%name,t); return bytes(int(x,16) for x in m.group(1).split(','))
    return arr('CAVE_DMG'), arr('CAVE'), arr('SITE_PATCH'), arr('SITE_ORIG')
CAVE_DMG, CAVE_TLH, SITE_PATCH, SITE_ORIG = parse_header(sys.argv[1])
OLD_DMG = parse_header(sys.argv[2])[0]
assert len(CAVE_DMG) <= len(OLD_DMG), (len(CAVE_DMG), len(OLD_DMG))
print('cave bytes', len(CAVE_DMG), 'old', len(OLD_DMG))
SITE=0x1496643; CAVE=0x5447800; BACK=0x149664a
STRUCT=0x20000000; STACK=0x30000000
PCT={3:80,4:60,5:50,6:105,7:110,8:120,9:150,10:200}
# One emulator per cave: code is written once (Unicorn caches translated blocks, so code at one
# address is never swapped between runs); per run only the two flag bytes (data) change.
EMU={}
def emu_for(cave):
    if cave not in EMU:
        mu=Uc(UC_ARCH_X86,UC_MODE_64)
        mu.mem_map(0x1496000,0x1000, UC_PROT_READ|UC_PROT_EXEC)
        mu.mem_map(0x5447000,0x1000, UC_PROT_READ|UC_PROT_WRITE|UC_PROT_EXEC)
        mu.mem_map(STRUCT,0x10000); mu.mem_map(STACK-0x10000,0x20000)
        mu.mem_write(SITE, SITE_PATCH + b'\xf4')
        mu.mem_write(CAVE, b'\xcc'*0x200)       # anything past the cave = trap
        mu.mem_write(CAVE, cave)
        EMU[cave]=mu
    return EMU[cave]
fails=0; n=0
def run(cave, flags, player, old, new, maxhp, rax_hi=0):
    global n; n+=1
    mu=emu_for(cave)
    mu.mem_write(CAVE, bytes([flags[0]&0xff, flags[1]&0xff]))
    mu.mem_write(STRUCT+0x14a0, struct.pack('<iii', player, old, maxhp))
    rz=bytes(random.getrandbits(8) for _ in range(0x100))
    mu.mem_write(STACK-0x80, rz)
    regs={UC_X86_REG_RBX:0x1111,UC_X86_REG_RCX:0xdeadbeefcafe0001,UC_X86_REG_RDX:0x123456789abcdef0,
          UC_X86_REG_RSI:7,UC_X86_REG_RDI:8,UC_X86_REG_R8:9,UC_X86_REG_R9:10,UC_X86_REG_R10:11,UC_X86_REG_R11:12,
          UC_X86_REG_R12:13,UC_X86_REG_R13:14,UC_X86_REG_R14:15,UC_X86_REG_RBP:16}
    for r,v in regs.items(): mu.reg_write(r,v)
    mu.reg_write(UC_X86_REG_R15,STRUCT); mu.reg_write(UC_X86_REG_RSP,STACK)
    mu.reg_write(UC_X86_REG_RAX,(rax_hi<<32)|(new & 0xffffffff))
    mu.emu_start(SITE, BACK, count=200)
    assert mu.reg_read(UC_X86_REG_RIP)==BACK, hex(mu.reg_read(UC_X86_REG_RIP))
    for r,v in regs.items(): assert mu.reg_read(r)==v, ('clobbered',r)
    assert mu.reg_read(UC_X86_REG_RSP)==STACK, 'rsp'
    assert mu.reg_read(UC_X86_REG_R15)==STRUCT
    assert bytes(mu.mem_read(STACK-0x80,0x100))==rz, 'red zone touched'
    p,h,m=struct.unpack('<iii',bytes(mu.mem_read(STRUCT+0x14a0,12)))
    assert p==player and m==maxhp
    rax=mu.reg_read(UC_X86_REG_RAX)
    assert struct.unpack('<i',struct.pack('<I',rax&0xffffffff))[0]==h
    return h, rax
def expected(mode, old, new, maxhp):
    if mode==1: return maxhp
    if mode==2: return new if (new & 0xffffffff)==0 else 1
    pct=PCT.get(mode)
    if pct is None or new>=old: return new
    d=old-new
    s=(d*pct + (50 if pct>100 else 0))//100
    if s==0: s=1
    return max(old-s, min(new,0))
random.seed(7)
cases=[(180,170),(180,175),(180,179),(10,0),(1,0),(2,0),(2,1),(5,4),(180,0),(180,-20),(50,-100),(0,0),(0,-5),
       (170,180),(100,180),(0,180),(180,180),(30,25),(100,90),(7,6),(3,2),(170,169),(2147483647,-2147483648),
       (-5,-10),(-2147483648,-2147483648),(2147483647,0),(5,-2147483648),(11,1),(10,0),(9,0),(6,0)]
for _ in range(400):
    old=random.randint(0,250); cases.append((old, random.randint(-50,260)))
for _ in range(100):
    cases.append((random.randint(-2**31,2**31-1), random.randint(-2**31,2**31-1)))
for mode in range(0,14):
    for player in (0,1,2,-1):
        pi = 0 if player==0 else 1
        for old,new in cases:
            for rax_hi in (0, 0xffffffff, 0x1234):
                flags=[0,0]; flags[pi]=mode
                other=[0,0]; other[1-pi]=mode
                for fl,mm in ((flags,mode),(other,0)):
                    exp=expected(mm, old, new, 180)
                    got,rax=run(CAVE_DMG, fl, player, old, new, 180, rax_hi)
                    if got!=exp: fails+=1; print('FAIL mode',mode,'P',player,fl,old,new,'got',got,'exp',exp)
                    if mm in (0,1,2):
                        if run(CAVE_TLH, fl, player, old, new, 180, rax_hi)!=(got,rax): fails+=1; print('DIFF vs TLH',mm,old,new)
                    if mm <= 5 or mm > 10:
                        if run(OLD_DMG, fl, player, old, new, 180, rax_hi)!=(got,rax): fails+=1; print('DIFF vs v2.14',mm,old,new)
# invariants for every damage mode over a dense grid
for mode,pct in PCT.items():
    for old in range(0,260):
        for new in range(-30,old):
            got,_=run(CAVE_DMG,[mode,0],0,old,new,180)
            d=old-new; dealt=old-got
            if pct<100 and not (new<=got<old): fails+=1; print('INV<',mode,old,new,got)
            if pct>100:
                # more (or equal) damage than the game's, never past min(new,0), never wraps
                if not (got<=new and got>=min(new,0) and got<old): fails+=1; print('INV>',mode,old,new,got)
                if got>min(new,0) and dealt != (d*pct+50)//100: fails+=1; print('ROUND',mode,old,new,got)
# KO: from 180, repeated hits of size k reach exactly 0 and stop (never negative unless game wrote negative)
for mode in PCT:
    for k in (1,3,7,10,25,60):
        h=180; hits=0
        while h>0 and hits<1000:
            h,_=run(CAVE_DMG,[mode,0],0,h,max(h-k,0),180); hits+=1
        if h!=0: fails+=1; print('NO KO',mode,k,h)
    print('mode %2d (%d%%) KO from 180 by 10-dmg hits after'%(mode,PCT[mode]), end=' ')
    h=180; hits=0
    while h>0: h,_=run(CAVE_DMG,[mode,0],0,h,max(h-10,0),180); hits+=1
    print(hits,'hits')
for mode,pct in PCT.items():
    row=[]
    for old,new in [(180,170),(180,175),(180,179),(180,178),(10,0),(5,0),(180,100),(100,180)]:
        row.append('%d->%d:%d'%(old,new,run(CAVE_DMG,[mode,0],0,old,new,180)[0]))
    print('%4d%%'%pct,' '.join(row))
print('runs',n,'fails',fails)
sys.exit(1 if fails else 0)
