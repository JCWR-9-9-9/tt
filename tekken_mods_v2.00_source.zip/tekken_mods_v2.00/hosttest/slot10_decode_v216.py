#!/usr/bin/env python3
"""v2.16 host check: decode a slot file written by the plugin's own writer (MacroHeader + MacroStep records)
and check the fixed combo "10 Hit Combo 1" against yahya's PDF (Marshall Law).
usage: slot10_decode_v216.py <slot10.bin>"""
import struct, sys, hashlib

BTN = {"Triangle": 0x1000, "Circle": 0x2000, "X": 0x4000, "Square": 0x8000, "Down": 0x0040, "Right": 0x0020}
# PDF presses: (time in seconds, buttons that must be down, label)
EXPECT = [
    (0.00, BTN["Square"] | BTN["Down"] | BTN["Right"], "Square + down-right (D-pad)"),
    (0.20, BTN["Triangle"], "Triangle"),
    (0.40, BTN["Triangle"], "Triangle"),
    (0.60, BTN["Square"], "Square"),
    (0.90, BTN["X"], "X"),
    (1.20, BTN["X"], "X"),
    (1.50, BTN["X"], "X"),
    (1.80, BTN["Circle"], "Circle"),
    (2.10, BTN["X"], "X"),
    (2.40, BTN["Circle"], "Circle"),
]
HZ = 60
TAP = 3          # 50 ms at 60 Hz
COUNT = 150
MAGIC = 0x4D434B54

def main(path):
    raw = open(path, "rb").read()
    assert len(raw) == 32 + 16 * COUNT, ("size", len(raw))
    magic, version, count, step_size, presses, source = struct.unpack_from("<6I", raw, 0)
    assert magic == MAGIC and version == 1 and count == COUNT and step_size == 16, (magic, version, count, step_size)
    assert presses == 10, presses
    steps = []
    for i in range(count):
        steps.append(struct.unpack_from("<IBBBBBBHI", raw, 32 + 16 * i))
    # neutral sticks everywhere (no stick input in this combo), no analog triggers
    for (b, lx, ly, rx, ry, l2, r2, res, t) in steps:
        assert (lx, ly, rx, ry) == (0x80, 0x80, 0x80, 0x80) and l2 == 0 and r2 == 0 and res == 0
    # rising edges of the buttons word = presses
    edges = []
    prev = 0
    for i, (b, *_rest) in enumerate(steps):
        rise = b & ~prev
        if rise:
            edges.append((i, rise, steps[i][8]))
        prev = b
    assert len(edges) == 10, ("presses found", len(edges))
    print("frame  t(s)   held(frames)  buttons                     PDF press")
    for n, ((frame, rise, t_us), (want_t, want_b, label)) in enumerate(zip(edges, EXPECT), 1):
        assert abs(t_us / 1e6 - want_t) < 1e-9, ("time", n, t_us)
        assert frame == round(want_t * HZ), ("frame", n, frame)
        held = 0
        while frame + held < count and (steps[frame + held][0] & want_b) == want_b:
            held += 1
        # each press holds exactly TAP samples and nothing else, then the buttons go up
        assert held == TAP, ("held", n, held)
        assert steps[frame + TAP][0] & want_b == 0
        assert steps[frame][0] == want_b, ("buttons", n, hex(steps[frame][0]), hex(want_b))
        names = [k for k, v in BTN.items() if want_b & v]
        print(f"{frame:5d}  {want_t:4.2f}  {held:3d}          {'+'.join(names):26s} {n:2d}. {label}")
    # no input outside the ten taps
    inside = set()
    for (frame, _r, _t), (want_t, want_b, _l) in zip(edges, EXPECT):
        inside.update(range(frame, frame + TAP))
    for i, (b, *_r) in enumerate(steps):
        if i not in inside:
            assert b == 0, ("stray input", i, hex(b))
    print("OK: 10 presses, times 0.00 0.20 0.40 0.60 0.90 1.20 1.50 1.80 2.10 2.40 s, 50 ms taps, nothing else")
    print("sha256", hashlib.sha256(raw).hexdigest())

if __name__ == "__main__":
    main(sys.argv[1])
