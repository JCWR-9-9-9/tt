#include <stdio.h>
#include <assert.h>
#include <stdlib.h>
#include "../installer/installer/ini_edit.h"
static char out[65536];
static void run(const char *name, const char *in, const char *expect, int exp_removed, int exp_added){
  size_t ol; int rem, add;
  assert(tk_ini_rewrite(in, strlen(in), out, sizeof(out), &ol, &rem, &add)==0);
  if (expect && strcmp(out, expect)) { printf("FAIL %s\n--got--\n%s\n--want--\n%s\n", name, out, expect); exit(1);} 
  assert(rem==exp_removed && add==exp_added); assert(tk_ini_verify(out, ol)); assert(ol==strlen(out));
  // idempotent: running again changes nothing
  static char out2[65536]; size_t ol2; assert(tk_ini_rewrite(out, ol, out2, sizeof(out2), &ol2, &rem, &add)==0);
  assert(ol2==ol && !memcmp(out,out2,ol) && rem==0 && add==0);
  printf("PASS %s\n", name);
}
#define C "/data/GoldHEN/plugins/tekken_combo_macro.prx\n"
#define MM "/data/GoldHEN/plugins/tekken_modmenu.prx\n"
#include <stdlib.h>
int main(void){
  // yahya's expected file: whatever he had + combo block (v1.01) + modmenu inserted in first [CUSA06014]
  const char *his =
    "[default]\n/data/GoldHEN/plugins/no_share_watermark.prx\n\n"
    "; Tekken 7 combo macro (L3+R3 record, R3 play, L3 play mirrored)\n"
    "[CUSA05972]\n" C "[CUSA06014]\n" C MM "[CUSA05898]\n" C "[CUSA05798]\n" C;
  const char *his_want =
    "[default]\n/data/GoldHEN/plugins/no_share_watermark.prx\n\n"
    "; Tekken 7 combo macro (L3+R3 record, R3 play, L3 play mirrored)\n"
    "[CUSA05972]\n" C "[CUSA06014]\n" C "[CUSA05898]\n" C "[CUSA05798]\n" C;
  run("expected current file", his, his_want, 1, 0);
  run("modmenu listed twice + commented + no trailing newline",
      "[CUSA06014]\n" MM C ";" MM "[CUSA05972]\n" C "[CUSA05898]\n" C "[CUSA05798]\n" C "[CUSA06014]\n/data/GoldHEN/plugins/tekken_modmenu.prx",
      "[CUSA06014]\n" C "[CUSA05972]\n" C "[CUSA05898]\n" C "[CUSA05798]\n" C "[CUSA06014]\n", 3, 0);
  run("empty file", "", "[CUSA05972]\n" C "[CUSA06014]\n" C "[CUSA05898]\n" C "[CUSA05798]\n" C, 0, 4);
  run("modmenu only section (no combo)", "[default]\n/x.prx\n[CUSA06014]\n" MM,
      "[default]\n/x.prx\n[CUSA06014]\n" C "[CUSA05972]\n" C "[CUSA05898]\n" C "[CUSA05798]\n" C, 1, 4);
  run("combo commented out gets an active line", "[CUSA06014]\n;" C "[CUSA05972]\n" C "[CUSA05898]\n" C "[CUSA05798]\n" C,
      "[CUSA06014]\n" C ";" C "[CUSA05972]\n" C "[CUSA05898]\n" C "[CUSA05798]\n" C, 0, 1);
  run("CRLF file", "[CUSA06014]\r\n/data/GoldHEN/plugins/tekken_modmenu.prx\r\n/a.prx\r\n",
      "[CUSA06014]\r\n" "/data/GoldHEN/plugins/tekken_combo_macro.prx\r\n/a.prx\r\n[CUSA05972]\r\n/data/GoldHEN/plugins/tekken_combo_macro.prx\r\n[CUSA05898]\r\n/data/GoldHEN/plugins/tekken_combo_macro.prx\r\n[CUSA05798]\r\n/data/GoldHEN/plugins/tekken_combo_macro.prx\r\n", 1, 4);
  run("header last line no newline", "[CUSA05972]", NULL, 0, 4);
  run("other game sections untouched", "[CUSA00001]\n/data/GoldHEN/plugins/a.prx\n[CUSA06014x]\n/b.prx\n" , NULL, 0, 4);
  assert(strstr(out, "[CUSA00001]\n/data/GoldHEN/plugins/a.prx\n[CUSA06014x]\n/b.prx\n")==out);
  assert(!tk_ini_verify(his, strlen(his)));
  printf("ALL INI TESTS PASSED\n"); return 0; }
