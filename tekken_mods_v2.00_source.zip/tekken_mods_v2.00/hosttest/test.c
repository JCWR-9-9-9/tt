
#define TK_HOST_TEST 1
#include <fcntl.h>
#include <unistd.h>
#include <sys/stat.h>
#include <assert.h>
#include "plugin_common.h"
#include "Common.h"
#include "orbis/Pad.h"
char last_notify[512]; int notify_count; char all_notify[16384];
void NotifyStatic(const char* i, const char *t){ snprintf(last_notify,512,"%s",t); notify_count++; strncat(all_notify,t,sizeof(all_notify)-strlen(all_notify)-2); strcat(all_notify,"|"); printf("  [NOTIFY] %s\n", t); }
void Notify(const char* i, const char *f, ...){ char b[512]; va_list a; va_start(a,f); vsnprintf(b,512,f,a); va_end(a); NotifyStatic(i,b);}
int sceKernelOpen(const char*p,int f,int m){ int ff=0; if(f&1) ff|=O_WRONLY; if(f&0x200) ff|=O_CREAT; if(f&0x400) ff|=O_TRUNC; return open(p,ff,m);}
ssize_t sceKernelWrite(int fd,const void*b,size_t n){return write(fd,b,n);} ssize_t sceKernelRead(int fd,void*b,size_t n){return read(fd,b,n);}
int sceKernelClose(int fd){return close(fd);} int sceKernelMkdir(const char*p,int m){return mkdir(p,m);}
int sceKernelRename(const char*a,const char*b){return rename(a,b);} int sceKernelUnlink(const char*p){return unlink(p);}
const char* sceKernelGetFsSandboxRandomWord(void){return "abc";} int sys_dynlib_load_prx(const char*p, int*h){return 0;}
int scePadRead(int h, OrbisPadData* d, int n){return 0;} int scePadReadState(int h, OrbisPadData* d){return 0;}
// fake eboot memory for the health cave
static unsigned char *fake_mem; static size_t fake_len;
#include "../repo/plugin_src/tekken_combo_macro/source/health_bytes.h"
int sys_sdk_proc_info(struct proc_info *pi){ memset(pi,0,sizeof(*pi));
#ifdef WRONG_TITLE
  strcpy(pi->titleid,"CUSA05972"); strcpy(pi->version,"01.00");
#else
  strcpy(pi->titleid,"CUSA06014"); strcpy(pi->version,"05.10");
#endif
  pi->base_address=(uint64_t)fake_mem; return 0; }
static int mapped(uint64_t at,size_t len,int w){ (void)w; return at>=(uint64_t)fake_mem && at+len<=(uint64_t)fake_mem+fake_len; }
static int kwrite_count;
static int kwrite(uint64_t at,const void*src,size_t n){ if(!mapped(at,n,1)) return 0; memcpy((void*)at,src,n); kwrite_count++; return 1; }
// scripted real pad
static uint32_t real_btn; static uint8_t real_lx=0x80; static uint64_t ts; static int real_handle;
int scePadReadStateExt(int h, OrbisPadData* d){ memset(d,0,sizeof(*d)); d->buttons=real_btn; d->leftStick.x=real_lx; d->leftStick.y=0x80; d->rightStick.x=d->rightStick.y=0x80; d->timestamp=(ts+=16667); d->touch.fingers=(real_btn&0x100000)?1:0; return 0; }
int scePadReadExt(int h, OrbisPadData* d, int n){ scePadReadStateExt(h,d); return 1; }
#include "../repo/plugin_src/tekken_combo_macro/source/main.c"
#define L3 0x2
#define R3 0x4
#define OPT 0x8
#define UP 0x10
#define DOWN 0x40
#define SQ 0x8000
#define TRI 0x1000
#define X 0x4000
#define O 0x2000
#define RIGHT 0x20
#define LEFT 0x80
#define TOUCH 0x100000
static OrbisPadData out;
static uint32_t frame(uint32_t b){ real_btn=b; scePadReadState_hook(real_handle,&out); return out.buttons; }
static uint32_t frame_read(uint32_t b){ real_btn=b; OrbisPadData arr[1]; scePadRead_hook(real_handle,arr,1); out=arr[0]; return out.buttons; }
static void frames(uint32_t b,int n){ for(int i=0;i<n;i++) frame(b); }
static int site_patched(void){ return memcmp(fake_mem+SITE_OFF,SITE_PATCH,7)==0; }

static void combo_suite(void){
  printf("C1) R3 with no combo\n"); frames(0,5); frames(R3,3); assert((out.buttons&R3)==0); frames(0,1);
  assert(strstr(last_notify,"No combo"));
  printf("C2) record: chord, idle, combo, chord\n");
  frames(R3,1); frames(L3|R3,4); assert(g_state==ST_RECORDING); assert(strstr(last_notify,"REC"));
  frames(L3,2); frames(0,30);
  frames(RIGHT,3); frames(SQ,2); frames(0,5); frames(TRI,1); frames(X,4); frames(RIGHT|SQ,2);
  frames(0,20);
  frames(L3,2); frames(L3|R3,3); frames(0,2);
  assert(g_state==ST_IDLE); assert(g_slot_count==18);
  assert(strstr(last_notify,"Combo saved (6 inputs"));
  struct stat st; assert(stat("/tmp/tkcm_test/GoldHEN/combo_macro/slot1.bin",&st)==0); assert(st.st_size==32+16*18);
  printf("C3) playback R3, exact frames\n");
  frames(0,3); frames(R3,4); assert(g_state==ST_IDLE); assert((out.buttons&R3)==0);
  uint32_t expect[18]={RIGHT,RIGHT,RIGHT,SQ,SQ,0,0,0,0,0,TRI,X,X,X,X,RIGHT|SQ,RIGHT|SQ,0};
  uint32_t b=frame(0); assert(b==0); assert(g_state==ST_PLAYING);
  for(int i=0;i<18;i++){ b=frame(0); if(b!=expect[i]){printf("mismatch at %d: %x vs %x\n",i,b,expect[i]); exit(1);} }
  assert(g_state==ST_IDLE); assert(frame(SQ)==SQ); frame(0);
  printf("C3b) same via scePadRead path\n");
  frame_read(R3); frame_read(R3); frame_read(0); assert(g_state==ST_PLAYING);
  for(int i=0;i<18;i++){ b=frame_read(0); assert(b==expect[i]); } assert(g_state==ST_IDLE);
  printf("C4) mirrored with L3\n");
  frames(L3,2); frame(0); assert(g_state==ST_PLAYING && g_play_mirror==1);
  b=frame(0); assert(b==LEFT); frames(0,17); assert(g_state==ST_IDLE);
  printf("C5) cancel during playback\n");
  frames(R3,2); frame(0); frames(0,4); assert(g_state==ST_PLAYING); b=frame(X); assert(g_state==ST_IDLE); assert(b==X); frames(0,3);
  printf("C6) R3 during playback cancels, no retrigger\n");
  frames(R3,2); frame(0); frames(0,2); frame(R3); assert(g_state==ST_IDLE); frames(R3,2); frames(0,3); assert(g_state==ST_IDLE);
  printf("C7) persistence\n");
  g_slot_count=0; assert(macro_load()==0); assert(g_slot_count==18);
  printf("C8) empty record cancelled\n");
  frames(L3|R3,2); frames(0,10); frames(L3|R3,2); frames(0,2); assert(strstr(last_notify,"cancelled")); assert(g_slot_count==18);
}

int main(){ setvbuf(stdout,0,_IONBF,0);
  system("rm -rf /tmp/tkcm_test; mkdir -p /tmp/tkcm_test");
  fake_len=CAVE_OFF+0x1000; fake_mem=calloc(1,fake_len); memcpy(fake_mem+SITE_OFF,SITE_ORIG,7);
  assert(plugin_load(0,0)==0); assert(g_slot_count==0);
#ifdef WRONG_TITLE
  printf("== other Tekken ID: combo only ==\n");
  assert(!g_menu_enabled); assert(strstr(last_notify,"Combo Macro ON")); assert(strstr(last_notify,"needs CUSA06014"));
  combo_suite();
  printf("W1) touchpad+OPTIONS passes to the game untouched, no menu\n");
  int n0=notify_count; frame(TOUCH); assert(frame(TOUCH|OPT)==(TOUCH|OPT)); frame(0); assert(notify_count==n0); assert(!g_menu.open);
  assert(kwrite_count==0);
  printf("ALL WRONG-TITLE TESTS PASSED\n"); return 0;
#else
  printf("== CUSA06014 v05.10: combo + menu ==\n");
  assert(g_menu_enabled); assert(strstr(last_notify,"Tekken Combo + Mod Menu ON"));
  combo_suite();
  uint32_t b;
  printf("M0) startup notice: v2.14, L3 + OPTIONS, no touchpad\n");
  assert(strstr(all_notify,"Tekken Combo + Mod Menu ON (v2.18)")); assert(strstr(all_notify,"Menu: L3 + OPTIONS"));
  assert(!strcasestr(all_notify,"touch")); assert(g_pluginVersion==0x218);
  printf("M1) plain OPTIONS: passes to game, one-time hint says L3 + OPTIONS\n");
  frames(0,2); b=frame(OPT); assert(b==OPT); assert(strstr(last_notify,"L3 + OPTIONS")); assert(!strcasestr(last_notify,"touch")); frame(0);
  int n0=notify_count; frame(OPT); frame(0); assert(notify_count==n0);
  printf("M2) touchpad alone reaches the game (button bit + finger)\n");
  b=frame(TOUCH); assert(b==TOUCH); assert(out.touch.fingers==1); b=frame(TOUCH|SQ); assert(b==(TOUCH|SQ)); frame(0);
  printf("M2b) touchpad + OPTIONS does NOT open the menu; both reach the game\n");
  n0=notify_count; frame(TOUCH); b=frame(TOUCH|OPT); assert(!g_menu.open); assert(b==(TOUCH|OPT)); assert(out.touch.fingers==1);
  b=frame(OPT|TOUCH); assert(b==(TOUCH|OPT)); frame(0); assert(notify_count==n0); assert(!g_menu.open);
  b=frame(OPT); assert(b==OPT); b=frame(OPT|TOUCH); assert(!g_menu.open && b==(TOUCH|OPT)); frame(0);   // OPTIONS first, then touch
  printf("M2c) touchpad during playback cancels it (any button) and still reaches the game\n");
  frames(R3,2); frame(0); frames(0,3); assert(g_state==ST_PLAYING); b=frame(TOUCH); assert(g_state==ST_IDLE); assert(b==TOUCH); frame(0);
  printf("M3) hold L3 + OPTIONS opens; input swallowed; no mirrored combo\n");
  frame(L3); b=frame(L3|OPT); assert(g_menu.open); assert(b==0); assert(strstr(last_notify,"P1 Health: Normal"));
  b=frame(L3|OPT); assert(b==0); b=frame(TOUCH); assert(b==0 && out.touch.fingers==0); frame(0); assert(g_state==ST_IDLE);
  printf("M4) combo triggers are dead while open\n");
  frames(R3,2); frame(0); assert(g_state==ST_IDLE); frames(L3|R3,2); frame(0); assert(g_state==ST_IDLE);
  printf("M5) RIGHT -> P1 Infinite: extended cave + jump installed, flags 01 00\n");
  b=frame(RIGHT); assert(b==0); frame(0); assert(g_menu.health[0]==1); assert(site_patched());
  assert(memcmp(fake_mem+CAVE_OFF+2,CAVE_DMG+2,sizeof(CAVE_DMG)-2)==0); assert(g_cave_kind==CAVE_KIND_DMG); assert(fake_mem[CAVE_OFF]==1 && fake_mem[CAVE_OFF+1]==0);
  assert(strstr(last_notify,"P1 Health: Infinite"));
  printf("M6) DOWN, LEFT x9 -> P2 200,150,120,110,105,50,60,80%%,1-Hit (flags 01 0A..02) (v2.16)\n");
  frame(DOWN); frame(0); assert(g_menu.selected==1);
  for(int v=10;v>=2;v--){ frame(LEFT); frame(0); assert(g_menu.health[1]==v && fake_mem[CAVE_OFF+1]==v && fake_mem[CAVE_OFF]==1); }
  assert(fake_mem[CAVE_OFF]==1 && fake_mem[CAVE_OFF+1]==2);
  frame(X); frame(0); assert(strstr(last_notify,"P2 Health: 1-Hit"));
  frame(UP); frame(0); assert(g_menu.selected==0);
  printf("M7) O closes; O never reaches the game; swallow until release\n");
  b=frame(O); assert(!g_menu.open && b==0); b=frame(O); assert(b==0); b=frame(O|SQ); assert(b==0); b=frame(0); assert(b==0);
  b=frame(SQ); assert(b==SQ); frame(0); assert(strstr(last_notify,"closed"));
  printf("M8) combo works again after closing\n");
  frames(R3,2); frame(0); assert(g_state==ST_PLAYING); frames(0,18); assert(g_state==ST_IDLE);
  printf("M9) L3 held + OPTIONS opens, no mirrored playback leaks on L3 release\n");
  frames(L3,3); b=frame(L3|OPT); assert(g_menu.open && b==0); frame(L3); frame(0); assert(g_state==ST_IDLE);
  frames(0,3); assert(g_state==ST_IDLE);
  printf("M10) L3+OPTIONS closes; no playback afterwards\n");
  frame(L3); frame(L3|OPT); assert(!g_menu.open); frame(L3); frame(0); frames(0,3); assert(g_state==ST_IDLE);
  printf("M11) opening during recording cancels it, old combo kept\n");
  frames(L3|R3,2); frames(0,2); frames(SQ,3); assert(g_state==ST_RECORDING);
  frame(L3); frame(L3|OPT); assert(g_menu.open && g_state==ST_IDLE); assert(strstr(all_notify,"REC cancelled (menu opened)")); assert(g_slot_count==18);
  frame(0); frame(O); frame(0); assert(!g_menu.open);
  printf("M12) opening during playback stops it\n");
  frames(R3,2); frame(0); frames(0,3); assert(g_state==ST_PLAYING);
  // the L3 press itself is a new press -> cancels playback already (any-button cancel)
  frame(L3); assert(g_state==ST_IDLE); frame(L3|OPT); assert(g_menu.open); frame(0); frame(O); frame(0); assert(g_state==ST_IDLE);
  printf("M12b) L3+OPTIONS in one sample during playback: stops it, opens, no mirrored replay\n");
  frames(R3,2); frame(0); frames(0,3); assert(g_state==ST_PLAYING);
  frame(L3|OPT); assert(g_menu.open && g_state==ST_IDLE); frame(L3); frame(0); frames(0,3); assert(g_state==ST_IDLE);
  frame(O); frame(0); assert(!g_menu.open); frames(0,3); assert(g_state==ST_IDLE);
  printf("M13) second controller while menu open: passes through, no combo\n");
  frame(L3); frame(L3|OPT); frame(0); assert(g_menu.open);
  real_handle=7; b=frame(SQ); assert(b==SQ); frames(R3,2); frame(0); assert(g_state==ST_IDLE); b=frame(O); assert(b==O && g_menu.open); frame(0);
  real_handle=0; frame(O); frame(0); assert(!g_menu.open);
  printf("M14) both Normal -> flags 00 00, jump left in place\n");
  frame(L3); frame(L3|OPT); frame(0);
  frame(RIGHT); frame(0); assert(g_menu.health[0]==2);   // 1->2
  { const char *nm[]={"Damage 80%","Damage 60%","Damage 50%","Damage 105%","Damage 110%","Damage 120%","Damage 150%","Damage 200%"};  // 2->3..10 (v2.16), flags follow
    for(int v=3;v<=10;v++){ frame(RIGHT); frame(0); assert(g_menu.health[0]==v); assert(fake_mem[CAVE_OFF]==v);
      frame(X); frame(0); assert(strstr(last_notify,nm[v-3])); } }
  frame(RIGHT); frame(0); assert(g_menu.health[0]==0); // 10->0 wraps
  frame(LEFT); frame(0); assert(g_menu.health[0]==10 && fake_mem[CAVE_OFF]==10); frame(RIGHT); frame(0); assert(g_menu.health[0]==0);
  frame(DOWN); frame(0); frame(RIGHT); frame(0); assert(g_menu.health[1]==3); assert(fake_mem[CAVE_OFF+1]==3);  // 2->3
  for(int k=0;k<8;k++){ frame(RIGHT); frame(0); } assert(g_menu.health[1]==0);   // 3->..->10->0
  assert(!g_patch_failed && !strstr(all_notify,"Damage % "));
  assert(fake_mem[CAVE_OFF]==0 && fake_mem[CAVE_OFF+1]==0 && site_patched());
  frame(O); frame(0);
  printf("M15) foreign bytes at site block writes\n");
  g_cave_installed=0; g_patch_failed=0; memcpy(fake_mem+SITE_OFF,"\x90\x90\x90\x90\x90\x90\x90",7); int kw=kwrite_count;
  frame(L3); frame(L3|OPT); frame(0); frame(RIGHT); frame(0);
  assert(g_menu.health[0]==0); assert(kwrite_count==kw); assert(strstr(all_notify,"health patch blocked")); frame(O); frame(0);
  printf("M17) overlay row: cycles, always notifies, saved to overlay.cfg\n");
  frame(L3); frame(L3|OPT); frame(0); assert(g_menu.open);
  while(g_menu.selected!=ITEM_OVERLAY){ frame(DOWN); frame(0); }
  frame(RIGHT); frame(0); assert(g_menu.ovl==OVL_PS4); assert(strstr(last_notify,"overlay: PS4"));
  { char c=0; int fd=open("/tmp/tkcm_test/GoldHEN/combo_macro/overlay.cfg",O_RDONLY); assert(fd>=0); assert(read(fd,&c,1)==1); close(fd); assert(c=='1'); }
  frame(LEFT); frame(0); frame(LEFT); frame(0); assert(g_menu.ovl==OVL_OFF); assert(strstr(last_notify,"notifications"));
  frame(RIGHT); frame(0); assert(g_menu.ovl==OVL_AUTO);
  assert(g_menu.health[0]==0 && g_menu.health[1]==0);   // overlay row never touches health
  frame(DOWN); frame(0); assert(g_menu.selected==ITEM_P1_HEALTH);   // wraps 5 rows (v2.13: Overlay is still last)
  frame(UP); frame(0); assert(g_menu.selected==ITEM_OVERLAY);
  frame(O); frame(0); assert(!g_menu.open);
  printf("M18) overlay drawing: no notification spam, X and overlay changes still notify\n");
  g_test_overlay_ready=1; int nc=notify_count;
  frame(L3); frame(L3|OPT); frame(0); assert(g_menu.open); assert(notify_count==nc);
  for(int k=0;k<ITEM_COUNT-1;k++){ frame(UP); frame(0); } assert(g_menu.selected==ITEM_P1_HEALTH); assert(notify_count==nc);   // v2.13: 5 rows
  frame(X); frame(0); assert(notify_count==nc+1); assert(strstr(last_notify,"P1 Health"));
  frame(UP); frame(0); assert(g_menu.selected==ITEM_OVERLAY); assert(notify_count==nc+1);
  frame(RIGHT); frame(0); assert(notify_count==nc+2); frame(LEFT); frame(0); assert(notify_count==nc+3); assert(g_menu.ovl==OVL_AUTO);
  frame(O); frame(0); assert(!g_menu.open); assert(notify_count==nc+3);
  frame(SQ); assert(out.buttons==SQ); frame(0);   // game gets input again
  g_test_overlay_ready=0;
  printf("M19) overlay.cfg load\n");
  { int fd=open("/tmp/tkcm_test/GoldHEN/combo_macro/overlay.cfg",O_WRONLY|O_TRUNC); assert(write(fd,"3",1)==1); close(fd);
    overlay_cfg_load(); assert(g_menu.ovl==OVL_PRO_B);
    fd=open("/tmp/tkcm_test/GoldHEN/combo_macro/overlay.cfg",O_WRONLY|O_TRUNC); assert(write(fd,"x",1)==1); close(fd);
    overlay_cfg_load(); assert(g_menu.ovl==OVL_PRO_B); g_menu.ovl=OVL_AUTO; }

  printf("M20) menu names + overlay colour kinds (Damage = yellow, kind 3)\n");
  assert(HEALTH_CHOICES==11); assert(!strcmp(menu_value(HEALTH_DMG105),"Damage 105%") && !strcmp(menu_value(HEALTH_DMG200),"Damage 200%") && !strcmp(menu_value(11),"Normal")); assert(!strcmp(menu_value(HEALTH_DMG80),"Damage 80%") && !strcmp(menu_value(HEALTH_DMG60),"Damage 60%") && !strcmp(menu_value(HEALTH_DMG50),"Damage 50%"));
  assert(!strcmp(menu_value(0),"Normal") && !strcmp(menu_value(1),"Infinite") && !strcmp(menu_value(2),"1-Hit"));
  assert(menu_value_kind(0)==0 && menu_value_kind(1)==1 && menu_value_kind(2)==2 && menu_value_kind(3)==3 && menu_value_kind(5)==3 && menu_value_kind(6)==2 && menu_value_kind(10)==2 && menu_value_kind(11)==0);
  printf("M21) GoldHEN cheat 'Health' (TLH cave) already active: 1/2 still work, Damage refused + explained\n");
  memset(fake_mem+CAVE_OFF,0,0x200); memcpy(fake_mem+CAVE_OFF,CAVE,sizeof(CAVE)); memcpy(fake_mem+SITE_OFF,SITE_PATCH,7);
  g_cave_installed=0; g_patch_failed=0; g_cave_kind=0; g_cave_tlh_why=0; g_menu.health[0]=g_menu.health[1]=0; g_menu.selected=0;
  frame(L3); frame(L3|OPT); frame(0); assert(g_menu.open);
  frame(RIGHT); frame(0); assert(g_menu.health[0]==1 && g_cave_kind==CAVE_KIND_TLH && fake_mem[CAVE_OFF]==1);
  assert(memcmp(fake_mem+CAVE_OFF+2,CAVE+2,sizeof(CAVE)-2)==0);           // TLH cave left untouched
  frame(RIGHT); frame(0); assert(g_menu.health[0]==2 && fake_mem[CAVE_OFF]==2);
  frame(RIGHT); frame(0); assert(g_menu.health[0]==0 && fake_mem[CAVE_OFF]==0); assert(strstr(all_notify,"cheat \"Health\" is on"));  // 2 -> skips Damage -> Normal
  frame(LEFT); frame(0); assert(g_menu.health[0]==2 && fake_mem[CAVE_OFF]==2);    // Normal -> skips Damage -> 1-Hit
  for(int i=0;i<sizeof(CAVE);i++) assert(i<2 || fake_mem[CAVE_OFF+i]==CAVE[i]); assert(!g_patch_failed);
  frame(O); frame(0);
  printf("M22) only TLH's 83 bytes free: TLH cave installed, Damage refused, 1/2 work\n");
  memset(fake_mem+CAVE_OFF,0,0x200); fake_mem[CAVE_OFF+120]=0x55; memcpy(fake_mem+SITE_OFF,SITE_ORIG,7);
  g_cave_installed=0; g_patch_failed=0; g_cave_kind=0; g_cave_tlh_why=0; g_menu.health[0]=g_menu.health[1]=0; g_menu.selected=0;
  frame(L3); frame(L3|OPT); frame(0);
  frame(LEFT); frame(0); assert(g_menu.health[0]==0); assert(g_cave_kind==CAVE_KIND_TLH && site_patched());  // first pick Damage 200% (v2.16): refused
  assert(strstr(all_notify,"not available here")); assert(memcmp(fake_mem+CAVE_OFF+2,CAVE+2,sizeof(CAVE)-2)==0); assert(fake_mem[CAVE_OFF+120]==0x55);
  frame(RIGHT); frame(0); assert(g_menu.health[0]==1 && fake_mem[CAVE_OFF]==1);
  frame(O); frame(0);
  printf("M23) foreign bytes inside TLH's 83 bytes: blocked, nothing written\n");
  memset(fake_mem+CAVE_OFF,0,0x200); fake_mem[CAVE_OFF+40]=0x12; memcpy(fake_mem+SITE_OFF,SITE_ORIG,7);
  g_cave_installed=0; g_patch_failed=0; g_cave_kind=0; g_menu.health[0]=g_menu.health[1]=0; g_menu.selected=0; kw=kwrite_count;
  frame(L3); frame(L3|OPT); frame(0); frame(RIGHT); frame(0); assert(g_menu.health[0]==0 && kwrite_count==kw && g_patch_failed);
  assert(memcmp(fake_mem+SITE_OFF,SITE_ORIG,7)==0); frame(O); frame(0);
  printf("M24) plugin reload in the same game session finds its own extended cave\n");
  memset(fake_mem+CAVE_OFF,0,0x200); memcpy(fake_mem+CAVE_OFF,CAVE_DMG,sizeof(CAVE_DMG)); memcpy(fake_mem+SITE_OFF,SITE_PATCH,7);
  g_cave_installed=0; g_patch_failed=0; g_cave_kind=0; g_menu.health[0]=g_menu.health[1]=0; g_menu.selected=0;
  frame(L3); frame(L3|OPT); frame(0); frame(LEFT); frame(0); assert(g_menu.health[0]==10 && g_cave_kind==CAVE_KIND_DMG && fake_mem[CAVE_OFF]==10);
  frame(O); frame(0);
  printf("M16) unload restores flags path safely\n");
  assert(plugin_unload(0,0)==0); assert(fake_mem[CAVE_OFF]==0 && fake_mem[CAVE_OFF+1]==0);
  printf("ALL TESTS PASSED (combo + menu)\n"); return 0;
#endif
}
