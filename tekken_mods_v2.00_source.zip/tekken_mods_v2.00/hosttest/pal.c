#include <stdio.h>
#include <stdint.h>
#include "../repo/plugin_src/tekken_combo_macro/source/font8x8_basic.h"
#include "../repo/plugin_src/tekken_combo_macro/source/overlay_draw.h"
int main(){ for(int i=0;i<PAL_COUNT;i++) printf("%d %d %d\n",OV_PAL_RGB[i][0],OV_PAL_RGB[i][1],OV_PAL_RGB[i][2]); }
