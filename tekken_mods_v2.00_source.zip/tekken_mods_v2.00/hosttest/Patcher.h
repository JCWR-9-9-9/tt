
#pragma once
typedef struct { int x; } Patcher;
static inline void Patcher_Construct(Patcher*p){} static inline void Patcher_Destroy(Patcher*p){}
static inline void Patcher_Install_Patch(Patcher*p, uint64_t a, void*b, int n){}
