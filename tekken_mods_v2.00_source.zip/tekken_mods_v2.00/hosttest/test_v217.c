
#define TK_HOST_TEST 1
#include <fcntl.h>
#include <unistd.h>
#include <sys/stat.h>
#include <assert.h>
#include "plugin_common.h"
#include "Common.h"
#include "orbis/Pad.h"
char last_notify[512]; int notify_count; char all_notify[16384];
void NotifyStatic(const char* i, const char *t){ snprintf(last_notify,512,"%s",t); notify_count++; if(strlen(all_notify)+strlen(t)+2>=sizeof(all_notify)) all_notify[0]=0; /* harness: keep the buffer in bounds */ strcat(all_notify,t); strcat(all_notify,"|"); printf("  [NOTIFY] %s\n", t); }
void Notify(const char* i, const char *f, ...){ char b[512]; va_list a; va_start(a,f); vsnprintf(b,512,f,a); va_end(a); NotifyStatic(i,b);}
int sceKernelOpen(const char*p,int f,int m){ int ff=0; if(f&1) ff|=O_WRONLY; if(f&0x200) ff|=O_CREAT; if(f&0x400) ff|=O_TRUNC; return open(p,ff,m);}
ssize_t sceKernelWrite(int fd,const void*b,size_t n){return write(fd,b,n);} ssize_t sceKernelRead(int fd,void*b,size_t n){return read(fd,b,n);}
int sceKernelClose(int fd){return close(fd);} int sceKernelMkdir(const char*p,int m){return mkdir(p,m);}
int sceKernelRename(const char*a,const char*b){return rename(a,b);} int sceKernelUnlink(const char*p){return unlink(p);}
const char* sceKernelGetFsSandboxRandomWord(void){return "abc";} int sys_dynlib_load_prx(const char*p, int*h){return 0;}
int scePadRead(int h, OrbisPadData* d, int n){return 0;} int scePadReadState(int h, OrbisPadData* d){return 0;}
// fake eboot memory for the health cave
static unsigned char *fake_mem; static size_t fake_len;
#include "../repo/plugin_src/tekken_combo_macro/source/health_bytes.h"
int sys_sdk_proc_info(struct proc_info *pi){ memset(pi,0,sizeof(*pi));
#ifdef WRONG_TITLE
  strcpy(pi->titleid,"CUSA05972"); strcpy(pi->version,"01.00");
#else
  strcpy(pi->titleid,"CUSA06014"); strcpy(pi->version,"05.10");
#endif
  pi->base_address=(uint64_t)fake_mem; return 0; }
static int mapped(uint64_t at,size_t len,int w){ (void)w; return at>=(uint64_t)fake_mem && at+len<=(uint64_t)fake_mem+fake_len; }
static int kwrite_count;
static int kwrite(uint64_t at,const void*src,size_t n){ if(!mapped(at,n,1)) return 0; memcpy((void*)at,src,n); kwrite_count++; return 1; }
// scripted real pad
static uint32_t real_btn; static uint8_t real_lx=0x80; static uint64_t ts; static int real_handle;
int scePadReadStateExt(int h, OrbisPadData* d){ memset(d,0,sizeof(*d)); d->buttons=real_btn; d->leftStick.x=real_lx; d->leftStick.y=0x80; d->rightStick.x=d->rightStick.y=0x80; d->timestamp=(ts+=16667); d->touch.fingers=(real_btn&0x100000)?1:0; return 0; }
int scePadReadExt(int h, OrbisPadData* d, int n){ scePadReadStateExt(h,d); return 1; }
#include "../repo/plugin_src/tekken_combo_macro/source/main.c"
// v2.17 host tests (v1.09): slot 10 fixed combo (seed, file, decode, playback), slots 1-9 untouched, menu 1..10.
#define CHK(x) do { if(!(x)) { printf("FAIL line %d: %s\n", __LINE__, #x); exit(1); } } while(0)
#define SLOT10 "/tmp/tkcm_test/GoldHEN/combo_macro/slot10.bin"
static int file_size(const char *p){ struct stat st; if(stat(p,&st)!=0) return -1; return (int)st.st_size; }
static int file_exists2(const char *p){ return file_size(p)>=0; }
static unsigned char *slurp_file(const char *p, size_t *n){ FILE *f=fopen(p,"rb"); if(!f) return 0; fseek(f,0,SEEK_END); *n=ftell(f); fseek(f,0,SEEK_SET); unsigned char *b=malloc(*n+1); fread(b,1,*n,f); fclose(f); return b; }
static void menu_key(uint32_t btn){ static MenuPad mp; menu_step(&g_menu, &mp, 1, btn); }

#define SLOTDIR "/tmp/tkcm_test/GoldHEN/combo_macro/"
static char pth[160];
static const char *slotp(int i){ snprintf(pth,sizeof pth,SLOTDIR "slot%d.bin",i); return pth; }
static void pad_key(uint32_t btn){ OrbisPadData d; memset(&d,0,sizeof d); d.buttons=btn; d.leftStick.x=d.leftStick.y=d.rightStick.x=d.rightStick.y=0x80; process_sample(1,&d,0); }
static void tap(uint32_t btn){ pad_key(btn); pad_key(0); }
static int same_bytes(const char *p, unsigned char *ref, size_t n){ size_t m=0; unsigned char *b=slurp_file(p,&m); int ok=b && m==n && (n==0 || memcmp(b,ref,n)==0); free(b); return ok; }
static void to_in(int k){ for(int i=0;i<60;i++) tap(MB_UP); for(int i=0;i<g_menu.mk_n+k;i++) tap(MB_DOWN); }
static int tv(uint32_t i){ return (int)((uint64_t)i*1000000u/60u); }

int main(void){ setvbuf(stdout,0,_IONBF,0);
  system("rm -rf /tmp/tkcm_test; mkdir -p /tmp/tkcm_test");
  fake_len=CAVE_OFF+0x1000; fake_mem=calloc(1,fake_len); memcpy(fake_mem+SITE_OFF,SITE_ORIG,7);
  static MacroStep seed[MAX_STEPS], w[MAX_STEPS]; static CePress o2[ED_MAX_PRESSES];
  static CePress pr[ED_MAX_PRESSES]; static uint32_t gp[ED_MAX_PRESSES];

  printf("P1) the parse finds the ten presses of the seed (slot 10), on the 60 Hz grid\n");
  CHK(plugin_load(0,0)==0);
  CHK(g_menu_enabled);
  uint32_t n0 = slot_read(9, seed, NULL); CHK(n0==150);
  int P = ce_parse(seed, n0, pr, ED_MAX_PRESSES); CHK(P==10);
  const uint32_t want_start[10]={0,12,24,36,54,72,90,108,126,144};
  for(int k=0;k<10;k++){ CHK(pr[k].start==want_start[k]); CHK(pr[k].hold==3); }
  CHK(pr[0].buttons==(0x8000u|0x40u|0x20u)); CHK(pr[1].buttons==0x1000u); CHK(pr[9].buttons==0x2000u);
  CHK(ce_min_gap(pr,P,0)==3 && ce_min_gap(pr,P,1)==4 && ce_min_gap(pr,P,9)==4);
  for(int k=0;k<P;k++) gp[k]=ce_gap_frames(pr,P,n0,k);
  CHK(gp[0]==12 && gp[1]==12 && gp[3]==18 && gp[9]==6);

  printf("P2) rebuild with the gaps as they are gives the same steps back (t_us rewritten on the grid)\n");
  uint32_t n1 = ce_rebuild(seed,n0,pr,P,gp,w); CHK(n1==n0);
  for(uint32_t i=0;i<n0;i++){ CHK(w[i].buttons==seed[i].buttons && w[i].lx==seed[i].lx && w[i].ly==seed[i].ly && w[i].rx==seed[i].rx && w[i].ry==seed[i].ry && w[i].l2==seed[i].l2 && w[i].r2==seed[i].r2 && w[i].reserved==seed[i].reserved);
    CHK(w[i].t_us==(uint32_t)tv(i)); }

  printf("P3) editing a gap moves the following presses, rewrites t_us, keeps order and buttons\n");
  gp[1]=15;
  uint32_t n2 = ce_rebuild(seed,n0,pr,P,gp,w); CHK(n2==n0+3);
  CHK(ce_parse(w,n2,o2,ED_MAX_PRESSES)==10);
  const uint32_t want2[10]={0,12,27,39,57,75,93,111,129,147};
  for(int k=0;k<10;k++){ CHK(o2[k].start==want2[k]); CHK(o2[k].buttons==pr[k].buttons); CHK(o2[k].hold==3); }
  for(uint32_t i=0;i<n2;i++) CHK(w[i].t_us==(uint32_t)tv(i));
  CHK(w[27].t_us==450000u);
  CHK(w[12].buttons==0x1000u && w[15].buttons==0 && w[26].buttons==0 && w[27].buttons==0x1000u);
  CHK(ce_hundredths(15)==25 && ce_hundredths(12)==20 && ce_hundredths(0)==0 && ce_hundredths(60)==100);
  gp[1]=2;   CHK(ce_rebuild(seed,n0,pr,P,gp,w)==0);
  gp[1]=12;

  printf("P4) names: short, full, unknown bit marked, empty dash\n");
  char nm[32];
  ce_button_name(nm,sizeof nm,0x8060u,1); CHK(!strcmp(nm,"Dn+Rt+Sq"));
  ce_button_name(nm,sizeof nm,0x8060u,0); CHK(!strcmp(nm,"Down+Right+Square"));
  ce_button_name(nm,sizeof nm,0x100000u,1); CHK(!strcmp(nm,"?"));
  ce_button_name(nm,sizeof nm,0,1); CHK(!strcmp(nm,"-"));

  printf("P5) the maker builds frames from hundredths; parse reads back the same presses and times; gap clamps to the minimum\n");
  MkPress mk[3] = {{0x2000u,20},{0x8000u,30},{0x4000u,1}};        // 0.20 s = 12 frames, 0.30 s = 18, 0.01 s -> min 4
  uint32_t nm3 = ce_make_build(mk,3,w); CHK(nm3==12+18+4);
  CHK(ce_parse(w,nm3,pr,ED_MAX_PRESSES)==3);
  CHK(pr[0].start==0 && pr[1].start==12 && pr[2].start==30);
  CHK(pr[0].buttons==0x2000u && pr[1].buttons==0x8000u && pr[2].buttons==0x4000u);
  for(int k=0;k<3;k++) CHK(pr[k].hold==3);
  for(uint32_t i=0;i<nm3;i++) CHK(w[i].t_us==(uint32_t)tv(i));

  printf("F1) fresh console: slot 10 seeded, slots 1-9 absent\n");
  for(int i=1;i<=9;i++) CHK(!file_exists2(slotp(i)));
  CHK(file_size(slotp(10))==32+16*150);
  size_t seed_n=0; unsigned char *seed_bytes = slurp_file(slotp(10),&seed_n); CHK(seed_bytes);

  printf("E1) menu opens; Triangle on the Combo slot row opens the tools; O goes back\n");
  pad_key(MB_L3); pad_key(MB_L3|MB_OPTIONS); pad_key(0);
  CHK(g_menu.open && g_menu.page==PG_MAIN);
  g_menu.selected=ITEM_SLOT; g_menu.slot=9;
  tap(MB_TRIANGLE); CHK(g_menu.page==PG_TOOLS && g_menu.sub==0);
  tap(MB_CIRCLE); CHK(g_menu.page==PG_MAIN);
  tap(MB_TRIANGLE); CHK(g_menu.page==PG_TOOLS);

  printf("E2) editor on slot 10: gap of press 2 +3 frames; O cancels, nothing written\n");
  tap(MB_CROSS); CHK(g_menu.page==PG_EDIT && g_ed_P==10 && g_menu.ed_n==10 && g_menu.ed_cur==0);
  tap(MB_DOWN); CHK(g_menu.ed_cur==1);
  tap(MB_RIGHT); tap(MB_RIGHT); tap(MB_RIGHT);
  CHK(g_ed_gap[1]==15 && g_ed_dirty==1 && g_ed_work_n==153);
  CHK(same_bytes(slotp(10),seed_bytes,seed_n));
  tap(MB_CIRCLE); CHK(g_menu.page==PG_TOOLS);
  CHK(same_bytes(slotp(10),seed_bytes,seed_n));
  CHK(g_slot_len[9]==150);

  printf("E3) reopen reads the file again; one gap resets with Triangle; the limits clamp\n");
  tap(MB_CROSS); CHK(g_ed_gap[1]==12 && !g_ed_dirty);
  tap(MB_DOWN); tap(MB_RIGHT); CHK(g_ed_gap[1]==13 && g_ed_dirty);
  tap(MB_TRIANGLE); CHK(g_ed_gap[1]==12 && !g_ed_dirty);
  tap(MB_UP); CHK(g_menu.ed_cur==0);
  for(int i=0;i<20;i++) tap(MB_LEFT);
  CHK(g_ed_gap[0]==3);                                   // min = the press's own hold (Square+Down+Right: 3 frames)
  tap(MB_RIGHT); CHK(g_ed_gap[0]==4);
  tap(MB_TRIANGLE); CHK(g_ed_gap[0]==12 && !g_ed_dirty);
  for(int i=0;i<300;i++) tap(MB_R1);
  CHK(g_ed_gap[0]==CE_GAP_MAX);                          // max 5.00 s
  tap(MB_TRIANGLE); CHK(g_ed_gap[0]==12 && !g_ed_dirty);
  tap(MB_CIRCLE); CHK(g_menu.page==PG_TOOLS);

  printf("E4) save: the file gets the new timing; header kept (10 presses); playback buffer follows\n");
  tap(MB_CROSS); tap(MB_DOWN); for(int i=0;i<3;i++) tap(MB_RIGHT);
  all_notify[0]=0; tap(MB_CROSS); CHK(g_menu.page==PG_TOOLS);
  CHK(file_size(slotp(10))==32+16*153);
  { size_t m; unsigned char *b=slurp_file(slotp(10),&m); MacroHeader h; memcpy(&h,b,sizeof h);
    CHK(h.magic==0x4D434B54u && h.version==1 && h.count==153 && h.step_size==16 && h.presses==10);
    free(b); }
  uint32_t np=0; uint32_t ns=slot_read(9,w,&np); CHK(ns==153 && np==10);
  CHK(ce_parse(w,ns,o2,ED_MAX_PRESSES)==10);
  for(int k=0;k<10;k++) CHK(o2[k].start==want2[k]);
  for(uint32_t i=0;i<ns;i++) CHK(w[i].t_us==(uint32_t)tv(i));
  CHK(g_slot_len[9]==153 && g_slot_count==153);
  CHK(strstr(all_notify,"timing saved"));

  printf("E5) saving with nothing changed writes nothing\n");
  tap(MB_CROSS); CHK(g_menu.page==PG_EDIT);
  size_t m5=0; unsigned char *b5=slurp_file(slotp(10),&m5);
  tap(MB_CROSS); CHK(g_menu.page==PG_TOOLS);
  CHK(same_bytes(slotp(10),b5,m5)); free(b5);

  printf("M1) maker (v2.18 one screen): Circle, then Square, then Up+Right + Square; edit a gap; delete Square\n");
  tap(MB_DOWN); tap(MB_CROSS); CHK(g_menu.page==PG_MAKE && g_menu.mk_n==0 && g_menu.mk_gap==CE_GAP_CS_DEF && g_menu.sub==0);
  tap(MB_CROSS); CHK(g_menu.mk_n==0 && strstr(all_notify,"Pick a direction or a button first"));
  tap(MB_DOWN); tap(MB_RIGHT); tap(MB_RIGHT); CHK(CE_BTN_BITS[g_menu.mk_btn]==0x2000u);
  tap(MB_CROSS); CHK(g_menu.mk_n==1 && g_menu.mk[0].buttons==0x2000u && g_menu.mk[0].cs==20 && g_menu.sub==2);
  tap(MB_RIGHT); CHK(CE_BTN_BITS[g_menu.mk_btn]==0x8000u);
  tap(MB_CROSS); CHK(g_menu.mk_n==2 && g_menu.mk[1].buttons==0x8000u && g_menu.sub==3);
  to_in(0); CHK(g_menu.sub==g_menu.mk_n+0);                  // Direction row
  tap(MB_RIGHT); tap(MB_RIGHT); CHK(CE_DIR_MASK[g_menu.mk_dir]==0x0030u);
  tap(MB_DOWN); tap(MB_CROSS); CHK(g_menu.mk_n==3 && g_menu.mk[2].buttons==(0x0030u|0x8000u) && g_menu.mk[2].cs==20);
  CHK(g_menu.sub==g_menu.mk_n+1);                             // the cursor stayed on Button
  tap(MB_DOWN); for(int i=0;i<8;i++) tap(MB_RIGHT); CHK(g_menu.mk_gap==28 && g_menu.sub==g_menu.mk_n+2);
  to_in(-3); CHK(g_menu.sub==0);                              // first step
  tap(MB_RIGHT); tap(MB_RIGHT); tap(MB_RIGHT); CHK(g_menu.mk[0].cs==23 && g_menu.mk[1].cs==20 && g_menu.mk[2].cs==20);
  tap(MB_LEFT); tap(MB_LEFT); tap(MB_LEFT); CHK(g_menu.mk[0].cs==20);
  tap(MB_R1); CHK(g_menu.mk[0].cs==30); tap(MB_L1); CHK(g_menu.mk[0].cs==20);
  for(int i=0;i<600;i++) tap(MB_RIGHT); CHK(g_menu.mk[0].cs==CE_GAP_CS_MAX);   // max 5.00 s
  for(int i=0;i<600;i++) tap(MB_LEFT);  CHK(g_menu.mk[0].cs==CE_GAP_CS_MIN);   // min 0.07 s (4 frames)
  for(int i=0;i<6;i++) tap(MB_RIGHT);   CHK(g_menu.mk[0].cs==13);              // 0.01 s steps
  for(int i=0;i<3;i++) tap(MB_LEFT);    CHK(g_menu.mk[0].cs==10);
  for(int i=0;i<10;i++) tap(MB_RIGHT);  CHK(g_menu.mk[0].cs==20);
  CHK(ce_cs_frames(20)==12 && ce_cs_frames(7)==4 && ce_cs_frames(500)==300 && ce_cs_frames(10)==6 && ce_cs_frames(1)==4);
  tap(MB_DOWN); CHK(g_menu.sub==1);                           // delete the Square step (step 2)
  tap(MB_TRIANGLE); CHK(g_menu.mk_n==2 && g_menu.mk[1].buttons==(0x0030u|0x8000u) && g_menu.sub==1);
  CHK(g_menu.mk[0].buttons==0x2000u && g_menu.mk[0].cs==20);

  printf("M2) choose slot 3 (empty): Save row, X picks the slot, X saves it: Circle, then Up+Right + Square\n");
  to_in(4); CHK(g_menu.sub==g_menu.mk_n+4);
  tap(MB_CROSS); CHK(g_menu.page==PG_MAKE_SLOT && g_menu.mk_slot==9);
  tap(MB_RIGHT); tap(MB_RIGHT); tap(MB_RIGHT); CHK(g_menu.mk_slot==2);
  all_notify[0]=0; tap(MB_DOWN); tap(MB_CROSS);
  CHK(g_menu.page==PG_TOOLS && file_size(slotp(3))==32+16*24);
  CHK(!file_exists2(slotp(4)));
  { uint32_t np3=0; uint32_t n3=slot_read(2,w,&np3); CHK(n3==24 && np3==2);
    CHK(ce_parse(w,n3,pr,ED_MAX_PRESSES)==2 && pr[0].start==0 && pr[1].start==12);
    CHK(pr[0].buttons==0x2000u && pr[1].buttons==(0x0030u|0x8000u) && pr[0].hold==3 && pr[1].hold==3);
    for(uint32_t i=0;i<n3;i++) CHK(w[i].t_us==(uint32_t)tv(i));
    CHK(w[3].buttons==0 && w[12].buttons==(0x0030u|0x8000u) && w[23].buttons==0);
    CHK(w[0].lx==0x80 && w[0].ry==0x80); }
  CHK(g_menu.slot==2 && g_slot_len[2]==24 && g_slot_presses[2]==2 && g_slot_count==24);
  CHK(strstr(all_notify,"Combo saved to slot 3"));

  printf("M3) slot 3 is full now: first X arms (nothing written), second X replaces it\n");
  tap(MB_CROSS); CHK(g_menu.page==PG_MAKE && g_menu.mk_n==0);
  tap(MB_DOWN); tap(MB_RIGHT); tap(MB_RIGHT); tap(MB_CROSS); CHK(g_menu.mk_n==1);
  to_in(4); CHK(g_menu.sub==g_menu.mk_n+4);
  tap(MB_CROSS); CHK(g_menu.page==PG_MAKE_SLOT && g_menu.mk_slot==2);
  size_t m3=0; unsigned char *b3=slurp_file(slotp(3),&m3);
  tap(MB_DOWN); tap(MB_CROSS); CHK(g_menu.mk_armed==1 && g_menu.page==PG_MAKE_SLOT);
  CHK(same_bytes(slotp(3),b3,m3));
  tap(MB_CROSS); CHK(g_menu.page==PG_TOOLS);
  CHK(file_size(slotp(3))==32+16*12);
  { uint32_t np3=0; uint32_t n3=slot_read(2,w,&np3); CHK(n3==12 && np3==1); }
  free(b3);

  printf("C1) maker cancel with a step entered: nothing written\n");
  tap(MB_CROSS); CHK(g_menu.page==PG_MAKE);
  tap(MB_DOWN); tap(MB_RIGHT); tap(MB_RIGHT); tap(MB_CROSS); CHK(g_menu.mk_n==1);
  all_notify[0]=0; tap(MB_CIRCLE); CHK(g_menu.page==PG_TOOLS && g_menu.mk_n==0 && g_menu.sub==1);
  CHK(!file_exists2(slotp(4)));
  CHK(strstr(all_notify,"Combo maker cancelled"));

  printf("C2) timing edit closed by L3+OPTIONS: nothing written\n");
  tap(MB_UP); CHK(g_menu.sub==0);
  tap(MB_CROSS); CHK(g_menu.page==PG_EDIT && g_ed_slot==2);
  size_t m6=0; unsigned char *b6=slurp_file(slotp(3),&m6);
  tap(MB_DOWN); tap(MB_RIGHT); CHK(g_ed_dirty==1);
  pad_key(MB_L3); pad_key(MB_L3|MB_OPTIONS); pad_key(0);
  CHK(!g_menu.open && g_menu.page==PG_MAIN);
  CHK(same_bytes(slotp(3),b6,m6)); free(b6);

  printf("S1) slots 1-9: only slot 3 exists among them (saved by the maker); the other slots are untouched\n");
  for(int i=1;i<=9;i++){ if(i==3) continue; CHK(!file_exists2(slotp(i))); }
  CHK(file_size(slotp(3))==32+16*12);
  free(seed_bytes);

  printf("ALL v2.17 TESTS PASSED (parse, rebuild, t_us, names, maker build, editor, maker v2.18 screen, cancels, slots)\n");
  return 0;
}
