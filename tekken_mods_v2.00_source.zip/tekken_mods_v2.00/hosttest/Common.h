
#pragma once
typedef struct { int x; } Detour;
#define HOOK_INIT(n) Detour Detour_##n
#define HOOK32(n) do{}while(0)
#define UNHOOK(n) do{}while(0)
int sceKernelOpen(const char*,int,int); ssize_t sceKernelWrite(int,const void*,size_t); ssize_t sceKernelRead(int,void*,size_t);
int sceKernelClose(int); int sceKernelMkdir(const char*,int); int sceKernelRename(const char*,const char*); int sceKernelUnlink(const char*);
const char* sceKernelGetFsSandboxRandomWord(void); int sys_dynlib_load_prx(const char*, int*);

struct proc_info { int pid; char name[32]; char path[64]; char titleid[16]; char contentid[64]; char version[8]; uint64_t base_address; };
struct proc_rw { uint64_t address; void *data; uint64_t length; uint64_t write_flags; };
int sys_sdk_proc_info(struct proc_info *);
