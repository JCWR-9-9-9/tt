
#define TK_HOST_TEST 1
#include <fcntl.h>
#include <unistd.h>
#include <sys/stat.h>
#include <assert.h>
#include "plugin_common.h"
#include "Common.h"
#include "orbis/Pad.h"
char last_notify[512]; int notify_count; char all_notify[16384];
void NotifyStatic(const char* i, const char *t){ snprintf(last_notify,512,"%s",t); notify_count++; strncat(all_notify,t,sizeof(all_notify)-strlen(all_notify)-2); strcat(all_notify,"|"); printf("  [NOTIFY] %s\n", t); }
void Notify(const char* i, const char *f, ...){ char b[512]; va_list a; va_start(a,f); vsnprintf(b,512,f,a); va_end(a); NotifyStatic(i,b);}
int sceKernelOpen(const char*p,int f,int m){ int ff=0; if(f&1) ff|=O_WRONLY; if(f&0x200) ff|=O_CREAT; if(f&0x400) ff|=O_TRUNC; return open(p,ff,m);}
ssize_t sceKernelWrite(int fd,const void*b,size_t n){return write(fd,b,n);} ssize_t sceKernelRead(int fd,void*b,size_t n){return read(fd,b,n);}
int sceKernelClose(int fd){return close(fd);} int sceKernelMkdir(const char*p,int m){return mkdir(p,m);}
int sceKernelRename(const char*a,const char*b){return rename(a,b);} int sceKernelUnlink(const char*p){return unlink(p);}
const char* sceKernelGetFsSandboxRandomWord(void){return "abc";} int sys_dynlib_load_prx(const char*p, int*h){return 0;}
int scePadRead(int h, OrbisPadData* d, int n){return 0;} int scePadReadState(int h, OrbisPadData* d){return 0;}
// fake eboot memory for the health cave
static unsigned char *fake_mem; static size_t fake_len;
#include "../repo/plugin_src/tekken_combo_macro/source/health_bytes.h"
int sys_sdk_proc_info(struct proc_info *pi){ memset(pi,0,sizeof(*pi));
#ifdef WRONG_TITLE
  strcpy(pi->titleid,"CUSA05972"); strcpy(pi->version,"01.00");
#else
  strcpy(pi->titleid,"CUSA06014"); strcpy(pi->version,"05.10");
#endif
  pi->base_address=(uint64_t)fake_mem; return 0; }
static int mapped(uint64_t at,size_t len,int w){ (void)w; return at>=(uint64_t)fake_mem && at+len<=(uint64_t)fake_mem+fake_len; }
static int kwrite_count;
static int kwrite(uint64_t at,const void*src,size_t n){ if(!mapped(at,n,1)) return 0; memcpy((void*)at,src,n); kwrite_count++; return 1; }
// scripted real pad
static uint32_t real_btn; static uint8_t real_lx=0x80; static uint64_t ts; static int real_handle;
int scePadReadStateExt(int h, OrbisPadData* d){ memset(d,0,sizeof(*d)); d->buttons=real_btn; d->leftStick.x=real_lx; d->leftStick.y=0x80; d->rightStick.x=d->rightStick.y=0x80; d->timestamp=(ts+=16667); d->touch.fingers=(real_btn&0x100000)?1:0; return 0; }
int scePadReadExt(int h, OrbisPadData* d, int n){ scePadReadStateExt(h,d); return 1; }
#include "../repo/plugin_src/tekken_combo_macro/source/main.c"
// v2.16 host tests: slot 10 fixed combo (seed, file, decode, playback), slots 1-9 untouched, menu 1..10.
#define CHK(x) do { if(!(x)) { printf("FAIL line %d: %s\n", __LINE__, #x); exit(1); } } while(0)
#define SLOT10 "/tmp/tkcm_test/GoldHEN/combo_macro/slot10.bin"
static int file_size(const char *p){ struct stat st; if(stat(p,&st)!=0) return -1; return (int)st.st_size; }
static int file_exists2(const char *p){ return file_size(p)>=0; }
static unsigned char *slurp_file(const char *p, size_t *n){ FILE *f=fopen(p,"rb"); if(!f) return 0; fseek(f,0,SEEK_END); *n=ftell(f); fseek(f,0,SEEK_SET); unsigned char *b=malloc(*n+1); fread(b,1,*n,f); fclose(f); return b; }
static void menu_key(uint32_t btn){ static MenuPad mp; menu_step(&g_menu, &mp, 1, btn); }
int main(void){ setvbuf(stdout,0,_IONBF,0);
  system("rm -rf /tmp/tkcm_test; mkdir -p /tmp/tkcm_test");
  fake_len=CAVE_OFF+0x1000; fake_mem=calloc(1,fake_len); memcpy(fake_mem+SITE_OFF,SITE_ORIG,7);

  printf("F1) fresh console: plugin load writes the fixed combo into slot 10 only\n");
  CHK(plugin_load(0,0)==0);
  CHK(file_size(SLOT10)==32+16*150);
  for(int i=1;i<=9;i++){ char p[128]; snprintf(p,sizeof p,"/tmp/tkcm_test/GoldHEN/combo_macro/slot%d.bin",i); CHK(!file_exists2(p)); }
  CHK(g_slot_len[9]==150 && g_slot_presses[9]==10);
  for(int i=0;i<9;i++) CHK(g_slot_len[i]==0);
  CHK(g_slot_count==0 && g_menu.slot==0);   // slot 1 still selected and empty
  CHK(strstr(all_notify,"Tekken Combo + Mod Menu ON (v2.18)"));

  printf("F2) slot10.bin header: magic TKCM, version 1, count 150, step 16, presses 10\n");
  system("cp " SLOT10 " /tmp/tkcm_test/slot10_seed_v216.bin");
  { size_t n; unsigned char *b=slurp_file(SLOT10,&n); CHK(b && n==32+16*150);
    MacroHeader h; memcpy(&h,b,sizeof h);
    CHK(h.magic==0x4D434B54u && h.version==1 && h.count==150 && h.step_size==16 && h.presses==10);
    free(b); }

  printf("F3) the ten presses on the 60 Hz grid, 50 ms taps, D-pad down-right on press 1\n");
  { static const uint32_t want_ms[10]={0,200,400,600,900,1200,1500,1800,2100,2400};
    static const uint32_t want_btn[10]={MB_SQUARE|MB_DOWN|MB_RIGHT, MB_TRIANGLE, MB_TRIANGLE, MB_SQUARE, MB_CROSS, MB_CROSS, MB_CROSS, MB_CIRCLE, MB_CROSS, MB_CIRCLE};
    CHK(macro_load()!=0 && g_slot_count==0);   // slot 1 is selected, still empty
    g_menu.slot=9; CHK(macro_load()==0 && g_slot_count==150);
    int press=0;
    for(uint32_t f=0; f<150; f++){
      uint32_t b=g_slot[f].buttons;
      uint32_t prev = f? g_slot[f-1].buttons : 0;
      uint32_t rise = b & ~prev & ~BTN_INTERCEPT;
      if(rise){ CHK(press<10); CHK(f*1000000u/60u == want_ms[press]*1000u); CHK(g_slot[f].t_us==want_ms[press]*1000u);
        CHK(rise==(want_btn[press] & ~(want_btn[press]&prev))); press++; }
      if(press>0 && f < 150){ /* held for exactly 3 samples */ }
    }
    CHK(press==10);
    for(int p=0;p<10;p++){ uint32_t f0=want_ms[p]*60u/1000u; for(uint32_t k=0;k<3;k++) CHK(g_slot[f0+k].buttons==want_btn[p]); CHK(g_slot[f0+3].buttons==0); }
    for(uint32_t f=0; f<150; f++){ int inp=0; for(int p=0;p<10;p++){ uint32_t f0=want_ms[p]*60u/1000u; if(f>=f0 && f<f0+3) inp=1; } if(!inp) CHK(g_slot[f].buttons==0); }
    CHK(g_slot[0].lx==0x80 && g_slot[0].ly==0x80 && g_slot[0].rx==0x80 && g_slot[0].ry==0x80 && g_slot[0].l2==0 && g_slot[0].r2==0);
  }

  printf("F4) playback: each stored step gives the pad the same sample (press 1 down-right, mirror flips it)\n");
  { OrbisPadData d; memset(&d,0,sizeof d); d.leftStick.x=d.leftStick.y=d.rightStick.x=d.rightStick.y=0x80;
    apply_step(&d,&g_slot[0],0); CHK(d.buttons==(MB_SQUARE|MB_DOWN|MB_RIGHT));
    memset(&d,0,sizeof d); apply_step(&d,&g_slot[0],1); CHK(d.buttons==(MB_SQUARE|MB_DOWN|MB_LEFT));
    memset(&d,0,sizeof d); apply_step(&d,&g_slot[12],0); CHK(d.buttons==MB_TRIANGLE); memset(&d,0,sizeof d); apply_step(&d,&g_slot[3],0); CHK(d.buttons==0);
    memset(&d,0,sizeof d); apply_step(&d,&g_slot[149],0); CHK(d.buttons==0); }

  printf("F5) menu row Combo slot cycles 1..10 and wraps; slot 10 shows its combo\n");
  { g_menu.open=1; g_menu.owner=1; g_menu.slot=0; g_menu.selected=ITEM_SLOT;
    OvMenuView v;
    for(int k=1;k<=10;k++){ menu_key(0); menu_key(MB_RIGHT); CHK(g_menu.slot==k%10); }
    menu_key(0); menu_key(MB_LEFT); CHK(g_menu.slot==9);
    menu_key(0); menu_key(MB_LEFT); CHK(g_menu.slot==8);
    g_menu.slot=9; g_menu.selected=ITEM_SLOT; menu_view_fill(&v,"x");
    CHK(!strcmp(v.value[2],"10: 2.5s")); CHK(v.value_kind[2]==1); CHK(v.strip_sel==9); CHK(v.strip_full==((1u<<9))); }

  printf("F6) menu Square, Square clears slot 10; the fixed combo comes back at the next plugin load\n");
  { g_menu.slot=9; g_menu.selected=ITEM_SLOT; menu_key(0); menu_key(MB_SQUARE); menu_key(0); menu_key(MB_SQUARE);
    CHK(slot_clear(9)==0); CHK(!file_exists2(SLOT10)); CHK(g_slot_len[9]==0);
    CHK(plugin_load(0,0)==0); CHK(file_size(SLOT10)==32+16*150); CHK(g_slot_len[9]==150); }

  printf("F7) a recording already in slot 10 is never replaced; slots 1-9 are not touched by the seed\n");
  { MacroStep mine[20]; memset(mine,0,sizeof mine); for(int i=0;i<20;i++){ mine[i].lx=mine[i].ly=mine[i].rx=mine[i].ry=0x80; mine[i].buttons=(i%4==0)?MB_CIRCLE:0; }
    g_menu.slot=9; CHK(slot_write(9,mine,20,count_presses(mine,20),0)==0);
    g_menu.slot=2; memcpy(g_slot,mine,sizeof mine); g_slot_count=20; CHK(slot_write(2,mine,20,count_presses(mine,20),0)==0);
    CHK(file_size("/tmp/tkcm_test/GoldHEN/combo_macro/slot3.bin")==32+16*20);   // slot index 2 = slot 3
    CHK(plugin_load(0,0)==0);
    size_t n; unsigned char *b=slurp_file(SLOT10,&n); CHK(b && n==32+16*20); MacroHeader h; memcpy(&h,b,sizeof h); CHK(h.count==20 && h.presses==5); free(b);
    CHK(g_slot_len[9]==20 && g_slot_presses[9]==5);
    CHK(g_slot_len[2]==20 && g_slot_len[0]==0 && g_slot_len[1]==0); }

  printf("F8) saving slot 1 writes the same bytes layout as before (header presses from the steps)\n");
  { MacroStep r[4]; memset(r,0,sizeof r); for(int i=0;i<4;i++){ r[i].lx=r[i].ly=r[i].rx=r[i].ry=0x80; } r[1].buttons=MB_SQUARE; r[2].buttons=MB_SQUARE; r[3].buttons=MB_CROSS;
    CHK(slot_write(0,r,4,count_presses(r,4),0)==0); size_t n; unsigned char *b=slurp_file("/tmp/tkcm_test/GoldHEN/combo_macro/slot1.bin",&n);
    CHK(b && n==32+16*4); MacroHeader h; memcpy(&h,b,sizeof h); CHK(h.presses==2 && h.count==4 && h.step_size==16); free(b); }

  printf("ALL v2.16 TESTS PASSED (slot 10 seed, file, decode, playback, menu, clear, no-overwrite)\n");
  return 0;
}
