
#define TK_HOST_TEST 1
#include <fcntl.h>
#include <unistd.h>
#include <sys/stat.h>
#include <assert.h>
#include "plugin_common.h"
#include "Common.h"
#include "orbis/Pad.h"
char last_notify[512]; int notify_count; char all_notify[16384];
void NotifyStatic(const char* i, const char *t){ snprintf(last_notify,512,"%s",t); notify_count++; strncat(all_notify,t,sizeof(all_notify)-strlen(all_notify)-2); strcat(all_notify,"|"); printf("  [NOTIFY] %s\n", t); }
void Notify(const char* i, const char *f, ...){ char b[512]; va_list a; va_start(a,f); vsnprintf(b,512,f,a); va_end(a); NotifyStatic(i,b);}
int sceKernelOpen(const char*p,int f,int m){ int ff=0; if(f&1) ff|=O_WRONLY; if(f&0x200) ff|=O_CREAT; if(f&0x400) ff|=O_TRUNC; return open(p,ff,m);}
ssize_t sceKernelWrite(int fd,const void*b,size_t n){return write(fd,b,n);} ssize_t sceKernelRead(int fd,void*b,size_t n){return read(fd,b,n);}
int sceKernelClose(int fd){return close(fd);} int sceKernelMkdir(const char*p,int m){return mkdir(p,m);}
int sceKernelRename(const char*a,const char*b){return rename(a,b);} int sceKernelUnlink(const char*p){return unlink(p);}
const char* sceKernelGetFsSandboxRandomWord(void){return "abc";} int sys_dynlib_load_prx(const char*p, int*h){return 0;}
int scePadRead(int h, OrbisPadData* d, int n){return 0;} int scePadReadState(int h, OrbisPadData* d){return 0;}
// fake eboot memory for the health cave
static unsigned char *fake_mem; static size_t fake_len;
#include "../repo/plugin_src/tekken_combo_macro/source/health_bytes.h"
int sys_sdk_proc_info(struct proc_info *pi){ memset(pi,0,sizeof(*pi));
#ifdef WRONG_TITLE
  strcpy(pi->titleid,"CUSA05972"); strcpy(pi->version,"01.00");
#else
  strcpy(pi->titleid,"CUSA06014"); strcpy(pi->version,"05.10");
#endif
  pi->base_address=(uint64_t)fake_mem; return 0; }
static int mapped(uint64_t at,size_t len,int w){ (void)w; return at>=(uint64_t)fake_mem && at+len<=(uint64_t)fake_mem+fake_len; }
static int kwrite_count;
static int kwrite(uint64_t at,const void*src,size_t n){ if(!mapped(at,n,1)) return 0; memcpy((void*)at,src,n); kwrite_count++; return 1; }
// scripted real pad
static uint32_t real_btn; static uint8_t real_lx=0x80; static uint64_t ts; static int real_handle;
int scePadReadStateExt(int h, OrbisPadData* d){ memset(d,0,sizeof(*d)); d->buttons=real_btn; d->leftStick.x=real_lx; d->leftStick.y=0x80; d->rightStick.x=d->rightStick.y=0x80; d->timestamp=(ts+=16667); d->touch.fingers=(real_btn&0x100000)?1:0; return 0; }
static int read_k=1;   // samples scePadRead returns per call (buffered read)
int scePadReadExt(int h, OrbisPadData* d, int n){ int k=read_k<n?read_k:n; for(int i=0;i<k;i++) scePadReadStateExt(h,&d[i]); return k; }
#include "../repo/plugin_src/tekken_combo_macro/source/main.c"
#include "../repo/plugin_src/tekken_combo_macro/source/font8x8_basic.h"
// v2.14 host tests: flicker fix — fast copy == old copy on every layout/format, bounds, bottom placement,
// scan-out timing model, opaque canvas, timing footer, PAD-counter redraw only on the Game speed row.
#define L3 0x2
#define R3 0x4
#define OPT 0x8
#define UP 0x10
#define DOWN 0x40
#define SQ 0x8000
#define TRI 0x1000
#define X 0x4000
#define O 0x2000
#define RIGHT 0x20
#define LEFT 0x80
#define DIR "/tmp/tkcm_test/GoldHEN/combo_macro"
static OrbisPadData out;
static int checks;
#define CHECK(c) do{ checks++; if(!(c)){ printf("FAIL line %d: %s\n",__LINE__,#c); exit(1);} }while(0)
static uint32_t frame(uint32_t b){ real_btn=b; scePadReadState_hook(real_handle,&out); g_host_now_us+=16000; return out.buttons; }   // + the game's own frame work
static void frames(uint32_t b,int n){ for(int i=0;i<n;i++) frame(b); }
// one buffered read call returning k samples; returns the buttons of every sample
static void read_call(uint32_t b,int k,uint32_t *got){ real_btn=b; read_k=k; OrbisPadData arr[64]; int r=scePadRead_hook(real_handle,arr,64); g_host_now_us+=16000; for(int i=0;i<r;i++) if(got) got[i]=arr[i].buttons; read_k=1; }
static void press(uint32_t b){ frame(b); frame(0); }
static void menu_open(void){ frame(L3); frame(L3|OPT); frame(0); CHECK(g_menu.open); }
static void menu_close(void){ press(O); CHECK(!g_menu.open); }
static void go_row(int row){ while(g_menu.selected!=row) press(DOWN); }
static int file_exists(const char*p){ struct stat st; return stat(p,&st)==0; }
static long file_size(const char*p){ struct stat st; return stat(p,&st)==0? (long)st.st_size : -1; }
static int file_same(const char*a,const char*b){ FILE*x=fopen(a,"rb"),*y=fopen(b,"rb"); if(!x||!y){ if(x)fclose(x); if(y)fclose(y); return 0;} int same=1,c,d; do{ c=fgetc(x); d=fgetc(y); if(c!=d){same=0;break;} }while(c!=EOF); fclose(x); fclose(y); return same; }
static void put(const char*p,const char*s){ FILE*f=fopen(p,"wb"); fputs(s,f); fclose(f); }
static void reload(void){ plugin_unload(0,0); g_menu_enabled=0; CHECK(plugin_load(0,0)==0); }

#include "../repo/plugin_src/tekken_combo_macro/source/ov_fast.c"
#include <time.h>
static uint32_t rng=12345; static uint32_t rnd(void){ rng=rng*1103515245u+12345u; return rng>>8; }
static const uint32_t FMTS[5]={OV_FMT_A8R8G8B8_SRGB,OV_FMT_A8B8G8R8_SRGB,OV_FMT_A2R10G10B10,OV_FMT_A2R10G10B10_SRGB,OV_FMT_A2R10G10B10_PQ};
// 1125-line 60 Hz timing (1080p CEA: 45 blanking lines, 1080 active); the flip lands at the start of
// vertical blanking, so screen row r (scaled to 1080 lines) leaves the console at (45 + r) / 1125 frame.
static double scan_ms(uint32_t row, uint32_t height){ double r=(double)row*1080.0/height; return (45.0+r)/1125.0*(1000.0/59.94); }
static double now_ms(void){ struct timespec t; clock_gettime(CLOCK_MONOTONIC,&t); return t.tv_sec*1e3+t.tv_nsec/1e6; }
static void fill_view(OvMenuView *v){ g_menu.selected=ITEM_SLOT; g_slot_len[3]=95; g_slot_len[6]=40; g_menu.slot=3; g_menu.health[0]=HEALTH_DMG80; menu_view_fill(v,"Pro A"); }
// compares ov_blit_fast with ov_blit on one buffer
static void cmp_blit(int layout,uint32_t fmt,uint32_t W,uint32_t Hh,uint32_t pitch,const OvGeom *g,const uint8_t *cv,uint64_t size_limit){
  uint64_t surf=ov_surface_bytes(layout,pitch,Hh); uint64_t size=size_limit&&size_limit<surf?size_limit:surf;
  size_t alloc=(size_t)surf+4096;
  uint8_t *a=malloc(alloc),*b=malloc(alloc);
  for(size_t i=0;i<alloc;i++) a[i]=b[i]=(uint8_t)(i*7+3);
  uint32_t na=ov_blit(a,size,layout,pitch,fmt,cv,g), nb=ovf_blit(b,size,layout,pitch,fmt,cv,g);
  CHECK(na==nb); CHECK(memcmp(a,b,alloc)==0);
  for(size_t i=size;i<alloc;i++) if(b[i]!=(uint8_t)(i*7+3)){ CHECK(0); break; }   // nothing past size
  free(a); free(b);
}
int main(){ setvbuf(stdout,0,_IONBF,0);
  system("rm -rf /tmp/tkcm_test; mkdir -p " DIR);
  fake_len=CAVE_OFF+0x1000; fake_mem=calloc(1,fake_len); memcpy(fake_mem+SITE_OFF,SITE_ORIG,7);
  CHECK(plugin_load(0,0)==0); CHECK(g_menu_enabled); CHECK(g_pluginVersion==0x218);
  CHECK(strstr(all_notify,"Tekken Combo + Mod Menu ON (v2.18)"));

  const uint32_t RES[4][2]={{1280,720},{1920,1080},{2560,1440},{3840,2160}};
  printf("F1) bottom placement: same size as v2.13, on the 8x8 grid, inside the screen, panel top below 60%%\n");
  for(int r=0;r<4;r++){ OvGeom a,b; CHECK(ov_geom_strip(&a,RES[r][0],RES[r][1],ITEM_COUNT,1)); CHECK(ov_geom_bottom(&b,RES[r][0],RES[r][1],ITEM_COUNT,1));
    CHECK(b.scale==a.scale && b.foot_scale==a.foot_scale && b.w==a.w && b.h>=a.h && b.h-a.h<8);
    CHECK(b.x%8==0 && b.y%8==0 && b.h%8==0 && b.w%8==0);
    CHECK(b.x+b.w<=RES[r][0] && b.y+b.h<=RES[r][1]); CHECK(RES[r][1]-(b.y+b.h)>=RES[r][1]/18-8);
    CHECK(b.y*100>=RES[r][1]*60);
    OvGeom c; ov_geom_strip(&c,RES[r][0],RES[r][1],3,0);   // v2.12 panel (3 rows, centred)
    printf("   %ux%u: panel %ux%u  v2.12 top row %u (scan-out reaches it %.1f ms after the flip), v2.13 %u (%.1f ms), v2.14 %u (%.1f ms)\n",
      RES[r][0],RES[r][1],b.w,b.h,c.y,scan_ms(c.y,RES[r][1]),a.y,scan_ms(a.y,RES[r][1]),b.y,scan_ms(b.y,RES[r][1]));
    CHECK(scan_ms(b.y,RES[r][1])>10.0 && scan_ms(a.y,RES[r][1])<scan_ms(c.y,RES[r][1])); }

  printf("F2) opaque canvas: every pixel written (no transparent pixel), rows identical to the see-through one\n");
  { OvMenuView v; fill_view(&v);
    for(int r=0;r<4;r++){ OvGeom g; ov_geom_bottom(&g,RES[r][0],RES[r][1],ITEM_COUNT,1);
      uint8_t *o=malloc(g.w*g.h),*s=malloc(g.w*g.h); ovf_render(o,&g,&v,font8x8_basic,1); ov_render_menu(s,&g,&v,font8x8_basic);
      size_t zeros=0,diff=0; for(size_t i=0;i<(size_t)g.w*g.h;i++){ if(!o[i]) zeros++; if(s[i]&&s[i]!=o[i]) diff++; if(!s[i]&&o[i]!=PAL_BG) diff++; }
      CHECK(zeros==0); CHECK(diff==0); free(o); free(s); } }

  printf("F3) fast copy == v2.13 copy, byte for byte, on all 4 layouts x 5 formats x 4 resolutions x 4 canvases\n");
  { OvMenuView v; fill_view(&v); int cases=0;
    for(int r=0;r<4;r++) for(int lay=0;lay<OV_LAYOUT_COUNT;lay++) for(int f=0;f<5;f++) for(int kind=0;kind<4;kind++){
      const uint32_t W=RES[r][0],Hh=RES[r][1]; uint32_t pitch=lay==OV_LAYOUT_LINEAR? W : (W+127)/128*128;
      OvGeom g; if(kind<2) ov_geom_bottom(&g,W,Hh,ITEM_COUNT,1); else ov_geom_strip(&g,W,Hh,ITEM_COUNT,1);   // aligned + v2.13's unaligned
      uint8_t *cv=malloc(g.w*g.h);
      if(kind==0) ovf_render(cv,&g,&v,font8x8_basic,1);
      else if(kind==1) ov_render_menu(cv,&g,&v,font8x8_basic);
      else if(kind==2) ovf_render(cv,&g,&v,font8x8_basic,1);
      else for(size_t i=0;i<(size_t)g.w*g.h;i++) cv[i]=(rnd()%5==0)?0:(uint8_t)(1+rnd()%(PAL_COUNT-1));
      cmp_blit(lay,FMTS[f],W,Hh,pitch,&g,cv,0); cases++;
      if(f==0 && (r==1||r==3)) { uint64_t surf=ov_surface_bytes(lay,pitch,Hh);   // truncated mappings: stores stop at size
        cmp_blit(lay,FMTS[f],W,Hh,pitch,&g,cv,surf/2+12345); cmp_blit(lay,FMTS[f],W,Hh,pitch,&g,cv,(uint64_t)g.y*pitch*4+777); cases+=2; }
      free(cv); }
    printf("   %d buffer comparisons identical\n",cases); }

  printf("F4) odd geometry: panels off the 8x8 grid and partly outside a tiny buffer\n");
  { int cases=0; for(int it=0;it<300;it++){ int lay=rnd()%OV_LAYOUT_COUNT; uint32_t W=64+rnd()%700, Hh=64+rnd()%500;
      uint32_t pitch=lay==OV_LAYOUT_LINEAR? W+rnd()%40 : (W+127)/128*128;
      OvGeom g; memset(&g,0,sizeof g); g.w=1+rnd()%200; g.h=1+rnd()%120; g.x=rnd()%W; g.y=rnd()%Hh; if(g.x+g.w>W) g.w=W-g.x; if(g.y+g.h>Hh) g.h=Hh-g.y;
      uint8_t *cv=malloc(g.w*g.h); for(size_t i=0;i<(size_t)g.w*g.h;i++) cv[i]=(rnd()%3==0)?0:(uint8_t)(1+rnd()%(PAL_COUNT-1));
      if(it%3==0) for(size_t i=0;i<(size_t)g.w*g.h;i++) if(!cv[i]) cv[i]=PAL_BG;
      cmp_blit(lay,FMTS[rnd()%5],W,Hh,pitch,&g,cv,(it%4==0)? 1+rnd()%((uint32_t)ov_surface_bytes(lay,pitch,Hh)) : 0); cases++; free(cv); }
    printf("   %d random cases identical\n",cases); }

  printf("F5) whole micro tiles: with the opaque bottom panel every tile is one 256-byte run\n");
  { OvMenuView v; fill_view(&v); OvGeom g; ov_geom_bottom(&g,1920,1080,ITEM_COUNT,1); uint8_t *cv=malloc(g.w*g.h); ovf_render(cv,&g,&v,font8x8_basic,1);
    uint64_t surf=ov_surface_bytes(OV_LAYOUT_PRO_A,1920,1080); uint8_t *b=calloc(1,surf);
    uint32_t n=ovf_blit(b,surf,OV_LAYOUT_PRO_A,1920,OV_FMT_A8R8G8B8_SRGB,cv,&g); CHECK(n==g.w*g.h);
    size_t tiles=0,full=0; for(uint32_t ty=g.y;ty<g.y+g.h;ty+=8) for(uint32_t tx=g.x;tx<g.x+g.w;tx+=8){ tiles++; uint64_t base=ov_microtile_base(OV_LAYOUT_PRO_A,tx,ty,1920); int ok=1; for(int k=0;k<256;k+=4) if(!(b[base+k+3])) ok=0; full+=ok; }
    CHECK(tiles==full); printf("   %zu of %zu micro tiles written whole\n",full,tiles);
    // every pixel of the panel holds its canvas colour (independent per-pixel address)
    uint32_t pal[PAL_COUNT]; for(int i=0;i<PAL_COUNT;i++) pal[i]=ov_pack(OV_FMT_A8R8G8B8_SRGB,OV_PAL_RGB[i][0],OV_PAL_RGB[i][1],OV_PAL_RGB[i][2]);
    size_t bad=0; for(uint32_t y=0;y<g.h;y++) for(uint32_t x=0;x<g.w;x++){ uint32_t p; memcpy(&p,b+ov_pixel_offset(OV_LAYOUT_PRO_A,g.x+x,g.y+y,1920),4); if(p!=pal[cv[y*g.w+x]]) bad++; }
    CHECK(bad==0); free(b); free(cv); }

  printf("F6) speed on this computer (not the PS4): v2.13 copy as the plugin built it (-O0) vs v2.14 (-O2, whole tiles)\n");
  { extern double bench_old(int layout,uint32_t W,uint32_t Hh,const uint8_t*cv,const OvGeom*g,int reps);
    OvMenuView v; fill_view(&v);
    for(int r=1;r<4;r+=2){ const uint32_t W=RES[r][0],Hh=RES[r][1];
      OvGeom go; ov_geom_strip(&go,W,Hh,ITEM_COUNT,1); uint8_t *cvo=malloc(go.w*go.h); ov_render_menu(cvo,&go,&v,font8x8_basic);
      OvGeom gn; ov_geom_bottom(&gn,W,Hh,ITEM_COUNT,1); uint8_t *cvn=malloc(gn.w*gn.h); ovf_render(cvn,&gn,&v,font8x8_basic,1);
      double old_ms=bench_old(OV_LAYOUT_PRO_A,W,Hh,cvo,&go,20);
      uint64_t surf=ov_surface_bytes(OV_LAYOUT_PRO_A,W,Hh); uint8_t *b=calloc(1,surf);
      double t0=now_ms(); for(int k=0;k<20;k++) ovf_blit(b,surf,OV_LAYOUT_PRO_A,W,OV_FMT_A8R8G8B8_SRGB,cvn,&gn); double new_ms=(now_ms()-t0)/20;
      t0=now_ms(); for(int k=0;k<5;k++) ovf_render(cvn,&gn,&v,font8x8_basic,1); double rend_ms=(now_ms()-t0)/5;
      printf("   %ux%u Pro A: v2.13 copy %.2f ms, v2.14 copy %.2f ms (%.1fx faster, and writes every pixel), v2.14 re-render %.2f ms\n",W,Hh,old_ms,new_ms,old_ms/new_ms,rend_ms);
      CHECK(new_ms<old_ms); free(b); free(cvo); free(cvn); } }

  printf("F7) Overlay row footer shows the draw timing; other rows unchanged; fits the panel\n");
  { reload(); menu_open(); go_row(ITEM_OVERLAY); OvMenuView v; menu_view_fill(&v,"Pro A"); CHECK(!strcmp(v.footer,"D-PAD SELECT/CHANGE   O CLOSE"));
    snprintf(g_ov_timing,sizeof g_ov_timing,"MENU READY 10.9MS AFTER FLIP (MAX 99.9)"); menu_view_fill(&v,"Pro A"); CHECK(v.footer==g_ov_timing);
    for(int r=0;r<4;r++){ OvGeom g; ov_geom_bottom(&g,RES[r][0],RES[r][1],ITEM_COUNT,1); CHECK(strlen(g_ov_timing)*8*g.foot_scale<=g.w-16*g.scale); }
    go_row(ITEM_SLOT); menu_view_fill(&v,"Pro A"); CHECK(!strcmp(v.footer,"L3+R3 REC  R3/L3 PLAY  SQUARE CLEAR"));
    g_ov_timing[0]=0; menu_close(); }

  printf("F8) PAD n/S counter redraws the menu only while Game speed is selected (v2.13: on any row)\n");
  { reload(); menu_open(); go_row(ITEM_P1_HEALTH);
    uint32_t r0=g_pacer.rate, g0=g_view_gen; for(int i=0;i<300;i++){ frame(0); if(i>=150) g_host_now_us+=6000; } CHECK(g_pacer.rate!=r0); CHECK(g_view_gen==g0);
    go_row(ITEM_SPEED); r0=g_pacer.rate; g0=g_view_gen;
    for(int i=0;i<300;i++) frame(0);   // back to 16 ms frames: the rate changes again
    CHECK(g_pacer.rate!=r0); CHECK(g_view_gen>g0);
    CHECK(g_host_sleeps==0); menu_close(); }

  printf("F9) preview canvas (plugin's own view + opaque renderer, bottom-left at 1080p)\n");
  { reload(); g_slot_len[3]=95; g_slot_presses[3]=14; g_slot_len[6]=40; g_slot_presses[6]=6; g_menu.health[0]=HEALTH_DMG80; g_menu.ovl=OVL_PRO_A; g_menu.slot=3;
    menu_open(); go_row(ITEM_OVERLAY); snprintf(g_ov_timing,sizeof g_ov_timing,"MENU READY 0.9MS AFTER FLIP (MAX 1.3)");
    OvGeom g; ov_geom_bottom(&g,1920,1080,ITEM_COUNT,1); uint8_t *cv=malloc(g.w*g.h); OvMenuView v; menu_view_fill(&v,"Pro A"); ovf_render(cv,&g,&v,font8x8_basic,1);
    FILE*f=fopen("/tmp/tk_preview_v214.bin","wb"); fwrite(&g.w,4,1,f); fwrite(&g.h,4,1,f); fwrite(&g.x,4,1,f); fwrite(&g.y,4,1,f); fwrite(cv,1,g.w*g.h,f); fclose(f); free(cv);
    g_ov_timing[0]=0; menu_close(); }
  printf("ALL v2.14 TESTS PASSED (%d checks)\n",checks);
  return 0; }
