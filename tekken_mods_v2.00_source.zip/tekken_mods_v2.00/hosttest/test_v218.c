
#define TK_HOST_TEST 1
#include <fcntl.h>
#include <unistd.h>
#include <sys/stat.h>
#include <assert.h>
#include "plugin_common.h"
#include "Common.h"
#include "orbis/Pad.h"
char last_notify[512]; int notify_count; char all_notify[16384];
void NotifyStatic(const char* i, const char *t){ snprintf(last_notify,512,"%s",t); notify_count++; if(strlen(all_notify)+strlen(t)+2>=sizeof(all_notify)) all_notify[0]=0; /* harness: keep the buffer in bounds */ strcat(all_notify,t); strcat(all_notify,"|"); printf("  [NOTIFY] %s\n", t); }
void Notify(const char* i, const char *f, ...){ char b[512]; va_list a; va_start(a,f); vsnprintf(b,512,f,a); va_end(a); NotifyStatic(i,b);}
int sceKernelOpen(const char*p,int f,int m){ int ff=0; if(f&1) ff|=O_WRONLY; if(f&0x200) ff|=O_CREAT; if(f&0x400) ff|=O_TRUNC; return open(p,ff,m);}
ssize_t sceKernelWrite(int fd,const void*b,size_t n){return write(fd,b,n);} ssize_t sceKernelRead(int fd,void*b,size_t n){return read(fd,b,n);}
int sceKernelClose(int fd){return close(fd);} int sceKernelMkdir(const char*p,int m){return mkdir(p,m);}
int sceKernelRename(const char*a,const char*b){return rename(a,b);} int sceKernelUnlink(const char*p){return unlink(p);}
const char* sceKernelGetFsSandboxRandomWord(void){return "abc";} int sys_dynlib_load_prx(const char*p, int*h){return 0;}
int scePadRead(int h, OrbisPadData* d, int n){return 0;} int scePadReadState(int h, OrbisPadData* d){return 0;}
// fake eboot memory for the health cave
static unsigned char *fake_mem; static size_t fake_len;
#include "../repo/plugin_src/tekken_combo_macro/source/health_bytes.h"
int sys_sdk_proc_info(struct proc_info *pi){ memset(pi,0,sizeof(*pi));
#ifdef WRONG_TITLE
  strcpy(pi->titleid,"CUSA05972"); strcpy(pi->version,"01.00");
#else
  strcpy(pi->titleid,"CUSA06014"); strcpy(pi->version,"05.10");
#endif
  pi->base_address=(uint64_t)fake_mem; return 0; }
static int mapped(uint64_t at,size_t len,int w){ (void)w; return at>=(uint64_t)fake_mem && at+len<=(uint64_t)fake_mem+fake_len; }
static int kwrite_count;
static int kwrite(uint64_t at,const void*src,size_t n){ if(!mapped(at,n,1)) return 0; memcpy((void*)at,src,n); kwrite_count++; return 1; }
// scripted real pad
static uint32_t real_btn; static uint8_t real_lx=0x80; static uint64_t ts; static int real_handle;
int scePadReadStateExt(int h, OrbisPadData* d){ memset(d,0,sizeof(*d)); d->buttons=real_btn; d->leftStick.x=real_lx; d->leftStick.y=0x80; d->rightStick.x=d->rightStick.y=0x80; d->timestamp=(ts+=16667); d->touch.fingers=(real_btn&0x100000)?1:0; return 0; }
int scePadReadExt(int h, OrbisPadData* d, int n){ scePadReadStateExt(h,d); return 1; }
#include "../repo/plugin_src/tekken_combo_macro/source/main.c"
// v2.17 host tests (v1.09): slot 10 fixed combo (seed, file, decode, playback), slots 1-9 untouched, menu 1..10.
#define CHK(x) do { if(!(x)) { printf("FAIL line %d: %s\n", __LINE__, #x); exit(1); } } while(0)
#define SLOT10 "/tmp/tkcm_test/GoldHEN/combo_macro/slot10.bin"
static int file_size(const char *p){ struct stat st; if(stat(p,&st)!=0) return -1; return (int)st.st_size; }
static int file_exists2(const char *p){ return file_size(p)>=0; }
static unsigned char *slurp_file(const char *p, size_t *n){ FILE *f=fopen(p,"rb"); if(!f) return 0; fseek(f,0,SEEK_END); *n=ftell(f); fseek(f,0,SEEK_SET); unsigned char *b=malloc(*n+1); fread(b,1,*n,f); fclose(f); return b; }
static void menu_key(uint32_t btn){ static MenuPad mp; menu_step(&g_menu, &mp, 1, btn); }

#define SLOTDIR "/tmp/tkcm_test/GoldHEN/combo_macro/"
static char pth[160];
static const char *slotp(int i){ snprintf(pth,sizeof pth,SLOTDIR "slot%d.bin",i); return pth; }
static void pad_key(uint32_t btn){ OrbisPadData d; memset(&d,0,sizeof d); d.buttons=btn; d.leftStick.x=d.leftStick.y=d.rightStick.x=d.rightStick.y=0x80; process_sample(1,&d,0); }
static void tap(uint32_t btn){ pad_key(btn); pad_key(0); }
static int same_bytes(const char *p, unsigned char *ref, size_t n){ size_t m=0; unsigned char *b=slurp_file(p,&m); int ok=b && m==n && (n==0 || memcmp(b,ref,n)==0); free(b); return ok; }
static void to_in(int k){ for(int i=0;i<60;i++) tap(MB_UP); for(int i=0;i<g_menu.mk_n+k;i++) tap(MB_DOWN); }
static int tv(uint32_t i){ return (int)((uint64_t)i*1000000u/60u); }


#include "../repo/plugin_src/tekken_combo_macro/source/ov_fast.c"
#include "../repo/plugin_src/tekken_combo_macro/source/font8x8_basic.h"
// v2.18 host tests: the one-screen combo builder (step = direction and/or button, gap in hundredths,
// list scroll, add / delete / save / cancel, the 40-step cap, render geometry). Plugin pad path throughout.
#define SLOTDIR18 "/tmp/tkcm_test/GoldHEN/combo_macro/"
static void to_in18(int k){ for(int i=0;i<60;i++) tap(MB_UP); for(int i=0;i<g_menu.mk_n+k;i++) tap(MB_DOWN); }
static int ascii_only(const char *s){ for(; *s; s++) if((unsigned char)*s >= 128) return 0; return 1; }
static char pth18[160];
static const char *slotp18(int i){ snprintf(pth18,sizeof pth18,SLOTDIR18 "slot%d.bin",i); return pth18; }

int main(void){ setvbuf(stdout,0,_IONBF,0);
  system("rm -rf /tmp/tkcm_test; mkdir -p /tmp/tkcm_test");
  fake_len=CAVE_OFF+0x1000; fake_mem=calloc(1,fake_len); memcpy(fake_mem+SITE_OFF,SITE_ORIG,7);
  static MacroStep w[MAX_STEPS]; static CePress pr[ED_MAX_PRESSES];

  CHK(plugin_load(0,0)==0); CHK(g_menu_enabled);
  printf("B1) names: every direction and button choice, plain words, no arrow glyphs\n");
  char nm[64];
  ce_step_name(nm,sizeof nm,0x4030u); CHK(!strcmp(nm,"Up+Right + X"));
  ce_step_name(nm,sizeof nm,0x0010u); CHK(!strcmp(nm,"Up"));
  ce_step_name(nm,sizeof nm,0x4000u); CHK(!strcmp(nm,"X"));
  ce_step_name(nm,sizeof nm,0x00C0u|0x1000u); CHK(!strcmp(nm,"Down+Left + Triangle"));
  ce_step_name(nm,sizeof nm,0x0060u|0x2000u); CHK(!strcmp(nm,"Down+Right + Circle"));
  ce_step_name(nm,sizeof nm,0x0800u); CHK(!strcmp(nm,"R1"));
  for(int d=0; d<(int)CE_DIR_OPTS; d++) for(int b=0; b<(int)CE_BTN_OPTS; b++){
    if(!d && !b) continue;
    ce_step_name(nm,sizeof nm,CE_DIR_MASK[d]|CE_BTN_BITS[b]); CHK(nm[0] && ascii_only(nm)); CHK(!strstr(nm,"?")); }
  CHK(!strcmp(CE_DIR_NAME[2],"Up+Right") && !strcmp(CE_BTN_NAME[3],"Square") && CE_DIR_OPTS==9 && CE_BTN_OPTS==7);

  printf("B2) a step with a direction and a button: buttons = direction bits OR button bit; decodes back (all 62 combinations)\n");
  for(int d=0; d<(int)CE_DIR_OPTS; d++) for(int b=0; b<(int)CE_BTN_OPTS; b++){
    if(!d && !b) continue;
    const uint32_t want = CE_DIR_MASK[d] | CE_BTN_BITS[b];
    MkPress one[1] = {{want, 20}};
    uint32_t n = ce_make_build(one,1,w); CHK(n==12);
    for(uint32_t i=0;i<n;i++) CHK(w[i].buttons == (i < 3 ? want : 0));
    CHK(ce_parse(w,n,pr,ED_MAX_PRESSES)==1 && pr[0].buttons==want && pr[0].start==0 && pr[0].hold==3);
    CHK((pr[0].buttons & 0x00F0u) == CE_DIR_MASK[d] && (pr[0].buttons & ~0x00F0u & CE_BTN_MASK) == CE_BTN_BITS[b]);
  }
  CHK(CE_DIR_MASK[2]==0x0030u && CE_BTN_BITS[1]==0x4000u);   // Up+Right + X = 0x4030

  printf("B3) builder on the pad: Up+Right + X, Circle, Square; gap edit on one step; save to slot 5\n");
  pad_key(MB_L3); pad_key(MB_L3|MB_OPTIONS); pad_key(0);
  CHK(g_menu.open && g_menu.page==PG_MAIN);
  g_menu.selected=ITEM_SLOT; g_menu.slot=4;
  tap(MB_TRIANGLE); CHK(g_menu.page==PG_TOOLS);
  tap(MB_DOWN); tap(MB_CROSS); CHK(g_menu.page==PG_MAKE && g_menu.mk_n==0 && g_menu.sub==0 && g_menu.mk_gap==20);
  tap(MB_RIGHT); tap(MB_RIGHT); CHK(CE_DIR_MASK[g_menu.mk_dir]==0x0030u);
  tap(MB_DOWN); tap(MB_RIGHT); CHK(CE_BTN_BITS[g_menu.mk_btn]==0x4000u);
  tap(MB_CROSS); CHK(g_menu.mk_n==1 && g_menu.mk[0].buttons==0x4030u && g_menu.mk[0].cs==20 && g_menu.sub==2);
  tap(MB_RIGHT); CHK(CE_BTN_BITS[g_menu.mk_btn]==0x2000u);           // Circle, direction still Up+Right
  tap(MB_CROSS); CHK(g_menu.mk_n==2 && g_menu.mk[1].buttons==(0x0030u|0x2000u) && g_menu.sub==3);
  tap(MB_RIGHT); CHK(CE_BTN_BITS[g_menu.mk_btn]==0x8000u);
  to_in18(1); CHK(g_menu.sub==g_menu.mk_n+1);                         // Button row
  tap(MB_CROSS); CHK(g_menu.mk_n==3 && g_menu.mk[2].buttons==(0x0030u|0x8000u) && g_menu.mk[2].cs==20);
  // gap edit: only step 2 (Circle) changes; the steps after it move
  to_in18(-2); CHK(g_menu.sub==1);
  for(int i=0;i<5;i++) tap(MB_RIGHT);
  CHK(g_menu.mk[1].cs==25 && g_menu.mk[0].cs==20 && g_menu.mk[2].cs==20);
  for(int i=0;i<5;i++) tap(MB_LEFT);
  CHK(g_menu.mk[1].cs==20);
  for(int i=0;i<5;i++) tap(MB_RIGHT);                                  // keep 0.25 s for the check below
  CHK(g_menu.mk_n==3 && g_menu.mk[0].buttons==0x4030u && g_menu.mk[1].buttons==(0x0030u|0x2000u) && g_menu.mk[2].buttons==(0x0030u|0x8000u));
  uint32_t n3 = ce_make_build(g_menu.mk, g_menu.mk_n, w);
  CHK(n3==12+15+12);                                                   // 0.20 s, 0.25 s (15 frames), 0.20 s
  CHK(ce_parse(w,n3,pr,ED_MAX_PRESSES)==3);
  CHK(pr[0].start==0 && pr[1].start==12 && pr[2].start==27);
  CHK(pr[0].buttons==0x4030u && pr[1].buttons==(0x0030u|0x2000u) && pr[2].buttons==(0x0030u|0x8000u));
  CHK(ce_gap_frames(pr,3,n3,0)==12 && ce_gap_frames(pr,3,n3,1)==15 && ce_gap_frames(pr,3,n3,2)==12);
  CHK(w[27].t_us==450000u && w[12].t_us==200000u);                    // following press at 27/60 s
  for(uint32_t i=0;i<n3;i++) CHK(w[i].t_us==(uint32_t)((uint64_t)i*1000000u/60u));
  // gap 0.25 s back to 0.25: the step's gap is 15 frames
  CHK(ce_cs_frames(25)==15 && ce_cs_frames(20)==12);

  printf("B4) save: Save row, slot 5 (X picks the slot, X writes); the file decodes back to the same steps\n");
  to_in18(4); CHK(g_menu.sub==g_menu.mk_n+4);
  tap(MB_CROSS); CHK(g_menu.page==PG_MAKE_SLOT && g_menu.mk_slot==4);
  all_notify[0]=0; tap(MB_DOWN); tap(MB_CROSS);
  CHK(g_menu.page==PG_TOOLS && g_menu.mk_n==0 && g_menu.slot==4);
  CHK(strstr(all_notify,"Combo saved to slot 5"));
  CHK(file_size(slotp18(5))==32+16*39);
  { size_t m; unsigned char *b=slurp_file(slotp18(5),&m); MacroHeader h; memcpy(&h,b,sizeof h);
    CHK(h.magic==0x4D434B54u && h.version==1 && h.count==39 && h.step_size==16 && h.presses==3); free(b); }
  { uint32_t np=0; uint32_t ns=slot_read(4,w,&np); CHK(ns==39 && np==3);
    CHK(ce_parse(w,ns,pr,ED_MAX_PRESSES)==3 && pr[0].buttons==0x4030u && pr[1].buttons==(0x0030u|0x2000u) && pr[2].buttons==(0x0030u|0x8000u));
    CHK(pr[0].start==0 && pr[1].start==12 && pr[2].start==27 && pr[0].hold==3 && pr[1].hold==3 && pr[2].hold==3); }
  CHK(g_slot_len[4]==39 && g_slot_presses[4]==3);
  for(int i=1;i<=9;i++) if(i!=5) CHK(file_size(slotp18(i))<0);
  CHK(file_size(slotp18(10))==32+16*150);

  printf("B5) empty Save and the 40-step cap give plain notices; delete moves the cursor; cancel writes nothing\n");
  tap(MB_CROSS); CHK(g_menu.page==PG_MAKE && g_menu.mk_n==0);
  all_notify[0]=0; to_in18(4); tap(MB_CROSS); CHK(g_menu.page==PG_MAKE && strstr(all_notify,"Add a step first"));
  to_in18(1); tap(MB_RIGHT);                                           // Button = X
  for(int i=0;i<40;i++) tap(MB_CROSS);
  CHK(g_menu.mk_n==40 && g_menu.sub==41);
  all_notify[0]=0; tap(MB_CROSS); CHK(g_menu.mk_n==40 && strstr(all_notify,"40 steps is the most"));
  to_in18(-1); CHK(g_menu.sub==39);
  tap(MB_TRIANGLE); CHK(g_menu.mk_n==39 && g_menu.sub==38);
  tap(MB_TRIANGLE); CHK(g_menu.mk_n==38 && g_menu.sub==37);
  size_t m5=0; unsigned char *b5=slurp_file(slotp18(5),&m5);
  all_notify[0]=0; tap(MB_CIRCLE); CHK(g_menu.page==PG_TOOLS && g_menu.mk_n==0 && g_menu.sub==1);
  CHK(strstr(all_notify,"Combo maker cancelled") && strstr(all_notify,"Nothing was written"));
  CHK(same_bytes(slotp18(5),b5,m5)); free(b5);
  for(int i=1;i<=9;i++) if(i!=5) CHK(file_size(slotp18(i))<0);

  printf("B6) the builder view: title count, 8 scrolled step rows, 5 input rows, plain words, footer\n");
  tap(MB_CROSS); CHK(g_menu.page==PG_MAKE && g_menu.mk_n==0);         // a fresh builder
  tap(MB_DOWN); tap(MB_RIGHT); CHK(CE_BTN_BITS[g_menu.mk_btn]==0x4000u);
  for(int i=0;i<12;i++) tap(MB_CROSS);
  CHK(g_menu.mk_n==12 && g_menu.sub==13 && g_menu.mk_top==4);
  { OvMenuView v; menu_view_fill(&v,"x");
    CHK(v.rows==CE_MAKE_ROWS && v.plain_rows==(int)CE_MAKE_VIS && v.strip==0);
    CHK(!strcmp(v.title,"BUILD A COMBO  12 STEPS"));
    CHK(!strcmp(v.label[0]," 5 X") && !strcmp(v.label[7],"12 X") && !strcmp(v.value[7],"0.20s"));
    CHK(!strcmp(v.label[8],"Direction") && !strcmp(v.label[9],"Button") && !strcmp(v.value[9],"X"));
    CHK(!strcmp(v.label[10],"Gap after it") && !strcmp(v.value[10],"0.20s") && !strcmp(v.label[11],"Add step"));
    CHK(!strcmp(v.label[12],"Save") && !strcmp(v.value[12],"X, choose a slot"));
    CHK(v.selected==9);                                                 // Button row, under the list
    CHK(strstr(v.footer,"X ADD") && strstr(v.footer,"TRI DELETE"));
    for(int r=0;r<v.rows;r++){ CHK(ascii_only(v.label[r]?v.label[r]:"")); CHK(ascii_only(v.value[r]?v.value[r]:"")); }
    CHK(ascii_only(v.title) && ascii_only(v.footer)); }
  to_in18(-12); CHK(g_menu.sub==0 && g_menu.mk_top==0);               // first step: the window goes back to the top
  { OvMenuView v; menu_view_fill(&v,"x"); CHK(!strcmp(v.label[0]," 1 X") && v.selected==0); }
  for(int i=0;i<11;i++) tap(MB_DOWN);                                   // step 12 is under the cursor: window scrolls
  CHK(g_menu.sub==11 && g_menu.mk_top==4);
  { OvMenuView v; menu_view_fill(&v,"x"); CHK(!strcmp(v.label[7],"12 X") && v.selected==7); }
  to_in18(0); tap(MB_UP); CHK(g_menu.sub==g_menu.mk_n-1);             // up from Direction lands on the last step
  { OvMenuView v; menu_view_fill(&v,"x"); CHK(v.selected==7 && g_menu.mk_top==4); }

  printf("B7) render: the builder panel fits 720p, 1080p and 4K; the canvas is painted\n");
  static const int RES[3][2] = {{1280,720},{1920,1080},{3840,2160}};
  for(int r=0;r<3;r++){
    OvGeom g; CHK(ov_geom_bottom_wide(&g,RES[r][0],RES[r][1],CE_MAKE_ROWS,0,120));
    CHK(g.x+g.w<=(uint32_t)RES[r][0] && g.y+g.h<=(uint32_t)RES[r][1]);
    uint8_t *cv=malloc((size_t)g.w*g.h); CHK(cv);
    OvMenuView v; menu_view_fill(&v,"x");
    ovf_render(cv,&g,&v,font8x8_basic,1);
    size_t lit=0; for(size_t i=0;i<(size_t)g.w*g.h;i++) if(cv[i]) lit++;
    CHK(lit > (size_t)g.w*g.h/4);
    free(cv);
  }
  { OvGeom gm, gb; ov_geom_bottom(&gm,1920,1080,ITEM_COUNT,1); ov_geom_bottom_wide(&gb,1920,1080,CE_MAKE_ROWS,0,120);
    CHK(gb.h > gm.h); printf("  builder panel %ux%u, main panel %ux%u (1080p)\n", gb.w, gb.h, gm.w, gm.h); }

  printf("B8) back on the pages: O from the builder's Save picks back to the builder; the main menu is unchanged\n");
  to_in18(4); tap(MB_CROSS); CHK(g_menu.page==PG_MAKE_SLOT);
  tap(MB_CIRCLE); CHK(g_menu.page==PG_MAKE && g_menu.sub==g_menu.mk_n+4);
  tap(MB_CIRCLE); CHK(g_menu.page==PG_TOOLS && g_menu.mk_n==0);
  tap(MB_CIRCLE); CHK(g_menu.page==PG_MAIN && g_menu.open);
  CHK(g_menu.selected==ITEM_SLOT && g_menu.slot==4);
  { OvMenuView v; menu_view_fill(&v,"x"); CHK(v.rows==ITEM_COUNT && v.plain_rows==0 && v.strip==1); }
  CHK(file_size(slotp18(5))==32+16*39);

  printf("ALL v2.18 TESTS PASSED (names, direction+button encoding x62, gap edit, save and decode, cap, delete, cancel, scroll, render, slots 1-9)\n");
  return 0;
}
