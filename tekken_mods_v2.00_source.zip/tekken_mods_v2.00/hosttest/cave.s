entry:
  jmp code
pct: .byte 80, 60, 50, 105, 110, 120, 150, 200
code:
  add rsp, -0x80
  push rcx
  push rdx
  lea rdx, [rip + flag_p1]
  cmp dword ptr [r15+0x14a0], 1
  sbb rcx, rcx
  movzx ecx, byte ptr [rdx + rcx + 1]
  dec ecx
  jz inf
  dec ecx
  jz onehit
  cmp ecx, 9
  jae store
  movzx edx, byte ptr [rdx + rcx + 3]
  movsxd rcx, dword ptr [r15+0x14a4]
  cmp eax, ecx
  jge store
  push rax
  push rcx
  sub ecx, eax
  imul rcx, rdx
  cmp dl, 100
  jb nr
  add rcx, 50
nr:
  xchg rax, rcx
  push 100
  pop rcx
  xor edx, edx
  div rcx
  test rax, rax
  jnz ok
  inc eax
ok:
  pop rcx
  sub rcx, rax
  pop rax
  xor edx, edx
  test eax, eax
  cmovg eax, edx
  cdqe
  cmp rcx, rax
  cmovl rcx, rax
  mov eax, ecx
  jmp store
inf:
  mov eax, dword ptr [r15+0x14a8]
  jmp store
onehit:
  test eax, eax
  jz store
  mov eax, 1
store:
  pop rdx
  pop rcx
  sub rsp, -0x80
  mov dword ptr [r15+0x14a4], eax
  jmp 0x149664a
