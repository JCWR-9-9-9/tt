#pragma once
typedef struct { uint8_t x, y; } stick;
typedef struct { uint8_t l2, r2; } analog;
typedef struct { uint8_t fingers; uint8_t pad[23]; } touchdata;
typedef struct OrbisPadData { uint32_t buttons; stick leftStick; stick rightStick; analog analogButtons; uint16_t padding; float q[4]; float v[3]; float a[3]; touchdata touch; uint8_t connected; uint64_t timestamp; uint8_t ext[16]; uint8_t count; uint8_t unknown[15]; } OrbisPadData;
int scePadReadExt(int h, OrbisPadData* d, int n); int scePadReadStateExt(int h, OrbisPadData* d);
int scePadRead(int h, OrbisPadData* d, int n); int scePadReadState(int h, OrbisPadData* d);
