
#define TK_HOST_TEST 1
#include <fcntl.h>
#include <unistd.h>
#include <sys/stat.h>
#include <assert.h>
#include "plugin_common.h"
#include "Common.h"
#include "orbis/Pad.h"
char last_notify[512]; int notify_count; char all_notify[16384];
void NotifyStatic(const char* i, const char *t){ snprintf(last_notify,512,"%s",t); notify_count++; strncat(all_notify,t,sizeof(all_notify)-strlen(all_notify)-2); strcat(all_notify,"|"); printf("  [NOTIFY] %s\n", t); }
void Notify(const char* i, const char *f, ...){ char b[512]; va_list a; va_start(a,f); vsnprintf(b,512,f,a); va_end(a); NotifyStatic(i,b);}
int sceKernelOpen(const char*p,int f,int m){ int ff=0; if(f&1) ff|=O_WRONLY; if(f&0x200) ff|=O_CREAT; if(f&0x400) ff|=O_TRUNC; return open(p,ff,m);}
ssize_t sceKernelWrite(int fd,const void*b,size_t n){return write(fd,b,n);} ssize_t sceKernelRead(int fd,void*b,size_t n){return read(fd,b,n);}
int sceKernelClose(int fd){return close(fd);} int sceKernelMkdir(const char*p,int m){return mkdir(p,m);}
int sceKernelRename(const char*a,const char*b){return rename(a,b);} int sceKernelUnlink(const char*p){return unlink(p);}
const char* sceKernelGetFsSandboxRandomWord(void){return "abc";} int sys_dynlib_load_prx(const char*p, int*h){return 0;}
int scePadRead(int h, OrbisPadData* d, int n){return 0;} int scePadReadState(int h, OrbisPadData* d){return 0;}
// fake eboot memory for the health cave
static unsigned char *fake_mem; static size_t fake_len;
#include "../repo/plugin_src/tekken_combo_macro/source/health_bytes.h"
int sys_sdk_proc_info(struct proc_info *pi){ memset(pi,0,sizeof(*pi));
#ifdef WRONG_TITLE
  strcpy(pi->titleid,"CUSA05972"); strcpy(pi->version,"01.00");
#else
  strcpy(pi->titleid,"CUSA06014"); strcpy(pi->version,"05.10");
#endif
  pi->base_address=(uint64_t)fake_mem; return 0; }
static int mapped(uint64_t at,size_t len,int w){ (void)w; return at>=(uint64_t)fake_mem && at+len<=(uint64_t)fake_mem+fake_len; }
static int kwrite_count;
static int kwrite(uint64_t at,const void*src,size_t n){ if(!mapped(at,n,1)) return 0; memcpy((void*)at,src,n); kwrite_count++; return 1; }
// scripted real pad
static uint32_t real_btn; static uint8_t real_lx=0x80; static uint64_t ts; static int real_handle;
int scePadReadStateExt(int h, OrbisPadData* d){ memset(d,0,sizeof(*d)); d->buttons=real_btn; d->leftStick.x=real_lx; d->leftStick.y=0x80; d->rightStick.x=d->rightStick.y=0x80; d->timestamp=(ts+=16667); d->touch.fingers=(real_btn&0x100000)?1:0; return 0; }
int scePadReadExt(int h, OrbisPadData* d, int n){ scePadReadStateExt(h,d); return 1; }
#include "../repo/plugin_src/tekken_combo_macro/source/main.c"
// v2.17 host tests (v1.09): slot 10 fixed combo (seed, file, decode, playback), slots 1-9 untouched, menu 1..10.
#define CHK(x) do { if(!(x)) { printf("FAIL line %d: %s\n", __LINE__, #x); exit(1); } } while(0)
#define SLOT10 "/tmp/tkcm_test/GoldHEN/combo_macro/slot10.bin"
static int file_size(const char *p){ struct stat st; if(stat(p,&st)!=0) return -1; return (int)st.st_size; }
static int file_exists2(const char *p){ return file_size(p)>=0; }
static unsigned char *slurp_file(const char *p, size_t *n){ FILE *f=fopen(p,"rb"); if(!f) return 0; fseek(f,0,SEEK_END); *n=ftell(f); fseek(f,0,SEEK_SET); unsigned char *b=malloc(*n+1); fread(b,1,*n,f); fclose(f); return b; }
static void menu_key(uint32_t btn){ static MenuPad mp; menu_step(&g_menu, &mp, 1, btn); }

#define SLOTDIR "/tmp/tkcm_test/GoldHEN/combo_macro/"
static char pth[160];
static const char *slotp(int i){ snprintf(pth,sizeof pth,SLOTDIR "slot%d.bin",i); return pth; }
static void pad_key(uint32_t btn){ OrbisPadData d; memset(&d,0,sizeof d); d.buttons=btn; d.leftStick.x=d.leftStick.y=d.rightStick.x=d.rightStick.y=0x80; process_sample(1,&d,0); }
static void tap(uint32_t btn){ pad_key(btn); pad_key(0); }
static int same_bytes(const char *p, unsigned char *ref, size_t n){ size_t m=0; unsigned char *b=slurp_file(p,&m); int ok=b && m==n && (n==0 || memcmp(b,ref,n)==0); free(b); return ok; }
static int tv(uint32_t i){ return (int)((uint64_t)i*1000000u/60u); }

#include "../repo/plugin_src/tekken_combo_macro/source/font8x8_basic.h"
#define CHK(x) do { if(!(x)) { printf("FAIL line %d\n", __LINE__); exit(1);} } while(0)
static void dump(const char *name){
  OvGeom g; ov_geom_strip(&g,1920,1080,ITEM_COUNT,1);
  uint8_t *cv=calloc(1,g.w*g.h);
  OvMenuView v; menu_view_fill(&v,"Pro A");
  ov_render_menu_bg(cv,&g,&v,font8x8_basic,1);
  char p[160]; snprintf(p,sizeof p,"/tmp/prev_%s.bin",name);
  FILE *f=fopen(p,"wb"); fwrite(&g.w,4,1,f); fwrite(&g.h,4,1,f); fwrite(cv,1,g.w*g.h,f); fclose(f);
  printf("%s w=%u h=%u rows=%d sel=%d title=%s footer=%s\n",name,g.w,g.h,v.rows,v.selected,v.title,v.footer);
  free(cv);
}
int main(void){
  fake_len=CAVE_OFF+0x1000; fake_mem=calloc(1,fake_len); memcpy(fake_mem+SITE_OFF,SITE_ORIG,7);
  system("rm -rf /tmp/tkcm_test; mkdir -p /tmp/tkcm_test");
  CHK(plugin_load(0,0)==0);
  g_menu.open=1; g_menu.owner=1; g_menu.selected=ITEM_SLOT; g_menu.slot=9;
  dump("main");
  g_menu.page=PG_TOOLS; g_menu.sub=0; dump("tools");
  g_menu.page=PG_EDIT; g_menu.sub=0; g_ed_P=0;
  tap(MB_CROSS); g_menu.page=PG_TOOLS;   /* open via the real path */
  pad_key(0);
  g_menu.page=PG_TOOLS; g_menu.sub=0; tap(MB_CROSS);
  dump("edit");
  for(int i=0;i<6;i++) tap(MB_DOWN);
  dump("edit_mid");
  g_menu.page=PG_MAKE; g_menu.sub=0; g_menu.mk_n=3; g_menu.mk_btn=10; g_menu.mk_gap=20; dump("make");
  g_menu.page=PG_MAKE_SLOT; g_menu.sub=1; g_menu.mk_slot=9; dump("make_slot");
  return 0;
}
