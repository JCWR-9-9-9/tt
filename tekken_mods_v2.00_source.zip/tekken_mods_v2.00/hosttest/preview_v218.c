
#define TK_HOST_TEST 1
#include <fcntl.h>
#include <unistd.h>
#include <sys/stat.h>
#include <assert.h>
#include "plugin_common.h"
#include "Common.h"
#include "orbis/Pad.h"
char last_notify[512]; int notify_count; char all_notify[16384];
void NotifyStatic(const char* i, const char *t){ snprintf(last_notify,512,"%s",t); notify_count++; if(strlen(all_notify)+strlen(t)+2>=sizeof(all_notify)) all_notify[0]=0; /* harness: keep the buffer in bounds */ strcat(all_notify,t); strcat(all_notify,"|"); printf("  [NOTIFY] %s\n", t); }
void Notify(const char* i, const char *f, ...){ char b[512]; va_list a; va_start(a,f); vsnprintf(b,512,f,a); va_end(a); NotifyStatic(i,b);}
int sceKernelOpen(const char*p,int f,int m){ int ff=0; if(f&1) ff|=O_WRONLY; if(f&0x200) ff|=O_CREAT; if(f&0x400) ff|=O_TRUNC; return open(p,ff,m);}
ssize_t sceKernelWrite(int fd,const void*b,size_t n){return write(fd,b,n);} ssize_t sceKernelRead(int fd,void*b,size_t n){return read(fd,b,n);}
int sceKernelClose(int fd){return close(fd);} int sceKernelMkdir(const char*p,int m){return mkdir(p,m);}
int sceKernelRename(const char*a,const char*b){return rename(a,b);} int sceKernelUnlink(const char*p){return unlink(p);}
const char* sceKernelGetFsSandboxRandomWord(void){return "abc";} int sys_dynlib_load_prx(const char*p, int*h){return 0;}
int scePadRead(int h, OrbisPadData* d, int n){return 0;} int scePadReadState(int h, OrbisPadData* d){return 0;}
// fake eboot memory for the health cave
static unsigned char *fake_mem; static size_t fake_len;
#include "../repo/plugin_src/tekken_combo_macro/source/health_bytes.h"
int sys_sdk_proc_info(struct proc_info *pi){ memset(pi,0,sizeof(*pi));
#ifdef WRONG_TITLE
  strcpy(pi->titleid,"CUSA05972"); strcpy(pi->version,"01.00");
#else
  strcpy(pi->titleid,"CUSA06014"); strcpy(pi->version,"05.10");
#endif
  pi->base_address=(uint64_t)fake_mem; return 0; }
static int mapped(uint64_t at,size_t len,int w){ (void)w; return at>=(uint64_t)fake_mem && at+len<=(uint64_t)fake_mem+fake_len; }
static int kwrite_count;
static int kwrite(uint64_t at,const void*src,size_t n){ if(!mapped(at,n,1)) return 0; memcpy((void*)at,src,n); kwrite_count++; return 1; }
// scripted real pad
static uint32_t real_btn; static uint8_t real_lx=0x80; static uint64_t ts; static int real_handle;
int scePadReadStateExt(int h, OrbisPadData* d){ memset(d,0,sizeof(*d)); d->buttons=real_btn; d->leftStick.x=real_lx; d->leftStick.y=0x80; d->rightStick.x=d->rightStick.y=0x80; d->timestamp=(ts+=16667); d->touch.fingers=(real_btn&0x100000)?1:0; return 0; }
int scePadReadExt(int h, OrbisPadData* d, int n){ scePadReadStateExt(h,d); return 1; }
#include "../repo/plugin_src/tekken_combo_macro/source/main.c"
// v2.17 host tests (v1.09): slot 10 fixed combo (seed, file, decode, playback), slots 1-9 untouched, menu 1..10.
#define CHK(x) do { if(!(x)) { printf("FAIL line %d: %s\n", __LINE__, #x); exit(1); } } while(0)
#define SLOT10 "/tmp/tkcm_test/GoldHEN/combo_macro/slot10.bin"
static int file_size(const char *p){ struct stat st; if(stat(p,&st)!=0) return -1; return (int)st.st_size; }
static int file_exists2(const char *p){ return file_size(p)>=0; }
static unsigned char *slurp_file(const char *p, size_t *n){ FILE *f=fopen(p,"rb"); if(!f) return 0; fseek(f,0,SEEK_END); *n=ftell(f); fseek(f,0,SEEK_SET); unsigned char *b=malloc(*n+1); fread(b,1,*n,f); fclose(f); return b; }
static void menu_key(uint32_t btn){ static MenuPad mp; menu_step(&g_menu, &mp, 1, btn); }

#define SLOTDIR "/tmp/tkcm_test/GoldHEN/combo_macro/"
static char pth[160];
static const char *slotp(int i){ snprintf(pth,sizeof pth,SLOTDIR "slot%d.bin",i); return pth; }
static void pad_key(uint32_t btn){ OrbisPadData d; memset(&d,0,sizeof d); d.buttons=btn; d.leftStick.x=d.leftStick.y=d.rightStick.x=d.rightStick.y=0x80; process_sample(1,&d,0); }
static void tap(uint32_t btn){ pad_key(btn); pad_key(0); }
static int same_bytes(const char *p, unsigned char *ref, size_t n){ size_t m=0; unsigned char *b=slurp_file(p,&m); int ok=b && m==n && (n==0 || memcmp(b,ref,n)==0); free(b); return ok; }
static void to_in(int k){ for(int i=0;i<60;i++) tap(MB_UP); for(int i=0;i<g_menu.mk_n+k;i++) tap(MB_DOWN); }
static int tv(uint32_t i){ return (int)((uint64_t)i*1000000u/60u); }


#include "../repo/plugin_src/tekken_combo_macro/source/ov_fast.c"
#include "../repo/plugin_src/tekken_combo_macro/source/font8x8_basic.h"
#define SLOTDIR18 "/tmp/tkcm_test/GoldHEN/combo_macro/"
static void to_in18(int k){ for(int i=0;i<60;i++) tap(MB_UP); for(int i=0;i<g_menu.mk_n+k;i++) tap(MB_DOWN); }
int main(int argc, char **argv){ setvbuf(stdout,0,_IONBF,0);
  system("rm -rf /tmp/tkcm_test; mkdir -p /tmp/tkcm_test");
  fake_len=CAVE_OFF+0x1000; fake_mem=calloc(1,fake_len); memcpy(fake_mem+SITE_OFF,SITE_ORIG,7);
  plugin_load(0,0);
  pad_key(MB_L3); pad_key(MB_L3|MB_OPTIONS); pad_key(0);
  g_menu.selected=ITEM_SLOT; g_menu.slot=2;
  tap(MB_TRIANGLE); tap(MB_DOWN); tap(MB_CROSS);
  /* a sample combo: 12 steps, mixed directions and buttons */
  const int D[] = {2,3,4,5,6,7,8,1,0,2,4,6}; const int B[] = {1,2,3,4,5,6,0,1,2,3,4,5};
  int sel_dir_btn[12][2]; for(int i=0;i<12;i++){ sel_dir_btn[i][0]=D[i]; sel_dir_btn[i][1]=B[i]; }
  for(int i=0;i<12;i++){
    g_menu.mk_dir = sel_dir_btn[i][0]; g_menu.mk_btn = sel_dir_btn[i][1];
    if (i==7) g_menu.mk_gap = 35; else g_menu.mk_gap = 20 + (i%3)*5;
    /* focus Button row, add */
    to_in18(1); tap(MB_CROSS);
  }
  g_menu.sub = g_menu.mk_n + 1; g_menu.mk_top = g_menu.mk_n - CE_MAKE_VIS;
  OvGeom g; ov_geom_bottom_wide(&g,1920,1080,CE_MAKE_ROWS,0,120);
  OvMenuView v; menu_view_fill(&v,"Pro A");
  uint8_t *cv=malloc((size_t)g.w*g.h); ovf_render(cv,&g,&v,font8x8_basic,1);
  FILE *f=fopen(argv[1],"wb"); fprintf(f,"%u %u\n",g.w,g.h); fwrite(cv,1,(size_t)g.w*g.h,f); fclose(f);
  printf("rendered %u x %u, rows %d, title %s\n", g.w, g.h, v.rows, v.title);
  for(int r=0;r<v.rows;r++) printf("  [%2d] %-22s %s\n", r, v.label[r]?v.label[r]:"", v.value[r]?v.value[r]:"");
  printf("  footer: %s\n", v.footer);
  return 0; }
