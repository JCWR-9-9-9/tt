import keystone,capstone,sys
# v2.15: flag bytes at cave+0/+1, entry cave+2 = short jmp over the pct table (cave+4..+11), code from cave+12.
src=open(sys.argv[1]).read()
CAVE=0x5447800
full = "flag_p1: .byte 0\nflag_p2: .byte 0\n" + src
ks=keystone.Ks(keystone.KS_ARCH_X86,keystone.KS_MODE_64)
enc,_=ks.asm(full,CAVE)
b=bytes(enc)
print(len(b)); print(b.hex())
md=capstone.Cs(capstone.CS_ARCH_X86,capstone.CS_MODE_64)
print('table', list(b[4:12]))
for i in md.disasm(b[2:4],CAVE+2): print(hex(i.address),i.bytes.hex(),i.mnemonic,i.op_str)
for i in md.disasm(b[12:],CAVE+12): print(hex(i.address),i.bytes.hex(),i.mnemonic,i.op_str)
if len(sys.argv)>2: open(sys.argv[2],'wb').write(b)
