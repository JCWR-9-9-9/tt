#pragma once
struct PNG{PNG(const char*){} void Draw(Scene2D*,int,int){}};
