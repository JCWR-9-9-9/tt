#pragma once
struct Scene2D{Scene2D(int,int,int){} bool Init(long,int){return true;} void FrameBufferClear(){} void SubmitFlip(int){} void FrameWait(int){} void FrameBufferSwap(){}};
