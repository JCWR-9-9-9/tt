#pragma once
#include <stdint.h>
#include <sys/types.h>
#include <string>
#include <fcntl.h>
#include <unistd.h>
#include <stdio.h>
#include <sys/stat.h>
enum { NotificationRequest=0 };
struct OrbisNotificationRequest { int type; int useIconImageUri; int targetId; char message[1024]; char iconUri[1024]; };
static std::string R(const char*p){ return std::string("/tmp/tkinst")+p; }
static char g_last_notify[1024];
static inline int sceKernelSendNotificationRequest(int,OrbisNotificationRequest*n,size_t,int){ snprintf(g_last_notify,1024,"%s",n->message); return 0; }
static inline int sceKernelOpen(const char*p,int f,int m){ int ff=0; if(f&1) ff|=O_WRONLY; if(f&0x200) ff|=O_CREAT; if(f&0x400) ff|=O_TRUNC; return open(R(p).c_str(),ff,m);}
static inline ssize_t sceKernelWrite(int fd,const void*b,size_t n){return write(fd,b,n);} static inline ssize_t sceKernelRead(int fd,void*b,size_t n){return read(fd,b,n);}
static inline int sceKernelClose(int fd){return close(fd);} static inline int sceKernelMkdir(const char*p,int m){return mkdir(R(p).c_str(),m);}
static inline int sceKernelRename(const char*a,const char*b){return rename(R(a).c_str(),R(b).c_str());} static inline int sceKernelUnlink(const char*p){return unlink(R(p).c_str());}
static inline int sceKernelUsleep(int){return 0;}
