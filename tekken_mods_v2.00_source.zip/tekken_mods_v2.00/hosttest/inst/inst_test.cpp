
#define main installer_main
#include "../../installer/installer/main.cpp"
#undef main
#include <assert.h>
#include <stdlib.h>
static std::string slurp(const char*p){ FILE*f=fopen(p,"rb"); if(!f) return "<none>"; std::string s; char b[4096]; size_t n; while((n=fread(b,1,4096,f))>0) s.append(b,n); fclose(f); return s; }
static void spit(const char*p,const std::string&s){ FILE*f=fopen(p,"wb"); fwrite(s.data(),1,s.size(),f); fclose(f); }
extern "C" { int sys_sdk_jailbreak(struct jailbreak_backup_s*){return 0;} uint32_t sys_sdk_version(){return 0x00020400;} }
int main(){
  system("rm -rf /tmp/tkinst; mkdir -p /tmp/tkinst/data/GoldHEN/plugins");
  std::string C="/data/GoldHEN/plugins/tekken_combo_macro.prx\n", MM="/data/GoldHEN/plugins/tekken_modmenu.prx\n";
  std::string ini="[default]\n/data/GoldHEN/plugins/no_share_watermark.prx\n\n; Tekken 7 combo macro (L3+R3 record, R3 play, L3 play mirrored)\n[CUSA05972]\n"+C+"[CUSA06014]\n"+C+MM+"[CUSA05898]\n"+C+"[CUSA05798]\n"+C;
  spit("/tmp/tkinst/data/GoldHEN/plugins.ini",ini);
  spit("/tmp/tkinst/data/GoldHEN/plugins/tekken_modmenu.prx","oldmenu");
  spit("/tmp/tkinst/data/GoldHEN/plugins/tekken_combo_macro.prx","oldcombo");
  system("mkdir -p /tmp/tkinst/data/GoldHEN/combo_macro");                      // v1.04: his saved combo + overlay setting
  spit("/tmp/tkinst/data/GoldHEN/combo_macro/slot1.bin","SAVEDCOMBO\x01\x02"); spit("/tmp/tkinst/data/GoldHEN/combo_macro/overlay.cfg","2");
  spit("/tmp/tkinst/data/GoldHEN/combo_macro/slot7.bin","SLOT7"); spit("/tmp/tkinst/data/GoldHEN/combo_macro/combo_slot.cfg","7\n");   // v1.05: slots 2..10 + selection
  char reason[200]; int rc=install(reason,sizeof(reason)); printf("rc=%d %s\n",rc,reason); assert(rc==0);
  std::string prx=slurp("/tmp/tkinst/data/GoldHEN/plugins/tekken_combo_macro.prx");
  assert(prx.size()==combo_prx_len && !memcmp(prx.data(),combo_prx,combo_prx_len));
  assert(slurp("/tmp/tkinst/data/GoldHEN/plugins/tekken_modmenu.prx")=="<none>");
  std::string out=slurp("/tmp/tkinst/data/GoldHEN/plugins.ini"); printf("--- plugins.ini after ---\n%s---\n",out.c_str());
  std::string want=ini; want.erase(want.find(MM),MM.size()); assert(out==want);
  assert(strstr(reason,"1 ini line"));
  assert(slurp("/tmp/tkinst/data/GoldHEN/combo_macro/slot1.bin")=="SAVEDCOMBO\x01\x02" && slurp("/tmp/tkinst/data/GoldHEN/combo_macro/overlay.cfg")=="2");
  assert(slurp("/tmp/tkinst/data/GoldHEN/combo_macro/slot7.bin")=="SLOT7" && slurp("/tmp/tkinst/data/GoldHEN/combo_macro/combo_slot.cfg")=="7\n");
  assert(system("test $(ls /tmp/tkinst/data/GoldHEN/combo_macro | wc -l) -eq 4")==0);
  assert(memmem(combo_prx,combo_prx_len,"Tekken Combo + Mod Menu ON (v2.16)",34)!=NULL);   // blob is the v2.16 plugin
  // second run: idempotent, no ini change
  rc=install(reason,sizeof(reason)); printf("rerun rc=%d %s\n",rc,reason); assert(rc==0 && slurp("/tmp/tkinst/data/GoldHEN/plugins.ini")==want);
  // fresh console: no ini, no dirs
  system("rm -rf /tmp/tkinst; mkdir -p /tmp/tkinst/data");
  rc=install(reason,sizeof(reason)); printf("fresh rc=%d %s\n",rc,reason); assert(rc==0);
  printf("%s", slurp("/tmp/tkinst/data/GoldHEN/plugins.ini").c_str());
  // tmp files cleaned
  assert(slurp("/tmp/tkinst/data/GoldHEN/plugins.ini.tabnew")=="<none>");
  puts("ALL INSTALLER TESTS PASSED"); return 0; }
