// bench_old.c — the v2.13 per-frame copy (ov_blit) compiled at -O0, as the plugin was built.
#include <stdlib.h>
#include <time.h>
#include "../repo/plugin_src/tekken_combo_macro/source/overlay_draw.h"
double bench_old(int layout,uint32_t W,uint32_t Hh,const uint8_t*cv,const OvGeom*g,int reps){
  uint64_t surf=ov_surface_bytes(layout,W,Hh); uint8_t *b=calloc(1,surf);
  struct timespec a,c; clock_gettime(CLOCK_MONOTONIC,&a);
  for(int k=0;k<reps;k++) ov_blit(b,surf,layout,W,OV_FMT_A8R8G8B8_SRGB,cv,g);
  clock_gettime(CLOCK_MONOTONIC,&c); free(b);
  return ((c.tv_sec-a.tv_sec)*1e3+(c.tv_nsec-a.tv_nsec)/1e6)/reps; }
