
#include <cstdio>
#include <cstdint>
#include <cstring>
#include <cstdlib>
#include "../repo/plugin_src/tekken_combo_macro/source/font8x8_basic.h"
#include "../repo/plugin_src/tekken_combo_macro/source/overlay_draw.h"
#include "../repo/plugin_src/tekken_combo_macro/source/menu_logic.h"
int main(int argc,char**argv){
  OvGeom g; ov_geom(&g,1920,1080,3);
  uint8_t *cv=(uint8_t*)malloc(g.w*g.h);
  OvMenuView v; memset(&v,0,sizeof v); v.rows=3; v.selected=0; v.title="TEKKEN 7 MOD MENU"; v.footer="D-PAD SELECT/CHANGE   O CLOSE";
  int h0=atoi(argv[1]), h1=atoi(argv[2]);
  v.label[0]="P1 Health"; v.value[0]=menu_value(h0); v.value_kind[0]=menu_value_kind(h0);
  v.label[1]="P2 Health"; v.value[1]=menu_value(h1); v.value_kind[1]=menu_value_kind(h1);
  v.label[2]="Overlay"; v.value[2]="Pro A";
  ov_render_menu(cv,&g,&v,font8x8_basic);
  FILE*f=fopen(argv[3],"wb"); fwrite(&g.w,4,1,f); fwrite(&g.h,4,1,f); fwrite(cv,1,g.w*g.h,f); fclose(f);
  for(int i=0;i<PAL_COUNT;i++) printf("%d %d %d\n",OV_PAL_RGB[i][0],OV_PAL_RGB[i][1],OV_PAL_RGB[i][2]);
}
