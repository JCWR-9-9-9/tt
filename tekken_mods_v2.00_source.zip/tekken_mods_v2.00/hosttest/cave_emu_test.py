
import sys, struct, random, re
from unicorn import *
from unicorn.x86_const import *

def parse_header(path):
    t=open(path).read()
    def arr(name):
        m=re.search(r'static const unsigned char %s\[\]=\{([^}]*)\}'%name,t); return bytes(int(x,16) for x in m.group(1).split(','))
    return arr('CAVE_DMG'), arr('CAVE'), arr('SITE_PATCH'), arr('SITE_ORIG')

CAVE_DMG, CAVE_TLH, SITE_PATCH, SITE_ORIG = parse_header(sys.argv[1])
SITE=0x1496643; CAVE=0x5447800; BACK=0x149664a
STRUCT=0x20000000; STACK=0x30000000
fails=0; n=0
def run(cave, flags, player, old, new, maxhp, rax_hi=0):
    global n
    n+=1
    mu=Uc(UC_ARCH_X86,UC_MODE_64)
    mu.mem_map(0x1496000,0x1000, UC_PROT_READ|UC_PROT_EXEC)
    mu.mem_map(0x5447000,0x1000, UC_PROT_READ|UC_PROT_EXEC)
    mu.mem_map(STRUCT,0x10000); mu.mem_map(STACK-0x10000,0x20000)
    mu.mem_write(SITE, SITE_PATCH + b'\xf4')    # hlt marker right after the patched 7 bytes at BACK
    c=bytearray(cave); c[0]=flags[0]; c[1]=flags[1]
    mu.mem_write(CAVE, bytes(c))
    mu.mem_write(STRUCT+0x14a0, struct.pack('<iii', player, old, maxhp))
    rz=bytes(random.getrandbits(8) for _ in range(0x100))
    mu.mem_write(STACK-0x80, rz)                 # 128-byte red zone + caller's frame above rsp
    regs={UC_X86_REG_RBX:0x1111,UC_X86_REG_RCX:0xdeadbeefcafe0001,UC_X86_REG_RDX:0x123456789abcdef0,
          UC_X86_REG_RSI:7,UC_X86_REG_RDI:8,UC_X86_REG_R8:9,UC_X86_REG_R9:10,UC_X86_REG_R10:11,UC_X86_REG_R11:12,
          UC_X86_REG_R12:13,UC_X86_REG_R13:14,UC_X86_REG_R14:15,UC_X86_REG_RBP:16}
    for r,v in regs.items(): mu.reg_write(r,v)
    mu.reg_write(UC_X86_REG_R15,STRUCT); mu.reg_write(UC_X86_REG_RSP,STACK)
    mu.reg_write(UC_X86_REG_RAX,(rax_hi<<32)|(new & 0xffffffff))
    mu.emu_start(SITE, BACK, count=200)
    assert mu.reg_read(UC_X86_REG_RIP)==BACK, hex(mu.reg_read(UC_X86_REG_RIP))
    for r,v in regs.items(): assert mu.reg_read(r)==v, ('clobbered',r)
    assert mu.reg_read(UC_X86_REG_RSP)==STACK, 'rsp'
    assert mu.reg_read(UC_X86_REG_R15)==STRUCT
    assert bytes(mu.mem_read(STACK-0x80,0x100))==rz, 'red zone touched'
    p,h,m=struct.unpack('<iii',bytes(mu.mem_read(STRUCT+0x14a0,12)))
    assert p==player and m==maxhp
    rax=mu.reg_read(UC_X86_REG_RAX)
    eax=struct.unpack('<i',struct.pack('<I',rax&0xffffffff))[0]
    assert eax==h, ('eax != written', eax, h)
    return h, rax

def expected(mode, old, new, maxhp):
    if mode==1: return maxhp
    if mode==2: return new if (new & 0xffffffff)==0 else 1
    pct={3:80,4:60,5:50,6:105,7:110,8:120,9:150,10:200}.get(mode)
    if pct is None or new>=old: return new
    d=old-new; scaled=(d*pct+(50 if pct>100 else 0))//100
    if scaled==0: scaled=1
    return max(old-scaled,min(new,0))

random.seed(1)
cases=[]
for old,new in [(180,170),(180,175),(180,179),(10,0),(1,0),(2,0),(2,1),(5,4),(180,0),(180,-20),(50,-100),(0,0),(0,-5),
                (170,180),(100,180),(0,180),(180,180),(30,25),(100,90),(7,6),(3,2),(170,169),(2147483647,-2147483648),(-5,-10)]:
    cases.append((old,new))
for _ in range(300):
    old=random.randint(0,250); cases.append((old, random.randint(-50,260)))

for cave_name, cave in (('DMG',CAVE_DMG),('TLH',CAVE_TLH)):
  modes = range(0,13) if cave_name=='DMG' else (0,1,2)
  for mode in modes:
    for player in (0,1):
      for old,new in cases:
        flags=[0,0]; flags[player]=mode
        other=[0,0]; other[1-player]=mode   # mode on the OTHER player must not affect this one
        for fl,mm in ((flags,mode),(other,0)):
          exp=expected(mm if mm<=10 else 0, old, new, 180)
          got,rax=run(cave, fl, player, old, new, 180)
          if got!=exp:
            fails+=1; print('FAIL',cave_name,'mode',mode,'P',player+1,'flags',fl,old,new,'got',got,'exp',exp)
          if cave_name=='DMG' and mm in (0,1,2):
            g2,r2=run(CAVE_TLH, fl, player, old, new, 180)
            if (g2,r2)!=(got,rax): fails+=1; print('DIFF vs TLH', mm, old,new,got,g2,hex(rax),hex(r2))
# invariants for damage modes
for mode in (3,4,5):
  for old in range(0,200):
    for new in range(-10,old):
      got,_=run(CAVE_DMG,[mode,0],0,old,new,180)
      if not (new<=got<old): fails+=1; print('INV',mode,old,new,got)
# KO reachable: repeated 1-damage hits from 180 reach 0 in every mode
for mode in (3,4,5):
  h=180; hits=0
  while h>0 and hits<1000:
    h,_=run(CAVE_DMG,[mode,0],0,h,h-1,180); hits+=1
  if h!=0: fails+=1; print('NO KO', mode)
  else: print('mode',mode,'KO after',hits,'1-dmg hits')
# example table
for mode,name in ((3,'80%'),(4,'60%'),(5,'50%')):
  row=[]
  for old,new in [(180,170),(180,175),(180,179),(10,0),(1,0),(180,0),(100,180)]:
    row.append('%d->%d:%d'%(old,new,run(CAVE_DMG,[mode,0],0,old,new,180)[0]))
  print(name,' '.join(row))
print('runs',n,'fails',fails)
sys.exit(1 if fails else 0)
