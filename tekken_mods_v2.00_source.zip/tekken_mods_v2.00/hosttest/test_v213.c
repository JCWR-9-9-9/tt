
#define TK_HOST_TEST 1
#include <fcntl.h>
#include <unistd.h>
#include <sys/stat.h>
#include <assert.h>
#include "plugin_common.h"
#include "Common.h"
#include "orbis/Pad.h"
char last_notify[512]; int notify_count; char all_notify[16384];
void NotifyStatic(const char* i, const char *t){ snprintf(last_notify,512,"%s",t); notify_count++; strncat(all_notify,t,sizeof(all_notify)-strlen(all_notify)-2); strcat(all_notify,"|"); printf("  [NOTIFY] %s\n", t); }
void Notify(const char* i, const char *f, ...){ char b[512]; va_list a; va_start(a,f); vsnprintf(b,512,f,a); va_end(a); NotifyStatic(i,b);}
int sceKernelOpen(const char*p,int f,int m){ int ff=0; if(f&1) ff|=O_WRONLY; if(f&0x200) ff|=O_CREAT; if(f&0x400) ff|=O_TRUNC; return open(p,ff,m);}
ssize_t sceKernelWrite(int fd,const void*b,size_t n){return write(fd,b,n);} ssize_t sceKernelRead(int fd,void*b,size_t n){return read(fd,b,n);}
int sceKernelClose(int fd){return close(fd);} int sceKernelMkdir(const char*p,int m){return mkdir(p,m);}
int sceKernelRename(const char*a,const char*b){return rename(a,b);} int sceKernelUnlink(const char*p){return unlink(p);}
const char* sceKernelGetFsSandboxRandomWord(void){return "abc";} int sys_dynlib_load_prx(const char*p, int*h){return 0;}
int scePadRead(int h, OrbisPadData* d, int n){return 0;} int scePadReadState(int h, OrbisPadData* d){return 0;}
// fake eboot memory for the health cave
static unsigned char *fake_mem; static size_t fake_len;
#include "../repo/plugin_src/tekken_combo_macro/source/health_bytes.h"
int sys_sdk_proc_info(struct proc_info *pi){ memset(pi,0,sizeof(*pi));
#ifdef WRONG_TITLE
  strcpy(pi->titleid,"CUSA05972"); strcpy(pi->version,"01.00");
#else
  strcpy(pi->titleid,"CUSA06014"); strcpy(pi->version,"05.10");
#endif
  pi->base_address=(uint64_t)fake_mem; return 0; }
static int mapped(uint64_t at,size_t len,int w){ (void)w; return at>=(uint64_t)fake_mem && at+len<=(uint64_t)fake_mem+fake_len; }
static int kwrite_count;
static int kwrite(uint64_t at,const void*src,size_t n){ if(!mapped(at,n,1)) return 0; memcpy((void*)at,src,n); kwrite_count++; return 1; }
// scripted real pad
static uint32_t real_btn; static uint8_t real_lx=0x80; static uint64_t ts; static int real_handle;
int scePadReadStateExt(int h, OrbisPadData* d){ memset(d,0,sizeof(*d)); d->buttons=real_btn; d->leftStick.x=real_lx; d->leftStick.y=0x80; d->rightStick.x=d->rightStick.y=0x80; d->timestamp=(ts+=16667); d->touch.fingers=(real_btn&0x100000)?1:0; return 0; }
static int read_k=1;   // samples scePadRead returns per call (buffered read)
int scePadReadExt(int h, OrbisPadData* d, int n){ int k=read_k<n?read_k:n; for(int i=0;i<k;i++) scePadReadStateExt(h,&d[i]); return k; }
#include "../repo/plugin_src/tekken_combo_macro/source/main.c"
#include "../repo/plugin_src/tekken_combo_macro/source/font8x8_basic.h"
// v2.13 host tests: 10 combo slots (incl. the legacy v2.12 slot1.bin), menu rows, slot clear,
// selected-slot persistence, slow-motion pacing math + hook integration, combo timing under slow motion.
#define L3 0x2
#define R3 0x4
#define OPT 0x8
#define UP 0x10
#define DOWN 0x40
#define SQ 0x8000
#define TRI 0x1000
#define X 0x4000
#define O 0x2000
#define RIGHT 0x20
#define LEFT 0x80
#define DIR "/tmp/tkcm_test/GoldHEN/combo_macro"
static OrbisPadData out;
static int checks;
#define CHECK(c) do{ checks++; if(!(c)){ printf("FAIL line %d: %s\n",__LINE__,#c); exit(1);} }while(0)
static uint32_t frame(uint32_t b){ real_btn=b; scePadReadState_hook(real_handle,&out); g_host_now_us+=16000; return out.buttons; }   // + the game's own frame work
static void frames(uint32_t b,int n){ for(int i=0;i<n;i++) frame(b); }
// one buffered read call returning k samples; returns the buttons of every sample
static void read_call(uint32_t b,int k,uint32_t *got){ real_btn=b; read_k=k; OrbisPadData arr[64]; int r=scePadRead_hook(real_handle,arr,64); g_host_now_us+=16000; for(int i=0;i<r;i++) if(got) got[i]=arr[i].buttons; read_k=1; }
static void press(uint32_t b){ frame(b); frame(0); }
static void menu_open(void){ frame(L3); frame(L3|OPT); frame(0); CHECK(g_menu.open); }
static void menu_close(void){ press(O); CHECK(!g_menu.open); }
static void go_row(int row){ while(g_menu.selected!=row) press(DOWN); }
static int file_exists(const char*p){ struct stat st; return stat(p,&st)==0; }
static long file_size(const char*p){ struct stat st; return stat(p,&st)==0? (long)st.st_size : -1; }
static int file_same(const char*a,const char*b){ FILE*x=fopen(a,"rb"),*y=fopen(b,"rb"); if(!x||!y){ if(x)fclose(x); if(y)fclose(y); return 0;} int same=1,c,d; do{ c=fgetc(x); d=fgetc(y); if(c!=d){same=0;break;} }while(c!=EOF); fclose(x); fclose(y); return same; }
static void put(const char*p,const char*s){ FILE*f=fopen(p,"wb"); fputs(s,f); fclose(f); }
static void reload(void){ plugin_unload(0,0); g_menu_enabled=0; CHECK(plugin_load(0,0)==0); }
static const uint32_t LEGACY[18]={RIGHT,RIGHT,RIGHT,SQ,SQ,0,0,0,0,0,TRI,X,X,X,X,RIGHT|SQ,RIGHT|SQ,0};
// plays the selected slot with R3 (ReadState path) and compares every frame
static void expect_play(uint32_t trig,const uint32_t *exp,int n,int mirror){
  frames(trig,2); CHECK(frame(0)==0); CHECK(g_state==ST_PLAYING && g_play_mirror==mirror);
  for(int i=0;i<n;i++){ uint32_t b=frame(0), e=exp[i];
    if(mirror){ uint32_t l=e&LEFT,r=e&RIGHT; e&=~(LEFT|RIGHT); if(l)e|=RIGHT; if(r)e|=LEFT; }
    if(b!=e){ printf("frame %d: got %x want %x\n",i,b,e); exit(1);} }
  CHECK(g_state==ST_IDLE);
}
static void record(const uint32_t *seq,const int *len,int n){   // L3+R3, the inputs, L3+R3
  frames(L3|R3,2); frames(0,3); CHECK(g_state==ST_RECORDING);
  for(int i=0;i<n;i++) frames(seq[i],len[i]);
  frames(0,4); frames(L3|R3,2); frames(0,2); CHECK(g_state==ST_IDLE);
}

// ---------------------------------------------------------------- pacing (pure math)
static void pacing_math(void){
  printf("P1) frame periods: 100%% none, 75%% 22222us, 50%% 33333us, 33%% 50000us, 25%% 66667us\n");
  CHECK(pace_period_us(SPEED_NUM[SPEED_100],SPEED_DEN[SPEED_100])==0);
  CHECK(pace_period_us(SPEED_NUM[SPEED_75],SPEED_DEN[SPEED_75])==22222);
  CHECK(pace_period_us(SPEED_NUM[SPEED_50],SPEED_DEN[SPEED_50])==33333);
  CHECK(pace_period_us(SPEED_NUM[SPEED_33],SPEED_DEN[SPEED_33])==50000);
  CHECK(pace_period_us(SPEED_NUM[SPEED_25],SPEED_DEN[SPEED_25])==66667);
  printf("P2) simulated game (60 fps natural, 1-2 controllers, jittery work): reads/s = speed x 60\n");
  for(int sp=0;sp<SPEED_CHOICES;sp++) for(int pads=1;pads<=2;pads++) for(int jit=0;jit<2;jit++){
    Pacer p; memset(&p,0,sizeof p); uint64_t now=1000000, first=0, last=0, maxw=0; int frames_n=600; uint64_t per=pace_period_us(SPEED_NUM[sp],SPEED_DEN[sp]);
    unsigned seed=12345;
    for(int f=0;f<frames_n;f++){
      for(int h=0;h<pads;h++){
        int key=pace_is_key(&p,h,2,now); uint64_t w=0;
        if(key){ pace_measure(&p,now); w=pace_step(&p,now,per); now+=w; if(w>maxw)maxw=w; if(f==60) first=now; last=now; }
        now+=200;   // the read itself
      }
      seed=seed*1103515245+12345; uint64_t work=16667-200*pads + (jit? (seed>>16)%3000 : 0) - (jit?1500:0);
      now+=work;    // the rest of the game frame (vsync-bound ~16.7 ms)
    }
    double avg=(double)(last-first)/(frames_n-1-60), want= per? (double)per : 16667.0;
    if(jit && !per) want=16667.0;
    if(avg<want-60 || avg>want+60){ printf("speed %d pads %d jit %d: avg %.1f want %.1f\n",sp,pads,jit,avg,want); exit(1);}
    CHECK(maxw<=per); if(!per) CHECK(maxw==0);
    double rate=1e6/avg; CHECK(p.rate>= (uint32_t)(rate-2) && p.rate<=(uint32_t)(rate+2));
  }
  printf("P3) loading stall (2 s without reads) restarts the schedule: no catch-up burst, no long sleep\n");
  { Pacer p; memset(&p,0,sizeof p); uint64_t now=0, per=33333; int burst=0;
    for(int f=0;f<100;f++){ pace_is_key(&p,0,2,now); now+=pace_step(&p,now,per); now+=16667; }
    now+=2000000; pace_is_key(&p,0,2,now); uint64_t w=pace_step(&p,now,per); CHECK(w==0);
    now+=16667; for(int f=0;f<20;f++){ pace_is_key(&p,0,2,now); uint64_t w2=pace_step(&p,now,per); if(w2<10000) burst++; now+=w2+16667; }
    CHECK(burst==0); }
  printf("P4) game slower than the target (30 fps natural, 75%% asked): never adds a sleep\n");
  { Pacer p; memset(&p,0,sizeof p); uint64_t now=0, per=22222, slept=0;
    for(int f=0;f<300;f++){ pace_is_key(&p,0,2,now); uint64_t w=pace_step(&p,now,per); slept+=w; now+=w+33333; }
    CHECK(slept==0); }
  printf("P5) back to 100%%: the very next read does not sleep\n");
  { Pacer p; memset(&p,0,sizeof p); uint64_t now=0;
    for(int f=0;f<50;f++){ pace_is_key(&p,0,2,now); now+=pace_step(&p,now,66667)+16667; }
    pace_is_key(&p,0,2,now); CHECK(pace_step(&p,now,0)==0); CHECK(!p.active); }
  printf("P6) pace key: second controller never paced; key moves when the first controller is gone\n");
  { Pacer p; memset(&p,0,sizeof p); CHECK(pace_is_key(&p,7,2,0)); CHECK(!pace_is_key(&p,8,2,100)); CHECK(!pace_is_key(&p,7,1,200));
    CHECK(!pace_is_key(&p,8,2,400000)); CHECK(pace_is_key(&p,8,2,700000)); CHECK(!pace_is_key(&p,7,2,700100)); }
  printf("P7) combo gate: ReadState always 1 step/frame; buffered read keeps game time; 100%% = every sample\n");
  { ComboGate g; gate_reset(&g); int adv=0;
    for(int c=0;c<100;c++) adv+=gate_sample(&g,2,1,4,1,1); CHECK(adv==100);
    gate_reset(&g); adv=0; for(int c=0;c<100;c++) for(int i=0;i<4;i++) adv+=gate_sample(&g,1,1,1,i==0,i==3); CHECK(adv==400);
    gate_reset(&g); adv=0; for(int c=0;c<100;c++) for(int i=0;i<8;i++) adv+=gate_sample(&g,1,1,2,i==0,i==7); CHECK(adv==400);   // 50%: 8/call -> 4
    gate_reset(&g); adv=0; for(int c=0;c<99;c++) for(int i=0;i<12;i++) adv+=gate_sample(&g,1,1,3,i==0,i==11); CHECK(adv==396); // 33%: 12 -> 4
    gate_reset(&g); adv=0; for(int c=0;c<100;c++) adv+=gate_sample(&g,1,1,4,1,1); CHECK(adv==100);   // 1 sample/call: still 1 per frame
    gate_reset(&g); adv=0; for(int c=0;c<100;c++) for(int i=0;i<4;i++) adv+=gate_sample(&g,1,3,4,i==0,i==3); CHECK(adv==300); }
}

int main(){ setvbuf(stdout,0,_IONBF,0);
  pacing_math();
  system("rm -rf /tmp/tkcm_test; mkdir -p " DIR);
  fake_len=CAVE_OFF+0x1000; fake_mem=calloc(1,fake_len); memcpy(fake_mem+SITE_OFF,SITE_ORIG,7);
  system("cp fixtures/legacy_slot1_v212.bin " DIR "/slot1.bin && cp fixtures/legacy_slot1_v212.bin /tmp/tkcm_legacy_copy.bin");
  printf("S1) legacy slot1.bin (written by v2.12) loads unchanged as slot 1, plays frame-exact\n");
  CHECK(plugin_load(0,0)==0); CHECK(g_menu_enabled); CHECK(g_menu.slot==0);
  CHECK(g_slot_count==18 && g_slot_len[0]==18 && g_slot_presses[0]==6);
  for(int i=1;i<SLOT_COUNT-1;i++) CHECK(g_slot_len[i]==0);
  CHECK(g_slot_len[SLOT_COUNT-1]==150);   // v2.16: slot 10 holds the fixed combo (seeded at plugin load)
  CHECK(strstr(last_notify,"Tekken Combo + Mod Menu ON (v2.18) (combo slot 1 loaded: 18 frames)"));
  expect_play(R3,LEGACY,18,0); expect_play(L3,LEGACY,18,1);
  CHECK(file_same(DIR "/slot1.bin","/tmp/tkcm_legacy_copy.bin")); CHECK(!file_exists(DIR "/combo_slot.cfg"));
  CHECK(g_menu.speed==SPEED_100 && g_host_sleeps==0);

  printf("S2) menu rows: P1 Health, P2 Health, Combo slot, Game speed, Overlay\n");
  menu_open(); CHECK(g_menu.selected==ITEM_P1_HEALTH);
  press(DOWN); press(DOWN); CHECK(g_menu.selected==ITEM_SLOT);
  { OvMenuView v; menu_view_fill(&v,"Pro A"); CHECK(v.rows==5);
    CHECK(!strcmp(v.label[0],"P1 Health")&&!strcmp(v.label[1],"P2 Health")&&!strcmp(v.label[2],"Combo slot")&&!strcmp(v.label[3],"Game speed")&&!strcmp(v.label[4],"Overlay"));
    CHECK(!strcmp(v.value[2],"1: 0.3s")); CHECK(v.value_kind[2]==1); CHECK(!strcmp(v.value[3],"100%")); CHECK(!strcmp(v.value[4],"Pro A"));
    CHECK(v.strip && v.strip_row==ITEM_SLOT && v.strip_sel==0 && v.strip_full==((1u<<0)|(1u<<9))); CHECK(strstr(v.footer,"SQUARE CLEAR")); }

  printf("S3) Right -> slot 2 (empty): R3/L3 now use slot 2; choice saved to combo_slot.cfg\n");
  press(RIGHT); CHECK(g_menu.slot==1 && g_slot_count==0);
  { FILE*f=fopen(DIR "/combo_slot.cfg","r"); char b[8]={0}; CHECK(f && fgets(b,8,f)); fclose(f); CHECK(!strcmp(b,"2\n")); }
  { OvMenuView v; menu_view_fill(&v,"x"); CHECK(!strcmp(v.value[2],"2: empty")); CHECK(v.value_kind[2]==0); CHECK(v.strip_sel==1 && v.strip_full==((1u<<0)|(1u<<9))); }
  menu_close(); frames(R3,2); frame(0); CHECK(g_state==ST_IDLE); CHECK(strstr(last_notify,"No combo in slot 2"));

  printf("S4) record into slot 2: slot2.bin written, slot1.bin untouched\n");
  { uint32_t seq[]={DOWN,DOWN|RIGHT,RIGHT,TRI}; int len[]={2,2,2,3}; record(seq,len,4); }
  CHECK(strstr(last_notify,"Combo saved (3 inputs, 10 frames") && strstr(last_notify,"Slot 2"));
  CHECK(file_size(DIR "/slot2.bin")==32+16*10); CHECK(file_same(DIR "/slot1.bin","/tmp/tkcm_legacy_copy.bin"));
  CHECK(g_slot_len[1]==10 && g_slot_presses[1]==3 && g_slot_len[0]==18);
  const uint32_t S2SEQ[10]={DOWN,DOWN,DOWN|RIGHT,DOWN|RIGHT,RIGHT,RIGHT,TRI,TRI,TRI,0};
  expect_play(R3,S2SEQ,10,0); expect_play(L3,S2SEQ,10,1);

  printf("S5) back to slot 1 plays the legacy combo; slot 2 again plays slot 2\n");
  menu_open(); go_row(ITEM_SLOT); press(LEFT); CHECK(g_menu.slot==0 && g_slot_count==18); menu_close();
  expect_play(R3,LEGACY,18,0);
  menu_open(); go_row(ITEM_SLOT); press(RIGHT); menu_close(); expect_play(R3,S2SEQ,10,0);

  printf("S6) wrap: Left from slot 1 -> slot 10; slot10.bin; cfg \"10\"\n");
  menu_open(); go_row(ITEM_SLOT); press(LEFT); press(LEFT); CHECK(g_menu.slot==9); menu_close();
  { uint32_t seq[]={SQ,TRI}; int len[]={1,1}; record(seq,len,2); }
  CHECK(file_size(DIR "/slot10.bin")==32+16*3); CHECK(strstr(last_notify,"Slot 10"));
  { FILE*f=fopen(DIR "/combo_slot.cfg","r"); char b[8]={0}; CHECK(f && fgets(b,8,f)); fclose(f); CHECK(!strcmp(b,"10\n")); }
  menu_open(); go_row(ITEM_SLOT);
  { OvMenuView v; menu_view_fill(&v,"x"); CHECK(v.strip_full==((1u<<0)|(1u<<1)|(1u<<9))); CHECK(v.strip_sel==9); CHECK(!strcmp(v.value[2],"10: 0.1s")); }
  press(RIGHT); CHECK(g_menu.slot==0); press(LEFT); CHECK(g_menu.slot==9);
  menu_close();

  printf("S7) restart: selected slot (10) and every slot's length come back; speed starts at 100%%\n");
  g_menu.speed=SPEED_25; reload();
  CHECK(g_menu.slot==9 && g_slot_count==3 && g_slot_len[0]==18 && g_slot_len[1]==10 && g_slot_len[9]==3);
  CHECK(g_menu.speed==SPEED_100); CHECK(strstr(last_notify,"(combo slot 10 loaded: 3 frames)"));
  printf("S8) bad cfg values fall back to slot 1\n");
  const char *bad[]={"0\n","11\n","x\n","","-3"};
  for(int i=0;i<5;i++){ put(DIR "/combo_slot.cfg",bad[i]); reload(); CHECK(g_menu.slot==0 && g_slot_count==18); }
  put(DIR "/combo_slot.cfg","7"); reload(); CHECK(g_menu.slot==6 && g_slot_count==0); CHECK(strstr(last_notify,"(combo slot 7)"));
  put(DIR "/combo_slot.cfg","2\n"); reload(); CHECK(g_menu.slot==1 && g_slot_count==10);

  printf("S9) clear: Square on an empty slot = 'already empty'; Square then Down = no; Square, Square = cleared\n");
  menu_open(); go_row(ITEM_SLOT); press(LEFT); press(LEFT); press(LEFT); CHECK(g_menu.slot==8 && g_slot_len[8]==0);
  press(SQ); CHECK(!g_menu.clear_armed); CHECK(strstr(last_notify,"Combo slot 9 is already empty"));
  press(RIGHT); press(RIGHT); press(RIGHT); CHECK(g_menu.slot==1);
  press(SQ); CHECK(g_menu.clear_armed);
  { OvMenuView v; menu_view_fill(&v,"x"); CHECK(!strcmp(v.value[2],"Clear? SQUARE") && v.value_kind[2]==2); CHECK(strstr(v.footer,"SQUARE AGAIN")); }
  press(DOWN); CHECK(!g_menu.clear_armed && g_menu.selected==ITEM_SPEED); CHECK(file_exists(DIR "/slot2.bin"));
  press(UP); press(SQ); press(RIGHT); CHECK(!g_menu.clear_armed && g_menu.slot==2); press(LEFT);   // Right also = no
  CHECK(file_exists(DIR "/slot2.bin") && g_slot_count==10);
  press(SQ); press(SQ); CHECK(!g_menu.clear_armed); CHECK(!file_exists(DIR "/slot2.bin")); CHECK(g_slot_len[1]==0 && g_slot_count==0);
  CHECK(strstr(last_notify,"Combo slot 2 cleared"));
  CHECK(file_same(DIR "/slot1.bin","/tmp/tkcm_legacy_copy.bin") && file_exists(DIR "/slot10.bin"));
  press(SQ); CHECK(strstr(last_notify,"already empty"));
  press(SQ); press(O); CHECK(!g_menu.open && !g_menu.clear_armed); frame(0);   // O closes and disarms
  menu_open(); CHECK(!g_menu.clear_armed); go_row(ITEM_SLOT); press(LEFT); CHECK(g_menu.slot==0); menu_close();
  printf("S10) Square on other rows does nothing to slots\n");
  menu_open(); go_row(ITEM_P1_HEALTH); press(SQ); go_row(ITEM_SPEED); press(SQ); CHECK(!g_menu.clear_armed); CHECK(g_slot_len[0]==18); menu_close();

  printf("S11) Game speed row cycles 100 -> 75 -> 50 -> 33 -> 25 -> 100; Left from 100 = 25\n");
  menu_open(); go_row(ITEM_SPEED);
  const char *names[]={"75%","50%","33%","25%","100%"};
  for(int i=0;i<5;i++){ press(RIGHT); OvMenuView v; menu_view_fill(&v,"x"); CHECK(!strcmp(v.value[3],names[i])); CHECK(v.value_kind[3]==(i<4?3:0)); }
  press(LEFT); CHECK(g_menu.speed==SPEED_25); press(RIGHT); CHECK(g_menu.speed==SPEED_100);
  CHECK(g_menu.health[0]==0 && g_menu.health[1]==0 && g_menu.slot==0);   // speed row touches nothing else

  printf("S12) slow motion through the real hooks: 50%% -> one read per 33.3 ms; none while the menu is open\n");
  press(RIGHT); press(RIGHT); CHECK(g_menu.speed==SPEED_50);
  uint32_t s0=g_host_sleeps; for(int i=0;i<30;i++){ frame(0); } CHECK(g_host_sleeps==s0);   // menu open: never paced
  menu_close();
  uint64_t t0=0,t1=0; for(int i=0;i<300;i++){ if(i==60) t0=g_host_now_us; frame(0); } t1=g_host_now_us;
  { double per=(double)(t1-t0)/240; printf("    50%%: %.1f us per game frame\n",per); CHECK(per>33333-50 && per<33333+50); }
  printf("S13) 25%% -> 66.7 ms; X re-show etc unaffected; back to 100%% = no sleep on the next read\n");
  menu_open(); go_row(ITEM_SPEED); press(RIGHT); press(RIGHT); CHECK(g_menu.speed==SPEED_25);
  { OvMenuView v; menu_view_fill(&v,"x"); CHECK(strstr(v.footer,"SLOW-MO STARTS ON CLOSE")); }
  menu_close();
  t0=0; for(int i=0;i<200;i++){ if(i==40) t0=g_host_now_us; frame(0); } t1=g_host_now_us;
  { double per=(double)(t1-t0)/160; printf("    25%%: %.1f us per game frame\n",per); CHECK(per>66667-50 && per<66667+50); }
  menu_open(); go_row(ITEM_SPEED); press(RIGHT); CHECK(g_menu.speed==SPEED_100); menu_close();
  s0=g_host_sleeps; for(int i=0;i<100;i++){ frame(0); } CHECK(g_host_sleeps==s0);

  printf("S14) combo under slow motion (ReadState): exactly the same input on every game frame\n");
  menu_open(); go_row(ITEM_SPEED); press(RIGHT); press(RIGHT); CHECK(g_menu.speed==SPEED_50); menu_close();
  s0=g_host_sleeps; expect_play(R3,LEGACY,18,0); expect_play(L3,LEGACY,18,1); CHECK(g_host_sleeps>s0+20);
  printf("S15) record in slow motion (ReadState): stored per game frame, plays back identically at 100%%\n");
  menu_open(); go_row(ITEM_SLOT); press(RIGHT); press(RIGHT); CHECK(g_menu.slot==2); menu_close();
  { uint32_t seq[]={RIGHT,SQ,TRI|X}; int len[]={3,2,4}; record(seq,len,3); }
  CHECK(g_slot_len[2]==10);
  menu_open(); go_row(ITEM_SPEED); press(LEFT); press(LEFT); CHECK(g_menu.speed==SPEED_100); menu_close();
  { const uint32_t e[10]={RIGHT,RIGHT,RIGHT,SQ,SQ,TRI|X,TRI|X,TRI|X,TRI|X,0}; expect_play(R3,e,10,0); }

  printf("S16) buffered scePadRead: 100%% = one step per sample (v2.12); slowed = steps follow game time\n");
  menu_open(); go_row(ITEM_SLOT); press(LEFT); press(LEFT); CHECK(g_menu.slot==0); menu_close();
  { uint32_t got[64], stream[256]; int ns=0; // 100%, 2 samples per call -> every sample is the next step (v2.12)
    read_call(R3,2,0); read_call(R3,2,0); read_call(0,2,got); CHECK(g_state==ST_PLAYING); stream[ns++]=got[1];
    while(g_state==ST_PLAYING && ns<40){ read_call(0,2,got); stream[ns++]=got[0]; stream[ns++]=got[1]; }
    for(int i=0;i<18;i++) CHECK(stream[i]==LEGACY[i]); CHECK(g_state==ST_IDLE); }
  menu_open(); go_row(ITEM_SPEED); press(RIGHT); press(RIGHT); CHECK(g_menu.speed==SPEED_50); menu_close();
  { uint32_t got[64]; // 50%: the pad buffers 4 samples per (slow) frame where it had 2 -> still 2 steps per frame
    read_call(R3,4,0); read_call(R3,4,0); read_call(0,4,got); CHECK(g_state==ST_PLAYING);
    int calls=0, per[32]; uint32_t prev=g_play_idx;
    while(g_state==ST_PLAYING && calls<30){ read_call(0,4,got); per[calls++]=(g_state==ST_PLAYING? (int)g_play_idx:18)-(int)prev; prev=g_play_idx;
    }
    printf("    50%%, 4 samples/call: %d calls, steps per call:",calls); for(int c=0;c<calls;c++) printf(" %d",per[c]); printf("\n");
    for(int c=0;c<calls-1;c++) CHECK(per[c]==2); CHECK(calls>=8 && calls<=9); }
  { uint32_t got[64]; // 50%, 1 sample per call (game reads once per frame with num=1): one step per frame
    read_call(R3,1,0); read_call(R3,1,0); read_call(0,1,got); CHECK(g_state==ST_PLAYING); int calls=0;
    while(g_state==ST_PLAYING && calls<40){ read_call(0,1,got); CHECK(got[0]==LEGACY[calls]); calls++; } CHECK(calls==18); }
  menu_open(); go_row(ITEM_SPEED); press(LEFT); press(LEFT); CHECK(g_menu.speed==SPEED_100); menu_close();

  printf("S17) installer-safe: only slot files + cfgs live in combo_macro\n");
  system("ls " DIR);
  printf("S18) on-screen menu fits and labels never collide (720p, 1080p, 4K)\n");
  { const uint32_t res[3][2]={{1280,720},{1920,1080},{3840,2160}};
    for(int r=0;r<3;r++){ OvGeom g; CHECK(ov_geom_strip(&g,res[r][0],res[r][1],ITEM_COUNT,1)); }
    const char *worst[]={"Damage 80%","10: 300.0s","Clear? SQUARE","100%","Auto: Pro B"};
    const char *labels[]={"P1 Health","Combo slot","Combo slot","Game speed","Overlay"};
    for(int i=0;i<5;i++){ int chars=(int)strlen(labels[i])+1+(int)strlen(worst[i])+4; CHECK(chars<=28); }
    const char *foots[]={"L3+R3 REC  R3/L3 PLAY  SQUARE CLEAR","SQUARE AGAIN = CLEAR   ANY OTHER = NO","SLOW-MO STARTS ON CLOSE   PAD 999/S"};
    for(int i=0;i<3;i++){ CHECK(strlen(foots[i])*16<=720-48); } }
  printf("S19) preview canvases (plugin's own view + renderer)\n");
  { g_slot_len[3]=95; g_slot_presses[3]=14; g_slot_len[6]=40; g_slot_presses[6]=6;
    g_menu.health[0]=HEALTH_DMG80; g_menu.health[1]=HEALTH_NORMAL; g_menu.ovl=OVL_PRO_A;
    for(int pv=0;pv<2;pv++){
      g_menu.selected= pv==0? ITEM_SLOT : ITEM_SPEED; g_menu.slot= pv==0? 3:3; g_menu.speed= pv==0? SPEED_100 : SPEED_50; g_pacer.rate=60;
      OvGeom g; ov_geom_strip(&g,1920,1080,ITEM_COUNT,1); uint8_t *cv=malloc(g.w*g.h); OvMenuView v; menu_view_fill(&v,"Pro A");
      ov_render_menu(cv,&g,&v,font8x8_basic);
      char fn[64]; snprintf(fn,64,"/tmp/tk_preview_%d.bin",pv); FILE*f=fopen(fn,"wb"); fwrite(&g.w,4,1,f); fwrite(&g.h,4,1,f); fwrite(&g.x,4,1,f); fwrite(&g.y,4,1,f); fwrite(cv,1,g.w*g.h,f); fclose(f); free(cv);
    } }
  printf("ALL v2.13 TESTS PASSED (%d checks)\n",checks);
  return 0; }
