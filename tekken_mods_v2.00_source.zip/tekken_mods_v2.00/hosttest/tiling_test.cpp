// Host tests for the overlay tiling (Tab). Build: g++ -O2 -std=c++17 tiling_test.cpp -o tiling_t
// References, copied in verbatim/ported 1:1 (sources in ../ref/):
//  REF1 shadPS4 TileManager32 + ConvertTileToLinear, commit c01b6f8 (2024-04-14), the CPU detiler
//       shadPS4 used for VideoOut display buffers (TilingMode::Tile).  Both is_neo=false and true.
//  REF2 shadPS4 host_shaders/tiling.comp (main, 2025) ComputeSurfaceAddrFromCoordMacroTiled ported
//       from GLSL to C++ with spec constants as parameters: Display micro tiling, 32 bpp,
//       ARRAY_2D_TILED_THIN1, macro mode for Display2DThin@32bpp = Mode_1x1_16 (tiling.cpp tables):
//       base: P8_32x32_16x16, bank w/h 1/1, 16 banks, aspect 2;
//       Neo alt (GetAltPipeConfig / GetAlt*): P16_32x32_8x16, bank h 2, 8 banks, aspect 1, with the
//       P16 pipe equation taken from AMD addrlib siaddrlib.cpp ComputePipeFromCoord (the shader has none).
//  Plugin code under test: ../repo/plugin_src/tekken_combo_macro/source/overlay_draw.h (written
//  independently in closed form).
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <cstdint>
#include <vector>
#include <cassert>
typedef uint8_t u8; typedef uint32_t u32; typedef uint64_t u64;
extern "C" {
#include "../repo/plugin_src/tekken_combo_macro/source/font8x8_basic.h"
#include "../repo/plugin_src/tekken_combo_macro/source/overlay_draw.h"
}

// ============================== REF1: shadPS4 c01b6f8 tile_manager.cpp (verbatim) ==============================
namespace VideoCore {
static u32 IntLog2(u32 i) {
    return 31 - __builtin_clz(i | 1u);
}
class TileManager32 {
public:
    u32 m_macro_tile_height = 0;
    u32 m_bank_height = 0;
    u32 m_num_banks = 0;
    u32 m_num_pipes = 0;
    u32 m_padded_width = 0;
    u32 m_padded_height = 0;
    u32 m_pipe_bits = 0;
    u32 m_bank_bits = 0;

    void Init(u32 width, u32 height, bool is_neo) {
        m_macro_tile_height = (is_neo ? 128 : 64);
        m_bank_height = is_neo ? 2 : 1;
        m_num_banks = is_neo ? 8 : 16;
        m_num_pipes = is_neo ? 16 : 8;
        m_padded_width = width;
        if (height == 1080) {
            m_padded_height = is_neo ? 1152 : 1088;
        }
        if (height == 720) {
            m_padded_height = 768;
        }
        m_pipe_bits = is_neo ? 4 : 3;
        m_bank_bits = is_neo ? 3 : 4;
    }

    static u32 getElementIdx(u32 x, u32 y) {
        u32 elem = 0;
        elem |= ((x >> 0u) & 0x1u) << 0u;
        elem |= ((x >> 1u) & 0x1u) << 1u;
        elem |= ((y >> 0u) & 0x1u) << 2u;
        elem |= ((x >> 2u) & 0x1u) << 3u;
        elem |= ((y >> 1u) & 0x1u) << 4u;
        elem |= ((y >> 2u) & 0x1u) << 5u;

        return elem;
    }

    static u32 getPipeIdx(u32 x, u32 y, bool is_neo) {
        u32 pipe = 0;

        if (!is_neo) {
            pipe |= (((x >> 3u) ^ (y >> 3u) ^ (x >> 4u)) & 0x1u) << 0u;
            pipe |= (((x >> 4u) ^ (y >> 4u)) & 0x1u) << 1u;
            pipe |= (((x >> 5u) ^ (y >> 5u)) & 0x1u) << 2u;
        } else {
            pipe |= (((x >> 3u) ^ (y >> 3u) ^ (x >> 4u)) & 0x1u) << 0u;
            pipe |= (((x >> 4u) ^ (y >> 4u)) & 0x1u) << 1u;
            pipe |= (((x >> 5u) ^ (y >> 5u)) & 0x1u) << 2u;
            pipe |= (((x >> 6u) ^ (y >> 5u)) & 0x1u) << 3u;
        }

        return pipe;
    }

    static u32 getBankIdx(u32 x, u32 y, u32 bank_width, u32 bank_height, u32 num_banks,
                          u32 num_pipes) {
        const u32 x_shift_offset = IntLog2(bank_width * num_pipes);
        const u32 y_shift_offset = IntLog2(bank_height);
        const u32 xs = x >> x_shift_offset;
        const u32 ys = y >> y_shift_offset;
        u32 bank = 0;
        switch (num_banks) {
        case 8:
            bank |= (((xs >> 3u) ^ (ys >> 5u)) & 0x1u) << 0u;
            bank |= (((xs >> 4u) ^ (ys >> 4u) ^ (ys >> 5u)) & 0x1u) << 1u;
            bank |= (((xs >> 5u) ^ (ys >> 3u)) & 0x1u) << 2u;
            break;
        case 16:
            bank |= (((xs >> 3u) ^ (ys >> 6u)) & 0x1u) << 0u;
            bank |= (((xs >> 4u) ^ (ys >> 5u) ^ (ys >> 6u)) & 0x1u) << 1u;
            bank |= (((xs >> 5u) ^ (ys >> 4u)) & 0x1u) << 2u;
            bank |= (((xs >> 6u) ^ (ys >> 3u)) & 0x1u) << 3u;
            break;
        default:;
        }

        return bank;
    }

    u64 getTiledOffs(u32 x, u32 y, bool is_neo) const {
        u64 element_index = getElementIdx(x, y);

        u32 xh = x;
        u32 yh = y;
        u64 pipe = getPipeIdx(xh, yh, is_neo);
        u64 bank = getBankIdx(xh, yh, 1, m_bank_height, m_num_banks, m_num_pipes);
        u32 tile_bytes = (8 * 8 * 32 + 7) / 8;
        u64 element_offset = (element_index * 32);
        u64 tile_split_slice = 0;

        if (tile_bytes > 512) {
            tile_split_slice = element_offset / (static_cast<u64>(512) * 8);
            element_offset %= (static_cast<u64>(512) * 8);
            tile_bytes = 512;
        }

        u64 macro_tile_bytes =
            (128 / 8) * (m_macro_tile_height / 8) * tile_bytes / (m_num_pipes * m_num_banks);
        u64 macro_tiles_per_row = m_padded_width / 128;
        u64 macro_tile_row_index = y / m_macro_tile_height;
        u64 macro_tile_column_index = x / 128;
        u64 macro_tile_index =
            (macro_tile_row_index * macro_tiles_per_row) + macro_tile_column_index;
        u64 macro_tile_offset = macro_tile_index * macro_tile_bytes;
        u64 macro_tiles_per_slice = macro_tiles_per_row * (m_padded_height / m_macro_tile_height);
        u64 slice_bytes = macro_tiles_per_slice * macro_tile_bytes;
        u64 slice_offset = tile_split_slice * slice_bytes;
        u64 tile_row_index = (y / 8) % m_bank_height;
        u64 tile_index = tile_row_index;
        u64 tile_offset = tile_index * tile_bytes;

        u64 tile_split_slice_rotation = ((m_num_banks / 2) + 1) * tile_split_slice;
        bank ^= tile_split_slice_rotation;
        bank &= (m_num_banks - 1);

        u64 total_offset = (slice_offset + macro_tile_offset + tile_offset) * 8 + element_offset;
        u64 bit_offset = total_offset & 0x7u;
        total_offset /= 8;

        u64 pipe_interleave_offset = total_offset & 0xffu;
        u64 offset = total_offset >> 8u;
        u64 byte_offset = pipe_interleave_offset | (pipe << (8u)) | (bank << (8u + m_pipe_bits)) |
                          (offset << (8u + m_pipe_bits + m_bank_bits));

        return ((byte_offset << 3u) | bit_offset) / 8;
    }
};

void ConvertTileToLinear(u8* dst, const u8* src, u32 width, u32 height, bool is_neo) {
    TileManager32 t;
    t.Init(width, height, is_neo);

    for (u32 y = 0; y < height; y++) {
        u32 x = 0;
        u64 linear_offset = y * width * 4;

        for (; x + 1 < width; x += 2) {
            auto tiled_offset = t.getTiledOffs(x, y, is_neo);

            std::memcpy(dst + linear_offset, src + tiled_offset, sizeof(u64));
            linear_offset += 8;
        }
        if (x < width) {
            auto tiled_offset = t.getTiledOffs(x, y, is_neo);
            std::memcpy(dst + linear_offset, src + tiled_offset, sizeof(u32));
        }
    }
}
} // namespace VideoCore

// ============================== REF2: shadPS4 tiling.comp (2025) ported to C++ ==============================
struct Ref2Params { u32 num_pipes, num_pipe_bits, pipe_cfg, bank_width, bank_height, num_banks, num_bank_bits, aspect; };
enum { ADDR_SURF_P8_32x32_16x16 = 1, ADDR_P16_32x32_8x16 = 2 };
#define _BIT(v, n) (((v) >> (n)) & 1u)
static u32 r2_pixel_index(u32 x, u32 y) {   // MICRO_TILE_MODE == DISPLAY, BITS_PER_PIXEL == 32
    u32 p0 = _BIT(x,0), p1 = _BIT(x,1), p2 = _BIT(y,0), p3 = _BIT(x,2), p4 = _BIT(y,1), p5 = _BIT(y,2);
    return p0 | (p1 << 1) | (p2 << 2) | (p3 << 3) | (p4 << 4) | (p5 << 5);
}
static u32 r2_pipe(const Ref2Params& P, u32 x, u32 y) {
    u32 tx = x / 8, ty = y / 8;
    u32 x3 = _BIT(tx,0), x4 = _BIT(tx,1), x5 = _BIT(tx,2), x6 = _BIT(tx,3);
    u32 y3 = _BIT(ty,0), y4 = _BIT(ty,1), y5 = _BIT(ty,2), y6 = _BIT(ty,3);
    u32 p0=0,p1=0,p2=0,p3=0;
    if (P.pipe_cfg == ADDR_SURF_P8_32x32_16x16) { p0 = x3 ^ y3 ^ x4; p1 = x4 ^ y4; p2 = x5 ^ y5; }
    else {   // addrlib siaddrlib.cpp ComputePipeFromCoord, ADDR_PIPECFG_P16_32x32_8x16
        p0 = x4 ^ y3; p1 = x3 ^ y4; p2 = x5 ^ y6; p3 = x6 ^ y5; }
    return p0 | (p1 << 1) | (p2 << 2) | (p3 << 3);   // ARRAY_2D: no pipe swizzle
}
static u32 r2_bank(const Ref2Params& P, u32 x, u32 y) {
    u32 tx = x / 8 / (P.bank_width * P.num_pipes);
    u32 ty = y / 8 / P.bank_height;
    u32 x3=_BIT(tx,0),x4=_BIT(tx,1),x5=_BIT(tx,2),x6=_BIT(tx,3),y3=_BIT(ty,0),y4=_BIT(ty,1),y5=_BIT(ty,2),y6=_BIT(ty,3);
    u32 b0=0,b1=0,b2=0,b3=0;
    if (P.num_banks == 16) { b0 = x3 ^ y6; b1 = x4 ^ y5 ^ y6; b2 = x5 ^ y4; b3 = x6 ^ y3; }
    else if (P.num_banks == 8) { b0 = x3 ^ y5; b1 = x4 ^ y4 ^ y5; b2 = x5 ^ y3; }
    u32 bank = b0 | (b1 << 1) | (b2 << 2) | (b3 << 3);
    // slice 0, tile_split_slice 0, bank_swizzle 0
    return bank & (P.num_banks - 1);
}
static u64 r2_addr(const Ref2Params& P, u32 x, u32 y, u32 pitch, u32 height) {
    u32 pixel_index = r2_pixel_index(x, y);
    u32 element_offset = (pixel_index * 32) / 8;
    u32 micro_tile_bytes = 256;   // 8*8*4; TILE_SPLIT_BYTES >= 256 so no split
    u32 macro_tile_pitch = (8 * P.bank_width * P.num_pipes) * P.aspect;
    u32 macro_tile_height = (8 * P.bank_height * P.num_banks) / P.aspect;
    u32 macro_tile_bytes = micro_tile_bytes * (macro_tile_pitch / 8) * (macro_tile_height / 8) / (P.num_pipes * P.num_banks);
    u32 macro_tiles_per_row = pitch / macro_tile_pitch;
    u32 mx = x / macro_tile_pitch, my = y / macro_tile_height;
    u64 macro_tile_offset = ((u64)my * macro_tiles_per_row + mx) * macro_tile_bytes;
    (void)height;
    u32 tile_row_index = (y / 8) % P.bank_height;
    u32 tile_column_index = ((x / 8) / P.num_pipes) % P.bank_width;
    u32 tile_index = tile_row_index * P.bank_width + tile_column_index;
    u64 tile_offset = (u64)tile_index * micro_tile_bytes;
    u64 total_offset = macro_tile_offset + element_offset + tile_offset;
    u64 pipe = r2_pipe(P, x, y), bank = r2_bank(P, x, y);
    u64 pio = total_offset & 0xff, offset = total_offset >> 8;
    return pio | (pipe << 8) | (bank << (8 + P.num_pipe_bits)) | (offset << (8 + P.num_pipe_bits + P.num_bank_bits));
}
static const Ref2Params R2_BASE = {8, 3, ADDR_SURF_P8_32x32_16x16, 1, 1, 16, 4, 2};
static const Ref2Params R2_NEO  = {16, 4, ADDR_P16_32x32_8x16, 1, 2, 8, 3, 1};

static int fails;
#define CHECK(c, ...) do { if (!(c)) { printf("FAIL: " __VA_ARGS__); printf("\n"); fails++; } } while (0)

// 1. every pixel's address vs the references, + the surface is a permutation (no overlaps, in bounds)
static void test_addresses(u32 w, u32 h) {
    VideoCore::TileManager32 b, n; b.Init(w, h, false); n.Init(w, h, true);
    u64 sz_b = ov_surface_bytes(OV_LAYOUT_PS4, w, h), sz_n = ov_surface_bytes(OV_LAYOUT_PRO_A, w, h);
    std::vector<u8> seen_b(sz_b / 4), seen_a(sz_n / 4), seen_bb(sz_n / 4);
    u64 mism[6] = {0};
    for (u32 y = 0; y < ov_padded_height(OV_LAYOUT_PRO_A, h); y++)
        for (u32 x = 0; x < w; x++) {
            if (y < ov_padded_height(OV_LAYOUT_PS4, h)) {
                u64 a = ov_pixel_offset(OV_LAYOUT_PS4, x, y, w);
                if (a != b.getTiledOffs(x, y, false)) mism[0]++;
                if (a != r2_addr(R2_BASE, x, y, w, h)) mism[1]++;
                if (a + 4 > sz_b || seen_b[a / 4]++) mism[2]++;
            }
            u64 pa = ov_pixel_offset(OV_LAYOUT_PRO_A, x, y, w), pb = ov_pixel_offset(OV_LAYOUT_PRO_B, x, y, w);
            if (pa != n.getTiledOffs(x, y, true)) mism[3]++;
            if (pb != r2_addr(R2_NEO, x, y, w, h)) mism[4]++;
            if (pa + 4 > sz_n || seen_a[pa / 4]++ || pb + 4 > sz_n || seen_bb[pb / 4]++) mism[5]++;
        }
    printf("  %ux%u: PS4 vs REF1 %llu, vs REF2 %llu, overlap/oob %llu | ProA vs REF1(neo) %llu | ProB vs REF2(neo) %llu | overlap/oob %llu\n",
           w, h, (unsigned long long)mism[0], (unsigned long long)mism[1], (unsigned long long)mism[2],
           (unsigned long long)mism[3], (unsigned long long)mism[4], (unsigned long long)mism[5]);
    for (int i = 0; i < 6; i++) CHECK(mism[i] == 0, "address mismatch class %d at %ux%u", i, w, h);
}

// 2. tile a full random image with the plugin's addressing, detile with shadPS4's ConvertTileToLinear
static void test_image_roundtrip(u32 w, u32 h, int layout, bool neo) {
    std::vector<u32> img((size_t)w * h), back((size_t)w * h);
    uint32_t s = 12345 + w + layout;
    for (auto &p : img) { s = s * 1664525u + 1013904223u; p = s; }
    std::vector<u8> tiled(ov_surface_bytes(layout, w, h) + 8, 0);
    for (u32 y = 0; y < h; y++) for (u32 x = 0; x < w; x++) memcpy(&tiled[ov_pixel_offset(layout, x, y, w)], &img[(size_t)y * w + x], 4);
    VideoCore::ConvertTileToLinear((u8 *)back.data(), tiled.data(), w, h, neo);
    CHECK(memcmp(img.data(), back.data(), img.size() * 4) == 0, "image round trip %ux%u layout %s", w, h, ov_layout_name(layout));
    printf("  image round trip %ux%u %-12s -> shadPS4 ConvertTileToLinear(is_neo=%d): %s\n", w, h, ov_layout_name(layout), neo,
           memcmp(img.data(), back.data(), img.size() * 4) == 0 ? "EXACT" : "DIFFERENT");
}

static void view_for(OvMenuView *v, int sel) {
    memset(v, 0, sizeof(*v));
    v->rows = 3; v->selected = sel; v->title = "TEKKEN 7 MOD MENU"; v->footer = "D-PAD SELECT/CHANGE   O CLOSE";
    v->label[0] = "P1 Health"; v->value[0] = "Infinite"; v->value_kind[0] = 1;
    v->label[1] = "P2 Health"; v->value[1] = "1-Hit"; v->value_kind[1] = 2;
    v->label[2] = "Overlay"; v->value[2] = "Auto"; v->value_kind[2] = 0;
}

// 3. the real menu blitter: linear render vs tiled render detiled by shadPS4, on a game-like background
static void test_menu_blit(u32 w, u32 h, int layout, bool neo, u32 fmt, const char *dump) {
    OvGeom g; OvMenuView v; view_for(&v, 1);
    CHECK(ov_geom(&g, w, h, v.rows), "geometry does not fit %ux%u", w, h);
    std::vector<u8> cv((size_t)g.w * g.h);
    ov_render_menu(cv.data(), &g, &v, font8x8_basic);
    std::vector<u32> bg((size_t)w * h);
    for (u32 y = 0; y < h; y++) for (u32 x = 0; x < w; x++) bg[(size_t)y * w + x] = ov_pack(fmt, (u8)(x * 255 / w), (u8)(y * 255 / h), 90);
    std::vector<u32> lin = bg;
    u32 nl = ov_blit((u8 *)lin.data(), (u64)lin.size() * 4, OV_LAYOUT_LINEAR, w, fmt, cv.data(), &g);
    std::vector<u8> tiled(ov_surface_bytes(layout, w, h) + 8, 0);
    for (u32 y = 0; y < h; y++) for (u32 x = 0; x < w; x++) memcpy(&tiled[ov_pixel_offset(layout, x, y, w)], &bg[(size_t)y * w + x], 4);
    u32 nt = ov_blit(tiled.data(), ov_surface_bytes(layout, w, h), layout, w, fmt, cv.data(), &g);
    std::vector<u32> back((size_t)w * h);
    VideoCore::ConvertTileToLinear((u8 *)back.data(), tiled.data(), w, h, neo);
    bool eq = memcmp(back.data(), lin.data(), lin.size() * 4) == 0;
    CHECK(eq && nl == nt && nl > 0, "menu blit %ux%u %s fmt %08x", w, h, ov_layout_name(layout), fmt);
    printf("  menu %ux%u %-12s %-17s panel %ux%u at (%u,%u) scale %u, %u px written: tiled->detiled == linear: %s\n", w, h,
           ov_layout_name(layout), ov_format_name(fmt), g.w, g.h, g.x, g.y, g.scale, nt, eq ? "EXACT" : "DIFFERENT");
    if (dump) { FILE *f = fopen(dump, "wb"); fwrite(&w, 4, 1, f); fwrite(&h, 4, 1, f); fwrite(back.data(), 4, back.size(), f); fclose(f); }
}

static void test_pack(void) {
    CHECK(ov_pack(OV_FMT_A8R8G8B8_SRGB, 0x11, 0x22, 0x33) == 0xff112233u, "A8R8G8B8 pack");
    CHECK(ov_pack(OV_FMT_A8B8G8R8_SRGB, 0x11, 0x22, 0x33) == 0xff332211u, "A8B8G8R8 pack");
    CHECK(ov_pack(OV_FMT_A2R10G10B10, 255, 0, 255) == (3u << 30 | 1023u << 20 | 1023u), "A2R10G10B10 pack");
    CHECK(ov_pack(OV_FMT_A2R10G10B10_SRGB, 128, 128, 128) == (3u << 30 | 514u << 20 | 514u << 10 | 514u), "A2R10G10B10 mid grey");
    uint32_t pq = ov_pack(OV_FMT_A2R10G10B10_PQ, 255, 255, 255);
    CHECK(((pq >> 20) & 1023) == OV_PQ10[255] && OV_PQ10[255] > 560 && OV_PQ10[255] < 620, "PQ white ~203 nits");
    CHECK(!ov_format_supported(OV_FMT_A16R16G16B16_F) && !ov_format_supported(0x12345678), "unsupported formats refused");
    // element tables inside ov_blit agree with ov_elem
    for (u32 y = 0; y < 8; y++) for (u32 x = 0; x < 8; x++) {
        u32 e = ov_elem(x, y);
        u32 ex = (e & 1) | ((e >> 1) & 1) << 1 | ((e >> 3) & 1) << 2, ey = ((e >> 2) & 1) | ((e >> 4) & 1) << 1 | ((e >> 5) & 1) << 2;
        CHECK(ex == x && ey == y, "elem inverse %u,%u", x, y);
    }
    printf("  pixel packing (A8R8G8B8, A8B8G8R8, A2R10G10B10, A2R10G10B10 sRGB, HDR PQ) and element tables: ok\n");
}

// 4. bounds: a buffer whose known-mapped size is smaller than the panel area must never be written past
static void test_bounds(void) {
    OvGeom g; OvMenuView v; view_for(&v, 0); ov_geom(&g, 1920, 1080, 3);
    std::vector<u8> cv((size_t)g.w * g.h); ov_render_menu(cv.data(), &g, &v, font8x8_basic);
    u64 limit = 1920ull * 400 * 4;   // pretend only 400 rows are mapped
    std::vector<u8> buf(ov_surface_bytes(OV_LAYOUT_PS4, 1920, 1080) + 64, 0xAB);
    ov_blit(buf.data(), limit, OV_LAYOUT_PS4, 1920, OV_FMT_A8R8G8B8_SRGB, cv.data(), &g);
    bool ok = true; for (u64 i = limit; i < buf.size(); i++) if (buf[i] != 0xAB) { ok = false; break; }
    CHECK(ok, "bounds respected");
    printf("  bounds check (writes stop at the mapped size): %s\n", ok ? "ok" : "FAIL");
}

int main(int argc, char **argv) {
    printf("T1) per-pixel address vs shadPS4 references, whole padded surface\n");
    test_addresses(1920, 1080); test_addresses(1280, 720); test_addresses(3840, 2160); test_addresses(1920, 1088);
    printf("T2) full-image tile -> shadPS4 detile round trip\n");
    test_image_roundtrip(1920, 1080, OV_LAYOUT_PS4, false); test_image_roundtrip(1280, 720, OV_LAYOUT_PS4, false);
    test_image_roundtrip(1920, 1080, OV_LAYOUT_PRO_A, true);
    printf("T3) menu blitter (tiled vs linear) on every supported format\n");
    const u32 fmts[] = {OV_FMT_A8R8G8B8_SRGB, OV_FMT_A8B8G8R8_SRGB, OV_FMT_A2R10G10B10, OV_FMT_A2R10G10B10_SRGB, OV_FMT_A2R10G10B10_PQ};
    for (u32 f : fmts) test_menu_blit(1920, 1080, OV_LAYOUT_PS4, false, f, f == OV_FMT_A8R8G8B8_SRGB && argc > 1 ? argv[1] : nullptr);
    test_menu_blit(1280, 720, OV_LAYOUT_PS4, false, OV_FMT_A8R8G8B8_SRGB, nullptr);
    test_menu_blit(1920, 1080, OV_LAYOUT_PRO_A, true, OV_FMT_A8R8G8B8_SRGB, nullptr);
    test_menu_blit(3840, 2160, OV_LAYOUT_PS4, false, OV_FMT_A2R10G10B10_PQ, nullptr);
    printf("T4) packing and bounds\n");
    test_pack(); test_bounds();
    printf(fails ? "\n%d FAILURES\n" : "\nALL TILING TESTS PASSED\n", fails);
    return fails != 0;
}
