
#pragma once
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdarg.h>
#include <sys/types.h>
#define GOLDHEN_PATH "/tmp/tkcm_test/GoldHEN"
#define u32 uint32_t
#define s32 int32_t
#define s64 int64_t
#define TEX_ICON_SYSTEM "icon"
#define attr_public
#define attr_module_hidden static __attribute__((unused))
#define final_printf(...) 
#define boot_ver()
void NotifyStatic(const char* i, const char *t);
void Notify(const char* i, const char *f, ...);
